$(document).ready(function () {
    $(".submit-form").click(function () {
        var title = $('#title').val();
        var subtitle = $('#sub-title').val();
        var image_url = $('#image-url').val();
        var button_title = $('#button-title').val();
        var url = $('#url').val();
        var data = {
            "title": title,
            "subtitle": subtitle,
            "image_url": image_url,
            "button_title": button_title,
            "url": url
        }
        var parsedFormData = localStorage.getItem('parsedFormData');
        console.log(JSON.parse(parsedFormData));
        // Store Data
        localStorage.setItem("formData", JSON.stringify(data));
        var data = localStorage.getItem("formData");
        console.log('Data' + data);
        window.location.href = "view-campaign.html";
        // broadcastMessage();
    });
    if (localStorage.getItem('textValues') == null) {
        var dataList = [];
    } else {
        dataList = JSON.parse(localStorage.getItem('textValues'));
        //-----------^parse the item by getting---^--stored item
    }

    // Retrieve
    var data = localStorage.getItem("formData");
    var parsedData = JSON.parse(data);
    dataList.push(parsedData);
    localStorage.removeItem("formData");
    localStorage.setItem('textValues', JSON.stringify(dataList));
    var textValues = localStorage.getItem('textValues');
    console.log(dataList[0]);
    console.log(dataList.length);
    var i;
    for (i = dataList.length; i > 0; i--) {
        if (dataList[i] != null) {
            $('.post-main-div').append('<div class="row user-post-block"><div class="user-post col-sm-12"><div class="media"><img class="align-self-start mr-3" src="assets/images/user.jpg" alt="profile image"><div class="media-body"><div class="mt-0 username"><a>Saraha Smith</a></div><div class="user-designation"></div></div></div><div class="description pd-l-15 pd-r-15"><h4 class="title">' + dataList[i].title + '</h4><span  class="sub-title">' + dataList[i].subtitle + '</span></div><div class="d-none button-title">' + dataList[i].button_title + '</div><div class="d-none url">' + dataList[i].url + '</div><div class="post-image mr-t-20"><img src="' + dataList[i].image_url + '"></div><div class="divider"></div><div class="button-div"><div class="broadcast-btn"><span><i class="fa fa-users"></i> Broadcast</span></div><div class="share-btn"><span><i class="fa fa-share"></i> Share</span></div></div></div></div>');
        }
    }
    //   });
    $('.broadcast-btn span').on('click', function () {
        $('.lds-dual-ring').show();
        $('.ui-loader-background').show();
        var title = $(this).parent().parent().parent().find('.title').html();
        var subtitle = $(this).parent().parent().parent().find('.sub-title').html();
        var image_url = $(this).parent().parent().parent().find('.post-image img').attr('src');
        var button_title = $(this).parent().parent().parent().find('.button-title').html();
        var url = $(this).parent().parent().parent().find('.url').html();
        var data = {
            "title": title,
            "subtitle": subtitle,
            "image_url": image_url,
            "button_title": button_title,
            "url": url
        }
        // var toast = $(this).parent().parent().parent().find('.success-toast');
        broadcastMessage(data);
    });
    $('.share-btn span').on('click', function () {
        $('.lds-dual-ring').show();
        $('.ui-loader-background').show();
        var title = $(this).parent().parent().parent().find('.title').html();
        var subtitle = $(this).parent().parent().parent().find('.sub-title').html();
        var image_url = $(this).parent().parent().parent().find('.post-image img').attr('src');
        var button_title = $(this).parent().parent().parent().find('.button-title').html();
        var url = $(this).parent().parent().parent().find('.url').html();
        var data = {
            "title": title,
            "subtitle": subtitle,
            "image_url": image_url,
            "button_title": button_title,
            "url": url
        }
        createPostMessage(data);
        // $(this).parent().parent().parent().find('.success-toast-share').css('display', 'block').delay(3000).fadeOut(300);
    });
    function broadcastMessage(data) {
        $.ajax({
            type: "POST",
            url: "/fbservices/broadcastMessage",
            crossDomain: true,
            dataType: "json",
            processData: false,
            contentType: "application/json; charset=UTF-8",
            data: JSON.stringify(data),
            success: function (data) {
                alert('success');
            },
            error: function (error) {
                $('.lds-dual-ring').hide();
                $('.ui-loader-background').hide();
                window.scrollTo(0, 0);
                $('.success-toast').css('display', 'block').delay(3000).fadeOut(300);
            }
        });
    }
    function createPostMessage(data) {
        $.ajax({
            type: "POST",
            url: "/fbservices/createPost",
            crossDomain: true,
            dataType: "json",
            processData: false,
            contentType: "application/json; charset=UTF-8",
            data: JSON.stringify(data),
            success: function (data) {
                alert('success');
            },
            error: function (error) {
                $('.lds-dual-ring').hide();
                $('.ui-loader-background').hide();
                window.scrollTo(0, 0);
                $('.success-toast-share').css('display', 'block').delay(3000).fadeOut(300);
            }
        });
    }
});