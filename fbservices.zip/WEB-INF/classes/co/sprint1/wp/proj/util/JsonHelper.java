// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   JsonHelper.java

package co.sprint1.wp.util;

import com.google.gson.*;
import java.util.Date;

public final class JsonHelper
{
    public static final class Constants extends Enum
    {

        public static Constants[] values()
        {
            return (Constants[])$VALUES.clone();
        }

        public static Constants valueOf(String name)
        {
            return (Constants)Enum.valueOf(co/sprint1/wp/util/JsonHelper$Constants, name);
        }

        String getValue()
        {
            return value;
        }

        public static final Constants PROP_OBJECT;
        public static final Constants PROP_ENTRY;
        public static final Constants PROP_MESSAGING;
        public static final Constants PROP_SENDER;
        public static final Constants PROP_RECIPIENT;
        public static final Constants PROP_ID;
        public static final Constants PROP_TIMESTAMP;
        public static final Constants PROP_OPTIN;
        public static final Constants PROP_MESSAGE;
        public static final Constants PROP_MID;
        public static final Constants PROP_IS_ECHO;
        public static final Constants PROP_QUICK_REPLY;
        public static final Constants PROP_TEXT;
        public static final Constants PROP_ATTACHMENTS;
        public static final Constants PROP_PAYLOAD;
        public static final Constants PROP_TYPE;
        public static final Constants PROP_TITLE;
        public static final Constants PROP_URL;
        public static final Constants PROP_COORDINATES;
        public static final Constants PROP_LAT;
        public static final Constants PROP_LONG;
        public static final Constants PROP_REF;
        public static final Constants PROP_APP_ID;
        public static final Constants PROP_METADATA;
        public static final Constants PROP_POSTBACK;
        public static final Constants PROP_ACCOUNT_LINKING;
        public static final Constants PROP_STATUS;
        public static final Constants PROP_AUTHORIZATION_CODE;
        public static final Constants PROP_READ;
        public static final Constants PROP_WATERMARK;
        public static final Constants PROP_DELIVERY;
        public static final Constants PROP_MIDS;
        public static final Constants PROP_RECIPIENT_ID;
        public static final Constants PROP_MESSAGE_ID;
        public static final Constants PROP_ATTACHMENT_ID;
        public static final Constants PROP_ERROR;
        public static final Constants PROP_CODE;
        public static final Constants PROP_FB_TRACE_ID;
        public static final Constants PROP_RESULT;
        public static final Constants PROP_FIRST_NAME;
        public static final Constants PROP_LAST_NAME;
        public static final Constants PROP_PROFILE_PIC;
        public static final Constants PROP_LOCALE;
        public static final Constants PROP_TIMEZONE;
        public static final Constants PROP_GENDER;
        private final String value;
        private static final Constants $VALUES[];

        static 
        {
            PROP_OBJECT = new Constants("PROP_OBJECT", 0, "object");
            PROP_ENTRY = new Constants("PROP_ENTRY", 1, "entry");
            PROP_MESSAGING = new Constants("PROP_MESSAGING", 2, "messaging");
            PROP_SENDER = new Constants("PROP_SENDER", 3, "sender");
            PROP_RECIPIENT = new Constants("PROP_RECIPIENT", 4, "recipient");
            PROP_ID = new Constants("PROP_ID", 5, "id");
            PROP_TIMESTAMP = new Constants("PROP_TIMESTAMP", 6, "timestamp");
            PROP_OPTIN = new Constants("PROP_OPTIN", 7, "optin");
            PROP_MESSAGE = new Constants("PROP_MESSAGE", 8, "message");
            PROP_MID = new Constants("PROP_MID", 9, "mid");
            PROP_IS_ECHO = new Constants("PROP_IS_ECHO", 10, "is_echo");
            PROP_QUICK_REPLY = new Constants("PROP_QUICK_REPLY", 11, "quick_reply");
            PROP_TEXT = new Constants("PROP_TEXT", 12, "text");
            PROP_ATTACHMENTS = new Constants("PROP_ATTACHMENTS", 13, "attachments");
            PROP_PAYLOAD = new Constants("PROP_PAYLOAD", 14, "payload");
            PROP_TYPE = new Constants("PROP_TYPE", 15, "type");
            PROP_TITLE = new Constants("PROP_TITLE", 16, "title");
            PROP_URL = new Constants("PROP_URL", 17, "url");
            PROP_COORDINATES = new Constants("PROP_COORDINATES", 18, "coordinates");
            PROP_LAT = new Constants("PROP_LAT", 19, "lat");
            PROP_LONG = new Constants("PROP_LONG", 20, "long");
            PROP_REF = new Constants("PROP_REF", 21, "ref");
            PROP_APP_ID = new Constants("PROP_APP_ID", 22, "app_id");
            PROP_METADATA = new Constants("PROP_METADATA", 23, "metadata");
            PROP_POSTBACK = new Constants("PROP_POSTBACK", 24, "postback");
            PROP_ACCOUNT_LINKING = new Constants("PROP_ACCOUNT_LINKING", 25, "account_linking");
            PROP_STATUS = new Constants("PROP_STATUS", 26, "status");
            PROP_AUTHORIZATION_CODE = new Constants("PROP_AUTHORIZATION_CODE", 27, "authorization_code");
            PROP_READ = new Constants("PROP_READ", 28, "read");
            PROP_WATERMARK = new Constants("PROP_WATERMARK", 29, "watermark");
            PROP_DELIVERY = new Constants("PROP_DELIVERY", 30, "delivery");
            PROP_MIDS = new Constants("PROP_MIDS", 31, "mids");
            PROP_RECIPIENT_ID = new Constants("PROP_RECIPIENT_ID", 32, "recipient_id");
            PROP_MESSAGE_ID = new Constants("PROP_MESSAGE_ID", 33, "message_id");
            PROP_ATTACHMENT_ID = new Constants("PROP_ATTACHMENT_ID", 34, "attachment_id");
            PROP_ERROR = new Constants("PROP_ERROR", 35, "error");
            PROP_CODE = new Constants("PROP_CODE", 36, "code");
            PROP_FB_TRACE_ID = new Constants("PROP_FB_TRACE_ID", 37, "fbtrace_id");
            PROP_RESULT = new Constants("PROP_RESULT", 38, "result");
            PROP_FIRST_NAME = new Constants("PROP_FIRST_NAME", 39, "first_name");
            PROP_LAST_NAME = new Constants("PROP_LAST_NAME", 40, "last_name");
            PROP_PROFILE_PIC = new Constants("PROP_PROFILE_PIC", 41, "profile_pic");
            PROP_LOCALE = new Constants("PROP_LOCALE", 42, "locale");
            PROP_TIMEZONE = new Constants("PROP_TIMEZONE", 43, "timezone");
            PROP_GENDER = new Constants("PROP_GENDER", 44, "gender");
            $VALUES = (new Constants[] {
                PROP_OBJECT, PROP_ENTRY, PROP_MESSAGING, PROP_SENDER, PROP_RECIPIENT, PROP_ID, PROP_TIMESTAMP, PROP_OPTIN, PROP_MESSAGE, PROP_MID, 
                PROP_IS_ECHO, PROP_QUICK_REPLY, PROP_TEXT, PROP_ATTACHMENTS, PROP_PAYLOAD, PROP_TYPE, PROP_TITLE, PROP_URL, PROP_COORDINATES, PROP_LAT, 
                PROP_LONG, PROP_REF, PROP_APP_ID, PROP_METADATA, PROP_POSTBACK, PROP_ACCOUNT_LINKING, PROP_STATUS, PROP_AUTHORIZATION_CODE, PROP_READ, PROP_WATERMARK, 
                PROP_DELIVERY, PROP_MIDS, PROP_RECIPIENT_ID, PROP_MESSAGE_ID, PROP_ATTACHMENT_ID, PROP_ERROR, PROP_CODE, PROP_FB_TRACE_ID, PROP_RESULT, PROP_FIRST_NAME, 
                PROP_LAST_NAME, PROP_PROFILE_PIC, PROP_LOCALE, PROP_TIMEZONE, PROP_GENDER
            });
        }

        private Constants(String s, int i, String value)
        {
            super(s, i);
            this.value = value;
        }
    }


    private JsonHelper()
    {
    }

    public static transient JsonElement getProperty(JsonObject jsonObject, Constants propertyPath[])
    {
        if(jsonObject == null)
            return null;
        JsonObject internalValue = jsonObject;
        for(int i = 0; i <= propertyPath.length - 2; i++)
        {
            JsonElement property = internalValue.get(propertyPath[i].getValue());
            if(property == null || !property.isJsonObject())
                return null;
            internalValue = property.getAsJsonObject();
        }

        JsonElement property = internalValue.get(propertyPath[propertyPath.length - 1].getValue());
        return property != null && !property.isJsonNull() ? property : null;
    }

    public static transient boolean hasProperty(JsonObject jsonObject, Constants propertyPath[])
    {
        return getProperty(jsonObject, propertyPath) != null;
    }

    public static transient String getPropertyAsString(JsonObject jsonObject, Constants propertyPath[])
    {
        JsonElement jsonElement = getProperty(jsonObject, propertyPath);
        return jsonElement != null ? jsonElement.getAsString() : null;
    }

    public static transient Integer getPropertyAsInt(JsonObject jsonObject, Constants propertyPath[])
    {
        JsonElement jsonElement = getProperty(jsonObject, propertyPath);
        return jsonElement != null ? Integer.valueOf(jsonElement.getAsInt()) : null;
    }

    public static transient Boolean getPropertyAsBoolean(JsonObject jsonObject, Constants propertyPath[])
    {
        JsonElement jsonElement = getProperty(jsonObject, propertyPath);
        return jsonElement != null ? Boolean.valueOf(jsonElement.getAsBoolean()) : null;
    }

    public static transient Long getPropertyAsLong(JsonObject jsonObject, Constants propertyPath[])
    {
        JsonElement jsonElement = getProperty(jsonObject, propertyPath);
        return jsonElement != null ? Long.valueOf(jsonElement.getAsLong()) : null;
    }

    public static transient Date getPropertyAsDate(JsonObject jsonObject, Constants propertyPath[])
    {
        Long longValue = getPropertyAsLong(jsonObject, propertyPath);
        return longValue != null ? new Date(longValue.longValue()) : null;
    }

    public static transient Double getPropertyAsDouble(JsonObject jsonObject, Constants propertyPath[])
    {
        JsonElement jsonElement = getProperty(jsonObject, propertyPath);
        return jsonElement != null ? Double.valueOf(jsonElement.getAsDouble()) : null;
    }

    public static transient Float getPropertyAsFloat(JsonObject jsonObject, Constants propertyPath[])
    {
        JsonElement jsonElement = getProperty(jsonObject, propertyPath);
        return jsonElement != null ? Float.valueOf(jsonElement.getAsFloat()) : null;
    }

    public static transient JsonArray getPropertyAsJsonArray(JsonObject jsonObject, Constants propertyPath[])
    {
        JsonElement jsonElement = getProperty(jsonObject, propertyPath);
        return jsonElement != null ? jsonElement.getAsJsonArray() : null;
    }

    public static transient JsonObject getPropertyAsJsonObject(JsonObject jsonObject, Constants propertyPath[])
    {
        JsonElement jsonElement = getProperty(jsonObject, propertyPath);
        return jsonElement != null ? jsonElement.getAsJsonObject() : null;
    }
}
