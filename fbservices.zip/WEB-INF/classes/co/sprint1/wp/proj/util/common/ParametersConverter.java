// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ParametersConverter.java

package co.sprint1.wp.util.common;

import java.text.*;
import java.util.*;

// Referenced classes of package co.sprint1.wp.util.common:
//            PartialDate

public final class ParametersConverter
{

    private ParametersConverter()
    {
    }

    public static Date parseDateTime(String parameter)
        throws ParseException
    {
        if(parameter == null)
            throw new IllegalArgumentException("Parameter must not be null");
        else
            return DATE_TIME_FORMAT.parse(parameter);
    }

    public static Date parseDate(String parameter)
        throws ParseException
    {
        if(parameter == null)
            throw new IllegalArgumentException("Parameter must not be null");
        else
            return DATE_FORMAT.parse(parameter);
    }

    public static Date parseTime(String parameter)
        throws ParseException
    {
        if(parameter == null)
        {
            throw new IllegalArgumentException("Parameter must not be null");
        } else
        {
            Calendar timeParameter = Calendar.getInstance();
            timeParameter.setTime(TIME_FORMAT.parse(parameter));
            Calendar taskDueDate = Calendar.getInstance();
            taskDueDate.set(11, timeParameter.get(11));
            taskDueDate.set(12, timeParameter.get(12));
            taskDueDate.set(13, timeParameter.get(13));
            return taskDueDate.getTime();
        }
    }

    public static PartialDate parsePartialDate(String parameter)
        throws ParseException
    {
        if(parameter == null)
            throw new IllegalArgumentException("Parameter must not be empty");
        if(parameter.length() == 0)
            throw new ParseException("Parameter must not be empty", 0);
        if(parameter.contains("u"))
        {
            String parts[] = parameter.split("-");
            if(parts.length != 3)
            {
                throw new ParseException(String.format("Partial date must have 3 parts, but have %s: %s", new Object[] {
                    Integer.valueOf(parts.length), parameter
                }), 0);
            } else
            {
                Integer year = parsePart(parts[0]);
                Integer month = parsePart(parts[1]);
                Integer day = parsePart(parts[2]);
                PartialDate result = new PartialDate();
                result.set(1, year);
                result.set(2, month);
                result.set(5, day);
                return result;
            }
        } else
        {
            return new PartialDate(DATE_FORMAT.parse(parameter));
        }
    }

    public static int parseInteger(String parameter)
        throws NumberFormatException
    {
        return Integer.parseInt(parameter);
    }

    public static float parseFloat(String parameter)
    {
        if(parameter == null)
            throw new IllegalArgumentException("Parameter must not be empty");
        else
            return Float.parseFloat(parameter);
    }

    private static Integer parsePart(String part)
    {
        if(part == null)
            throw new IllegalArgumentException("part");
        if(part.indexOf('u') >= 0)
            return PartialDate.UNSPECIFIED_VALUE;
        else
            return Integer.valueOf(Integer.parseInt(part));
    }

    public static final String PROTOCOL_DATE_FORMAT = "yyyy-MM-dd";
    public static final String PROTOCOL_DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ssZ";
    public static final String PROTOCOL_TIME_FORMAT = "HH:mm:ss";
    private static final DateFormat DATE_FORMAT;
    private static final DateFormat DATE_TIME_FORMAT;
    private static final DateFormat TIME_FORMAT;

    static 
    {
        DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        DATE_TIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US);
        TIME_FORMAT = new SimpleDateFormat("HH:mm:ss", Locale.US);
    }
}
