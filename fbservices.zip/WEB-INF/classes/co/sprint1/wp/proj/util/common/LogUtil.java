// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   LogUtil.java

package co.sprint1.wp.util.common;

import com.google.gson.Gson;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LogUtil
{

    public LogUtil()
    {
    }

    public static void logJsonObject(Class clazz, String message, Object obj)
    {
        try
        {
            String gsonString = gson.toJson(obj);
            logger.debug((new StringBuilder()).append(clazz.getName()).append(" : ").append(message).append(" : ").append(gsonString).toString());
        }
        catch(Exception e)
        {
            logger.error((new StringBuilder()).append("error while logging ").append(clazz.getName()).append(" : ").append(message).toString());
        }
    }

    public static void logJsonObjectAsError(Class clazz, String message, Object obj)
    {
        try
        {
            String gsonString = gson.toJson(obj);
            logger.error((new StringBuilder()).append(clazz.getName()).append(" : ").append(message).append(" : ").append(gsonString).toString());
        }
        catch(Exception e)
        {
            logger.error((new StringBuilder()).append("error while logging ").append(clazz.getName()).append(" : ").append(message).toString());
        }
    }

    private static Logger logger = LogManager.getLogger(co/sprint1/wp/util/common/LogUtil.getName());
    private static Gson gson = new Gson();

}
