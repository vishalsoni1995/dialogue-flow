// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   WebhookResource.java

package co.sprint1.wp.resources.webhooks;

import co.sprint1.wp.helper.FBMessageHelper;
import co.sprint1.wp.model.fb.*;
import co.sprint1.wp.model.ro.WebHookRequest;
import co.sprint1.wp.util.common.LogUtil;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class WebhookResource
{

    public WebhookResource()
    {
        logger = LogManager.getLogger(getClass().getName());
        RRSP_INTROMESSAGE = "RRSP is an arrangement between an Individual and Insurance company under which contributions are made by individuals and a retirement income is payable at maturity.";
        RRSP_QUICKHints = "Let me know how can i help you , or choose from suggested topics";
    }

    public String broadcastMessage(WebHookRequest request)
        throws IOException
    {
        LogUtil.logJsonObject(co/sprint1/wp/model/ro/WebHookRequest, "Webhook Invoked with Message :", request);
        if(request.getEntry() != null && !request.getEntry().isEmpty() && request.getEntry().get(0) != null && ((Entry)request.getEntry().get(0)).getMessaging() != null && !((Entry)request.getEntry().get(0)).getMessaging().isEmpty())
        {
            MessageEvent message = (MessageEvent)((Entry)request.getEntry().get(0)).getMessaging().get(0);
            if(message.getPostback() != null && message.getPostback().getPayload() != null && message.getPostback().getPayload().equalsIgnoreCase("RRSP_POSTBACK") && message.getSender() != null && message.getSender().getId() != null)
            {
                List quickList = new ArrayList();
                QuickReply e = new QuickReply(co.sprint1.wp.model.fb.QuickReply.ContentType.TEXT, "Eligibility", "Eligibility", null);
                QuickReply e2 = new QuickReply(co.sprint1.wp.model.fb.QuickReply.ContentType.TEXT, "Tax Benefits", "Tax Benefits", null);
                QuickReply e3 = new QuickReply(co.sprint1.wp.model.fb.QuickReply.ContentType.TEXT, "Contribution Limit", "Contribution Limit", null);
                QuickReply e4 = new QuickReply(co.sprint1.wp.model.fb.QuickReply.ContentType.TEXT, "Calculator", "Calculator", null);
                QuickReply e5 = new QuickReply(co.sprint1.wp.model.fb.QuickReply.ContentType.TEXT, "Withdrawls", "Withdrawls", null);
                QuickReply e6 = new QuickReply(co.sprint1.wp.model.fb.QuickReply.ContentType.TEXT, "Any Other Queries", "Any Other Queries", null);
                quickList.add(e);
                quickList.add(e2);
                quickList.add(e3);
                quickList.add(e4);
                quickList.add(e5);
                quickList.add(e6);
                fbMessageHelper.sendTextMessage(message.getSender().getId(), RRSP_INTROMESSAGE, null);
                fbMessageHelper.sendTextMessage(message.getSender().getId(), RRSP_QUICKHints, quickList);
            }
        }
        return "success";
    }

    public String verifyFBToken(String mode, String verifyToken, String challenge)
    {
        logger.debug("Received Verification Request");
        if("subscribe".equalsIgnoreCase(mode) && "hitch-bot-token".equalsIgnoreCase(verifyToken))
            return challenge;
        else
            return "";
    }

    Logger logger;
    private String RRSP_INTROMESSAGE;
    private String RRSP_QUICKHints;
    FBMessageHelper fbMessageHelper;
}
