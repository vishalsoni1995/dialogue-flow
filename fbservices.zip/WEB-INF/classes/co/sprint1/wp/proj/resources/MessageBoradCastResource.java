// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   MessageBoradCastResource.java

package co.sprint1.wp.resources;

import co.sprint1.wp.helper.FBBroadCastHelper;
import co.sprint1.wp.model.fb.*;
import co.sprint1.wp.model.fb.ro.CreateBroadcastMessageRequest;
import co.sprint1.wp.model.ro.BroadcastMessageRequest;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class MessageBoradCastResource
{

    public MessageBoradCastResource()
    {
        logger = LogManager.getLogger(getClass().getName());
    }

    public String broadcastMessage(BroadcastMessageRequest request)
        throws IOException
    {
        Long bcId = null;
        if(request != null)
        {
            CreateBroadcastMessageRequest createMessage = new CreateBroadcastMessageRequest();
            Message3 broadcastGenericTemplate = new Message3();
            Attachment attachment = new Attachment();
            Payload genericMessageTemplate = new Payload();
            genericMessageTemplate.setTemplate_type("generic");
            PayloadElement genericeTemplatePayload = new PayloadElement();
            genericeTemplatePayload.setTitle(request.getTitle());
            genericeTemplatePayload.setSubtitle(request.getSubtitle());
            if(request.getImage_url() != null && !"".equals(request.getImage_url()))
                genericeTemplatePayload.setImage_url(request.getImage_url());
            ArrayList buttonList = new ArrayList();
            if(request.getButton_title() != null && !"".equals(request.getButton_title()) && request.getUrl() != null && !"".equals(request.getUrl()))
            {
                Button button = new Button();
                button.setTitle(request.getButton_title());
                button.setUrl(request.getUrl());
                button.setType("web_url");
                buttonList.add(button);
            }
            Button buttonPostback = new Button();
            buttonPostback.setTitle("Lets Talk");
            buttonPostback.setType("postback");
            buttonPostback.setPayload("RRSP_POSTBACK");
            buttonList.add(buttonPostback);
            genericeTemplatePayload.setButtons(buttonList);
            ArrayList elementList = new ArrayList();
            elementList.add(genericeTemplatePayload);
            genericMessageTemplate.setElements(elementList);
            attachment.setType("template");
            attachment.setPayload(genericMessageTemplate);
            broadcastGenericTemplate.setAttachment(attachment);
            ArrayList messages = new ArrayList();
            messages.add(broadcastGenericTemplate);
            createMessage.setMessages(messages);
            Long messageId = fBBroadCastHelper.createBroadcastMessage(createMessage);
            if(messageId != null)
                bcId = fBBroadCastHelper.sendBroadcast(messageId);
        }
        return (new StringBuilder()).append("Success : ").append(bcId).toString();
    }

    Logger logger;
    FBBroadCastHelper fBBroadCastHelper;
}
