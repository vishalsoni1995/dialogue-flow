// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CreateSFLeadResource.java

package co.sprint1.wp.resources;

import co.sprint1.wp.helper.SalesForceHelper;
import co.sprint1.wp.model.ro.CreateSFLeadRequest;
import co.sprint1.wp.util.common.LogUtil;
import java.io.IOException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CreateSFLeadResource
{

    public CreateSFLeadResource()
    {
        logger = LogManager.getLogger(getClass().getName());
    }

    public String broadcastMessage(CreateSFLeadRequest request)
        throws IOException
    {
        String sfResponse = null;
        if(request != null)
        {
            LogUtil.logJsonObject(co/sprint1/wp/model/ro/CreateSFLeadRequest, "Create Lead Input Request", request);
            salesForceHelper.createLead("Tarun", "Mittal", "9990121772");
        }
        return "Success : ";
    }

    Logger logger;
    SalesForceHelper salesForceHelper;
}
