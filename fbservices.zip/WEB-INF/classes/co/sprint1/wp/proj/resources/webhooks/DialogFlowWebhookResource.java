// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   DialogFlowWebhookResource.java

package co.sprint1.wp.resources.webhooks;

import co.sprint1.wp.helper.SalesForceHelper;
import co.sprint1.wp.model.dialogflow.AIFulfilmentRequest;
import co.sprint1.wp.model.dialogflow.QueryResult;
import co.sprint1.wp.util.common.LogUtil;
import java.io.IOException;
import java.util.HashMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class DialogFlowWebhookResource
{

    public DialogFlowWebhookResource()
    {
        logger = LogManager.getLogger(getClass().getName());
    }

    public String broadcastMessage(AIFulfilmentRequest request)
        throws IOException
    {
        LogUtil.logJsonObject(co/sprint1/wp/model/dialogflow/AIFulfilmentRequest, "Webhook Invoked with Message :", request);
        if(request != null && request.getQueryResult() != null && request.getQueryResult().getAction() != null)
        {
            String actionName = request.getQueryResult().getAction();
            HashMap params = request.getQueryResult().getParameters();
            if(actionName != null && "RRSP.createLead".equalsIgnoreCase(actionName) && request.getQueryResult().getAllRequiredParamsPresent().booleanValue())
            {
                String phnNumber = params.get("number").toString();
                salesForceHelper.createLead("Tarun", "Mittal", phnNumber);
            }
        }
        return "success";
    }

    public String verifyFBToken(String mode, String verifyToken, String challenge)
    {
        logger.debug("Received Verification Request");
        if("subscribe".equalsIgnoreCase(mode) && "hitch-bot-token".equalsIgnoreCase(verifyToken))
            return challenge;
        else
            return "";
    }

    Logger logger;
    SalesForceHelper salesForceHelper;
}
