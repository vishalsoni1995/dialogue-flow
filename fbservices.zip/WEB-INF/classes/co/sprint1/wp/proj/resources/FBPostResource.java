// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   FBPostResource.java

package co.sprint1.wp.resources;

import co.sprint1.wp.helper.FBPagePostHelper;
import co.sprint1.wp.model.ro.BroadcastMessageRequest;
import java.io.IOException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class FBPostResource
{

    public FBPostResource()
    {
        logger = LogManager.getLogger(getClass().getName());
    }

    public String postMessage(BroadcastMessageRequest request)
        throws IOException
    {
        Long bcId = null;
        if(request != null)
            fBPagePostHelper.postMessage(request);
        return (new StringBuilder()).append("Success : ").append(bcId).toString();
    }

    Logger logger;
    FBPagePostHelper fBPagePostHelper;
}
