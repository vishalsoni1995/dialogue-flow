// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ServletInitializer.java

package co.sprint1.wp;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

// Referenced classes of package co.sprint1.wp:
//            FBResourceApplication

public class ServletInitializer extends SpringBootServletInitializer
{

    public ServletInitializer()
    {
    }

    protected SpringApplicationBuilder configure(SpringApplicationBuilder application)
    {
        return application.sources(new Class[] {
            co/sprint1/wp/FBResourceApplication
        });
    }

    public void onStartup(ServletContext servletContext)
        throws ServletException
    {
        super.onStartup(servletContext);
    }
}
