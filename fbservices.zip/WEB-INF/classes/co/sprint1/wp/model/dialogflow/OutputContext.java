// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   OutputContext.java

package co.sprint1.wp.model.dialogflow;

import java.io.Serializable;
import java.util.Map;

public class OutputContext
    implements Serializable
{

    public OutputContext()
    {
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public Map getParameters()
    {
        return parameters;
    }

    public void setParameters(Map parameters)
    {
        this.parameters = parameters;
    }

    public Integer getLifespanCount()
    {
        return lifespanCount;
    }

    public void setLifespanCount(Integer lifespanCount)
    {
        this.lifespanCount = lifespanCount;
    }

    private String name;
    private Map parameters;
    private Integer lifespanCount;
    private static final long serialVersionUID = 1L;
}
