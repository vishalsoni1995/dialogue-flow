// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   OriginalRequest.java

package co.sprint1.wp.model.dialogflow;

import java.io.Serializable;

public class OriginalRequest
    implements Serializable
{

    public OriginalRequest()
    {
    }

    public Object getPayload()
    {
        return payload;
    }

    public void setPayload(Object payload)
    {
        this.payload = payload;
    }

    private static final long serialVersionUID = 1L;
    private Object payload;
}
