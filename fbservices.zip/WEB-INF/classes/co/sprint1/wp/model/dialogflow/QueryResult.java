// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   QueryResult.java

package co.sprint1.wp.model.dialogflow;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

// Referenced classes of package co.sprint1.wp.model.dialogflow:
//            Intent

public class QueryResult
    implements Serializable
{

    public QueryResult()
    {
    }

    public String getQueryText()
    {
        return queryText;
    }

    public void setQueryText(String queryText)
    {
        this.queryText = queryText;
    }

    public String getAction()
    {
        return action;
    }

    public void setAction(String action)
    {
        this.action = action;
    }

    public String getLanguageCode()
    {
        return languageCode;
    }

    public void setLanguageCode(String languageCode)
    {
        this.languageCode = languageCode;
    }

    public Long getIntentDetectionConfidence()
    {
        return intentDetectionConfidence;
    }

    public void setIntentDetectionConfidence(Long intentDetectionConfidence)
    {
        this.intentDetectionConfidence = intentDetectionConfidence;
    }

    public HashMap getParameters()
    {
        return parameters;
    }

    public void setParameters(HashMap parameters)
    {
        this.parameters = parameters;
    }

    public Boolean getAllRequiredParamsPresent()
    {
        return allRequiredParamsPresent;
    }

    public void setAllRequiredParamsPresent(Boolean allRequiredParamsPresent)
    {
        this.allRequiredParamsPresent = allRequiredParamsPresent;
    }

    public List getFulfillmentMessages()
    {
        return fulfillmentMessages;
    }

    public void setFulfillmentMessages(List fulfillmentMessages)
    {
        this.fulfillmentMessages = fulfillmentMessages;
    }

    public List getOutputContexts()
    {
        return outputContexts;
    }

    public void setOutputContexts(List outputContexts)
    {
        this.outputContexts = outputContexts;
    }

    public Intent getIntent()
    {
        return intent;
    }

    public void setIntent(Intent intent)
    {
        this.intent = intent;
    }

    private static final long serialVersionUID = 1L;
    private String queryText;
    private String action;
    private String languageCode;
    private Long intentDetectionConfidence;
    private HashMap parameters;
    private Boolean allRequiredParamsPresent;
    private List fulfillmentMessages;
    private List outputContexts;
    private Intent intent;
}
