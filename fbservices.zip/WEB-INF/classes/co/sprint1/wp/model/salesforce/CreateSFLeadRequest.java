// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CreateSFLeadRequest.java

package co.sprint1.wp.model.salesforce;

import java.io.Serializable;

public class CreateSFLeadRequest
    implements Serializable
{

    public CreateSFLeadRequest()
    {
    }

    public String getLastName()
    {
        return LastName;
    }

    public void setLastName(String lastName)
    {
        LastName = lastName;
    }

    public String getFirstName()
    {
        return FirstName;
    }

    public void setFirstName(String firstName)
    {
        FirstName = firstName;
    }

    public String getCompany()
    {
        return Company;
    }

    public void setCompany(String company)
    {
        Company = company;
    }

    public String getOwnerId()
    {
        return OwnerId;
    }

    public void setOwnerId(String ownerId)
    {
        OwnerId = ownerId;
    }

    public String getEmail()
    {
        return Email;
    }

    public void setEmail(String email)
    {
        Email = email;
    }

    public String getProductInterest()
    {
        return ProductInterest;
    }

    public void setProductInterest(String productInterest)
    {
        ProductInterest = productInterest;
    }

    public String getMobilePhone()
    {
        return MobilePhone;
    }

    public void setMobilePhone(String i)
    {
        MobilePhone = i;
    }

    private static final long serialVersionUID = 1L;
    private String LastName;
    private String FirstName;
    private String Company;
    private String OwnerId;
    private String MobilePhone;
    private String Email;
    private String ProductInterest;
}
