// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Recipient.java

package co.sprint1.wp.model.fb;

import java.util.Objects;

public final class Recipient
{

    public String getId()
    {
        return id;
    }

    public String getPhoneNumber()
    {
        return phoneNumber;
    }

    public boolean equals(Object o)
    {
        if(this == o)
            return true;
        if(o == null || getClass() != o.getClass())
        {
            return false;
        } else
        {
            Recipient recipient = (Recipient)o;
            return Objects.equals(id, recipient.id) && Objects.equals(phoneNumber, recipient.phoneNumber);
        }
    }

    public int hashCode()
    {
        return Objects.hash(new Object[] {
            id, phoneNumber
        });
    }

    public String toString()
    {
        return (new StringBuilder()).append("Recipient{id='").append(id).append('\'').append(", phoneNumber='").append(phoneNumber).append('\'').append('}').toString();
    }

    public Recipient(String id, String phoneNumber)
    {
        this.id = id;
        this.phoneNumber = phoneNumber;
    }

    private final String id;
    private final String phoneNumber;
}
