// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   BroadcastMessageResponse.java

package co.sprint1.wp.model.fb.ro;


public class BroadcastMessageResponse
{

    public BroadcastMessageResponse()
    {
    }

    public Long getBroadcast_id()
    {
        return broadcast_id;
    }

    public void setBroadcast_id(Long broadcast_id)
    {
        this.broadcast_id = broadcast_id;
    }

    private Long broadcast_id;
}
