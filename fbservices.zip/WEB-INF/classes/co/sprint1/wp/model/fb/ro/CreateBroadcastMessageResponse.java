// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CreateBroadcastMessageResponse.java

package co.sprint1.wp.model.fb.ro;


public class CreateBroadcastMessageResponse
{

    public CreateBroadcastMessageResponse()
    {
    }

    public Long getMessage_creative_id()
    {
        return message_creative_id;
    }

    public void setMessage_creative_id(Long message_creative_id)
    {
        this.message_creative_id = message_creative_id;
    }

    private Long message_creative_id;
}
