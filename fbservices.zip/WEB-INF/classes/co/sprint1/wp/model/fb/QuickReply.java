// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   QuickReply.java

package co.sprint1.wp.model.fb;

import java.util.Objects;

public class QuickReply
{
    public static final class ContentType extends Enum
    {

        public static ContentType[] values()
        {
            return (ContentType[])$VALUES.clone();
        }

        public static ContentType valueOf(String name)
        {
            return (ContentType)Enum.valueOf(co/sprint1/wp/model/fb/QuickReply$ContentType, name);
        }

        public static final ContentType TEXT;
        public static final ContentType LOCATION;
        private static final ContentType $VALUES[];

        static 
        {
            TEXT = new ContentType("TEXT", 0);
            LOCATION = new ContentType("LOCATION", 1);
            $VALUES = (new ContentType[] {
                TEXT, LOCATION
            });
        }

        private ContentType(String s, int i)
        {
            super(s, i);
        }
    }


    public QuickReply(ContentType contentType, String title, String payload, String imageUrl)
    {
        content_type = contentType;
        this.title = title;
        this.payload = payload;
        this.imageUrl = imageUrl;
    }

    public ContentType getContentType()
    {
        return content_type;
    }

    public String getTitle()
    {
        return title;
    }

    public String getPayload()
    {
        return payload;
    }

    public String getImageUrl()
    {
        return imageUrl;
    }

    public boolean equals(Object o)
    {
        if(this == o)
            return true;
        if(o == null || getClass() != o.getClass())
        {
            return false;
        } else
        {
            QuickReply that = (QuickReply)o;
            return content_type == that.content_type && Objects.equals(title, that.title) && Objects.equals(payload, that.payload) && Objects.equals(imageUrl, that.imageUrl);
        }
    }

    public int hashCode()
    {
        return Objects.hash(new Object[] {
            content_type, title, payload, imageUrl
        });
    }

    public String toString()
    {
        return (new StringBuilder()).append("QuickReply{contentType=").append(content_type).append(", title='").append(title).append('\'').append(", payload='").append(payload).append('\'').append(", imageUrl='").append(imageUrl).append('\'').append('}').toString();
    }

    private ContentType content_type;
    private String title;
    private String payload;
    private String imageUrl;
}
