// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SenderAction.java

package co.sprint1.wp.model.fb;


public final class SenderAction extends Enum
{

    public static SenderAction[] values()
    {
        return (SenderAction[])$VALUES.clone();
    }

    public static SenderAction valueOf(String name)
    {
        return (SenderAction)Enum.valueOf(co/sprint1/wp/model/fb/SenderAction, name);
    }

    private SenderAction(String s, int i)
    {
        super(s, i);
    }

    public static final SenderAction MARK_SEEN;
    public static final SenderAction TYPING_ON;
    public static final SenderAction TYPING_OFF;
    private static final SenderAction $VALUES[];

    static 
    {
        MARK_SEEN = new SenderAction("MARK_SEEN", 0);
        TYPING_ON = new SenderAction("TYPING_ON", 1);
        TYPING_OFF = new SenderAction("TYPING_OFF", 2);
        $VALUES = (new SenderAction[] {
            MARK_SEEN, TYPING_ON, TYPING_OFF
        });
    }
}
