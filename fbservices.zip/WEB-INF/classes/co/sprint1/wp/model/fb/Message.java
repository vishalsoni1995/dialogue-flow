// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Message.java

package co.sprint1.wp.model.fb;

import java.util.List;
import java.util.Objects;

public final class Message
{

    public Message(String text, String attachment, List quickReplies, String metadata)
    {
        this.text = text;
        this.attachment = attachment;
        quick_replies = quickReplies;
        this.metadata = metadata;
    }

    public String getText()
    {
        return text;
    }

    public String getAttachment()
    {
        return attachment;
    }

    public List getQuickReplies()
    {
        return quick_replies;
    }

    public String getMetadata()
    {
        return metadata;
    }

    public boolean equals(Object o)
    {
        if(this == o)
            return true;
        if(o == null || getClass() != o.getClass())
        {
            return false;
        } else
        {
            Message message = (Message)o;
            return Objects.equals(text, message.text) && Objects.equals(attachment, message.attachment) && Objects.equals(quick_replies, message.quick_replies) && Objects.equals(metadata, message.metadata);
        }
    }

    public int hashCode()
    {
        return Objects.hash(new Object[] {
            text, attachment, quick_replies, metadata
        });
    }

    public String toString()
    {
        return (new StringBuilder()).append("Message{text='").append(text).append('\'').append(", attachment=").append(attachment).append(", quickReplies=").append(quick_replies).append(", metadata='").append(metadata).append('\'').append('}').toString();
    }

    private final String text;
    private final String attachment;
    private final List quick_replies;
    private final String metadata;
}
