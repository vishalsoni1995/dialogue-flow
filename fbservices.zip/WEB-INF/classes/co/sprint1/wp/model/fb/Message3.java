// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Message3.java

package co.sprint1.wp.model.fb;


// Referenced classes of package co.sprint1.wp.model.fb:
//            Attachment

public class Message3
{

    public Message3()
    {
    }

    public Attachment getAttachment()
    {
        return attachment;
    }

    public void setAttachment(Attachment attachment)
    {
        this.attachment = attachment;
    }

    private Attachment attachment;
}
