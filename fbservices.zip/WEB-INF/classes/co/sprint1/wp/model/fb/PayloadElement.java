// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PayloadElement.java

package co.sprint1.wp.model.fb;

import java.util.List;

public class PayloadElement
{

    public PayloadElement()
    {
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public String getImage_url()
    {
        return image_url;
    }

    public void setImage_url(String image_url)
    {
        this.image_url = image_url;
    }

    public String getSubtitle()
    {
        return subtitle;
    }

    public void setSubtitle(String subtitle)
    {
        this.subtitle = subtitle;
    }

    public List getButtons()
    {
        return buttons;
    }

    public void setButtons(List buttons)
    {
        this.buttons = buttons;
    }

    private String title;
    private String image_url;
    private String subtitle;
    private List buttons;
}
