// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Attachment.java

package co.sprint1.wp.model.fb;


// Referenced classes of package co.sprint1.wp.model.fb:
//            Payload

public class Attachment
{

    public Attachment()
    {
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public String getURL()
    {
        return URL;
    }

    public void setURL(String uRL)
    {
        URL = uRL;
    }

    public String getType()
    {
        return type;
    }

    public void setType(String type)
    {
        this.type = type;
    }

    public Payload getPayload()
    {
        return payload;
    }

    public void setPayload(Payload payload)
    {
        this.payload = payload;
    }

    public String toString()
    {
        return (new StringBuilder()).append("Attachment [title=").append(title).append(", URL=").append(URL).append(", type=").append(type).append(", payload=").append(payload).append("]").toString();
    }

    private String title;
    private String URL;
    private String type;
    private Payload payload;
}
