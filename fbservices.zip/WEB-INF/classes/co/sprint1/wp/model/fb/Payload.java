// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Payload.java

package co.sprint1.wp.model.fb;

import java.util.List;

public class Payload
{

    public Payload()
    {
    }

    public String getTemplate_type()
    {
        return template_type;
    }

    public void setTemplate_type(String template_type)
    {
        this.template_type = template_type;
    }

    public List getElements()
    {
        return elements;
    }

    public void setElements(List elements)
    {
        this.elements = elements;
    }

    private String template_type;
    private List elements;
}
