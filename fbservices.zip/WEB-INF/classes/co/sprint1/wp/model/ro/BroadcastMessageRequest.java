// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   BroadcastMessageRequest.java

package co.sprint1.wp.model.ro;

import java.io.Serializable;

public class BroadcastMessageRequest
    implements Serializable
{

    public BroadcastMessageRequest()
    {
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public String getImage_url()
    {
        return image_url;
    }

    public void setImage_url(String image_url)
    {
        this.image_url = image_url;
    }

    public String getSubtitle()
    {
        return subtitle;
    }

    public void setSubtitle(String subtitle)
    {
        this.subtitle = subtitle;
    }

    public String getButton_title()
    {
        return button_title;
    }

    public void setButton_title(String button_title)
    {
        this.button_title = button_title;
    }

    public String getUrl()
    {
        return url;
    }

    public void setUrl(String url)
    {
        this.url = url;
    }

    private static final long serialVersionUID = 1L;
    private String title;
    private String image_url;
    private String subtitle;
    private String button_title;
    private String url;
}
