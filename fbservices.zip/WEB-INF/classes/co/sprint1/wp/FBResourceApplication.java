// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   FBResourceApplication.java

package co.sprint1.wp;

import org.springframework.boot.SpringApplication;

public class FBResourceApplication
{

    public FBResourceApplication()
    {
    }

    public static void main(String args[])
    {
        SpringApplication.run(co/sprint1/wp/FBResourceApplication, args);
    }
}
