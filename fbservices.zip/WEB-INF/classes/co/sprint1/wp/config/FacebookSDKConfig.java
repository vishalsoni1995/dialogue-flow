// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   FacebookSDKConfig.java

package co.sprint1.wp.config;

import com.facebook.ads.sdk.*;
import java.io.PrintStream;
import java.util.Iterator;

public class FacebookSDKConfig
{

    public FacebookSDKConfig()
    {
    }

    public AdAccount fbAddAccount()
        throws Exception
    {
        AdAccount account = new AdAccount("your-adaccount-id", context);
        APINodeList campaigns = account.getCampaigns().requestAllFields().execute();
        Campaign campaign;
        for(Iterator iterator = campaigns.iterator(); iterator.hasNext(); System.out.println(campaign.getFieldName()))
            campaign = (Campaign)iterator.next();

        return account;
    }

    public final APIContext context = new APIContext("your-access-token", "9831fb7d1358f32d96648a1866e2e40d");
}
