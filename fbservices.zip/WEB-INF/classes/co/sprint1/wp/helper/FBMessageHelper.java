// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   FBMessageHelper.java

package co.sprint1.wp.helper;

import co.sprint1.wp.model.fb.*;
import co.sprint1.wp.util.common.HttpClient;
import com.google.gson.Gson;
import java.io.IOException;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class FBMessageHelper
{

    public FBMessageHelper()
    {
        logger = LogManager.getLogger(getClass().getName());
        pageAccessToken = "EAAYKmt3XyFYBAGCZCvTgG3G16cB4MnLh50IDHh9bKVit1dP99tZA4tkin8N1JP5uF41oo00ZBZBajDlZClXnhE6JbMYRxEpxqIBsDvZCxmALpvZBTSF9FsJe8KrC7D2ZCrQNzSJZByCXz9pp8OxTqSBmAHrU6zT6466ELcLjBeeoQgnDh6YZCvIWVBVAi71lORatYZD";
        requestUrl = String.format("https://graph.facebook.com/v2.11/me/messages?access_token=%s", new Object[] {
            pageAccessToken
        });
        gson = new Gson();
    }

    public void sendTextMessage(String recipientId, String text, List quickList)
        throws IOException
    {
        if(recipientId != null && !recipientId.equals(""))
        {
            logger.debug(recipientId);
            Recipient recipient = new Recipient(recipientId, null);
            Message message = new Message(text, null, quickList, null);
            MessagingResponse response = new MessagingResponse(recipient, NotificationType.REGULAR, message, null);
            doRequest(co.sprint1.wp.util.common.HttpClient.HttpMethod.POST, response);
        }
    }

    private void doRequest(co.sprint1.wp.util.common.HttpClient.HttpMethod method, MessagingResponse response)
        throws IOException
    {
        String jsonBody = response != null ? gson.toJson(response) : null;
        logger.debug((new StringBuilder()).append("FB Send Message URL ::").append(requestUrl).append("Body :: ").append(jsonBody).toString());
        co.sprint1.wp.util.common.HttpClient.HttpResponse httpResponse = HttpClient.execute(method, requestUrl, jsonBody);
        logger.debug((new StringBuilder()).append("Message Post Response :").append(httpResponse.getStatusCode()).append(" , ").append(httpResponse.getBody()).toString());
    }

    Logger logger;
    private static final String FB_GRAPH_API_URL = "https://graph.facebook.com/v2.11/me/messages?access_token=%s";
    String pageAccessToken;
    String requestUrl;
    Gson gson;
}
