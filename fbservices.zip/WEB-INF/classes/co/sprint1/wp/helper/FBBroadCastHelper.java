// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   FBBroadCastHelper.java

package co.sprint1.wp.helper;

import co.sprint1.wp.model.fb.NotificationType;
import co.sprint1.wp.model.fb.ro.*;
import co.sprint1.wp.util.common.HttpClient;
import com.google.gson.Gson;
import java.io.IOException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class FBBroadCastHelper
{

    public FBBroadCastHelper()
    {
        logger = LogManager.getLogger(getClass().getName());
        pageAccessToken = "EAAYKmt3XyFYBAGCZCvTgG3G16cB4MnLh50IDHh9bKVit1dP99tZA4tkin8N1JP5uF41oo00ZBZBajDlZClXnhE6JbMYRxEpxqIBsDvZCxmALpvZBTSF9FsJe8KrC7D2ZCrQNzSJZByCXz9pp8OxTqSBmAHrU6zT6466ELcLjBeeoQgnDh6YZCvIWVBVAi71lORatYZD";
        gson = new Gson();
    }

    public Long createBroadcastMessage(CreateBroadcastMessageRequest request)
        throws IOException
    {
        CreateBroadcastMessageResponse resp = null;
        String requestUrl = String.format("https://graph.facebook.com/v2.11/me/message_creatives?access_token=%s", new Object[] {
            pageAccessToken
        });
        String response = doRequest(co.sprint1.wp.util.common.HttpClient.HttpMethod.POST, requestUrl, request);
        if(!"".equals(response))
            resp = (CreateBroadcastMessageResponse)gson.fromJson(response, co/sprint1/wp/model/fb/ro/CreateBroadcastMessageResponse);
        if(resp != null && resp.getMessage_creative_id() != null)
            return resp.getMessage_creative_id();
        else
            return null;
    }

    public Long sendBroadcast(Long creativeMessageId)
        throws IOException
    {
        BroadcastMessageResponse resp = null;
        BroadcastMessageRequest request = new BroadcastMessageRequest();
        request.setMessage_creative_id(creativeMessageId);
        request.setMessaging_type("MESSAGE_TAG");
        request.setNotification_type(NotificationType.SILENT_PUSH.toString());
        request.setTag("NON_PROMOTIONAL_SUBSCRIPTION");
        String requestUrl = String.format("https://graph.facebook.com/v2.11/me/broadcast_messages?access_token=%s", new Object[] {
            pageAccessToken
        });
        String response = doRequest(co.sprint1.wp.util.common.HttpClient.HttpMethod.POST, requestUrl, request);
        if(!"".equals(response))
            resp = (BroadcastMessageResponse)gson.fromJson(response, co/sprint1/wp/model/fb/ro/BroadcastMessageResponse);
        if(resp != null && resp.getBroadcast_id() != null)
            return resp.getBroadcast_id();
        else
            return null;
    }

    private String doRequest(co.sprint1.wp.util.common.HttpClient.HttpMethod method, String requestURL, Object request)
        throws IOException
    {
        String jsonBody = request != null ? gson.toJson(request) : null;
        logger.info((new StringBuilder()).append("Request Path :").append(requestURL).toString());
        logger.info((new StringBuilder()).append("Request Body :").append(jsonBody).toString());
        co.sprint1.wp.util.common.HttpClient.HttpResponse httpResponse = HttpClient.execute(method, requestURL, jsonBody);
        logger.info((new StringBuilder()).append("Response ").append(httpResponse.getStatusCode()).append("::").append(httpResponse.getBody()).toString());
        return httpResponse.getBody();
    }

    Logger logger;
    private static final String FB_CREATEMESSAGE_API_URL = "https://graph.facebook.com/v2.11/me/message_creatives?access_token=%s";
    private static final String FB_BROADCASTMESSAGE_API_URL = "https://graph.facebook.com/v2.11/me/broadcast_messages?access_token=%s";
    String pageAccessToken;
    Gson gson;
}
