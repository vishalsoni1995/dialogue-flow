// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SalesForceHelper.java

package co.sprint1.wp.helper;

import co.sprint1.wp.model.salesforce.CreateSFLeadRequest;
import co.sprint1.wp.model.salesforce.SFAuthResponse;
import co.sprint1.wp.util.common.HttpClient;
import com.google.gson.Gson;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class SalesForceHelper
{

    public SalesForceHelper()
    {
        logger = LogManager.getLogger(getClass().getName());
        gson = new Gson();
        SF_LEAD_URL = "https://gang84-dev-ed.my.salesforce.com/services/data/v43.0/sobjects/lead";
        SF_TOKEN_URL = "https://login.salesforce.com/services/oauth2/token";
    }

    public void createLead(String firstName, String lastName, String phoneNum)
        throws IOException
    {
        String accessToken = getToken();
        CreateSFLeadRequest request = new CreateSFLeadRequest();
        request.setFirstName(firstName);
        request.setLastName(lastName);
        request.setOwnerId("00528000005zvCw");
        request.setCompany("Sunlife");
        request.setMobilePhone(phoneNum);
        request.setEmail("tarun.mttl@gmail.com");
        String requestUrl = SF_LEAD_URL;
        if(accessToken != null)
            doRequest(co.sprint1.wp.util.common.HttpClient.HttpMethod.POST, accessToken, requestUrl, request);
    }

    private String getToken()
        throws IOException
    {
        HashMap requestParam = new HashMap();
        SFAuthResponse resp = null;
        requestParam.put("grant_type", "password");
        requestParam.put("client_id", "3MVG9ZL0ppGP5UrA4vDkZZM0gtKH9nxtwe8yvDAZDcxp4eVjcOvrq6FIdGA5JUNIm0zozB_sRk_Gcj2Jx.ZUG");
        requestParam.put("username", "gurdeep.singh@sunlife.com");
        requestParam.put("password", "Nano!1234KlQXaGA72Z73jLBpHnRY7VI5X");
        requestParam.put("client_secret", "3045587621930745632");
        String response = doRequest(co.sprint1.wp.util.common.HttpClient.HttpMethod.POST, SF_TOKEN_URL, requestParam);
        if(!"".equals(response))
            resp = (SFAuthResponse)gson.fromJson(response, co/sprint1/wp/model/salesforce/SFAuthResponse);
        if(resp != null && resp.getAccess_token() != null)
            return resp.getAccess_token();
        else
            return null;
    }

    private String doRequest(co.sprint1.wp.util.common.HttpClient.HttpMethod method, String requestURL, HashMap request)
        throws IOException
    {
        logger.info((new StringBuilder()).append("Request Path :").append(requestURL).toString());
        String jsonBody = null;
        if(request != null)
        {
            jsonBody = request != null ? gson.toJson(request) : "";
            logger.info((new StringBuilder()).append("Request Body :").append(jsonBody).toString());
        }
        co.sprint1.wp.util.common.HttpClient.HttpResponse httpResponse = HttpClient.executeFormPost(method, requestURL, new HashMap(), request);
        logger.info((new StringBuilder()).append("Response ").append(httpResponse.getStatusCode()).append("::").append(httpResponse.getBody()).toString());
        return httpResponse.getBody();
    }

    private String doRequest(co.sprint1.wp.util.common.HttpClient.HttpMethod method, String accesToken, String requestURL, Object request)
        throws IOException
    {
        String jsonBody = request != null ? gson.toJson(request) : null;
        logger.info((new StringBuilder()).append("Request Path :").append(requestURL).toString());
        logger.info((new StringBuilder()).append("Request Body :").append(jsonBody).toString());
        Map headers = new HashMap();
        headers.put("Authorization", (new StringBuilder()).append("Bearer ").append(accesToken).toString());
        headers.put("Content-Type", "application/json");
        co.sprint1.wp.util.common.HttpClient.HttpResponse httpResponse = HttpClient.execute(method, requestURL, headers, jsonBody);
        logger.info((new StringBuilder()).append("Response ").append(httpResponse.getStatusCode()).append("::").append(httpResponse.getBody()).toString());
        return httpResponse.getBody();
    }

    Logger logger;
    Gson gson;
    private String SF_LEAD_URL;
    private String SF_TOKEN_URL;
}
