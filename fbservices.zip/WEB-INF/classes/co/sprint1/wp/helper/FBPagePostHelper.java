// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   FBPagePostHelper.java

package co.sprint1.wp.helper;

import co.sprint1.wp.model.fb.ro.CreateBroadcastMessageResponse;
import co.sprint1.wp.model.ro.BroadcastMessageRequest;
import co.sprint1.wp.util.common.HttpClient;
import com.google.gson.Gson;
import java.io.IOException;
import java.util.HashMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class FBPagePostHelper
{

    public FBPagePostHelper()
    {
        logger = LogManager.getLogger(getClass().getName());
        pageAccessToken = "EAAEfCw2N26YBACA734sm8wok73wZAuDqbMXbz6gf6ZCSDVVJQhDZCMhXWXH3veK91V3j5NfKEdgZCxHY5NBtDip7sNc46FpRUWpDKHuNrgPekwhIZCZCRcIT6Wgbh3vTYZCDSGR9FlM7jnqyefBGUDc7txxrYvpTH1zVUWKpI13uwZDZD";
        gson = new Gson();
    }

    public Long postMessage(BroadcastMessageRequest request)
        throws IOException
    {
        CreateBroadcastMessageResponse resp = null;
        HashMap requestBody = new HashMap();
        requestBody.put("access_token", pageAccessToken);
        String requestUrl = String.format("https://graph.facebook.com/v2.11/671379429907093/feed", new Object[] {
            pageAccessToken
        });
        if(!"".equals(request.getImage_url()))
            requestBody.put("link", request.getImage_url());
        if(!"".equals(request.getSubtitle()))
            requestBody.put("message", request.getSubtitle());
        String response = doRequest(co.sprint1.wp.util.common.HttpClient.HttpMethod.POST, requestUrl, requestBody);
        if(!"".equals(response))
            resp = (CreateBroadcastMessageResponse)gson.fromJson(response, co/sprint1/wp/model/fb/ro/CreateBroadcastMessageResponse);
        if(resp != null && resp.getMessage_creative_id() != null)
            return resp.getMessage_creative_id();
        else
            return null;
    }

    private String doRequest(co.sprint1.wp.util.common.HttpClient.HttpMethod method, String requestURL, HashMap request)
        throws IOException
    {
        logger.info((new StringBuilder()).append("Request Path :").append(requestURL).toString());
        String jsonBody = null;
        if(request != null)
        {
            jsonBody = request != null ? gson.toJson(request) : "";
            logger.info((new StringBuilder()).append("Request Body :").append(jsonBody).toString());
        }
        co.sprint1.wp.util.common.HttpClient.HttpResponse httpResponse = HttpClient.executeFormPost(method, requestURL, new HashMap(), request);
        logger.info((new StringBuilder()).append("Response ").append(httpResponse.getStatusCode()).append("::").append(httpResponse.getBody()).toString());
        return httpResponse.getBody();
    }

    Logger logger;
    private static final String FB_PAGE_POST_API_URL = "https://graph.facebook.com/v2.11/671379429907093/feed";
    String pageAccessToken;
    Gson gson;
}
