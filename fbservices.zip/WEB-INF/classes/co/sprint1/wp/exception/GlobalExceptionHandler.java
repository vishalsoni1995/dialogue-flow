// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   GlobalExceptionHandler.java

package co.sprint1.wp.exception;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.*;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

// Referenced classes of package co.sprint1.wp.exception:
//            AuthenticationException, ExceptionResponse

public class GlobalExceptionHandler extends ResponseEntityExceptionHandler
{

    public GlobalExceptionHandler()
    {
        logger = LogManager.getLogger(getClass().getName());
    }

    protected ResponseEntity handleUnhandledException(AuthenticationException ex, WebRequest request)
    {
        logger.info((new StringBuilder()).append("Validate Pin Authentication Exception ").append(ex.getErrorStatus()).append(ex.getErrorMessage()).toString());
        if(ExceptionResponse.resolve(ex.getErrorStatus()) != null)
            return new ResponseEntity(ExceptionResponse.resolve(ex.getErrorStatus()), HttpStatus.UNAUTHORIZED);
        else
            return new ResponseEntity(ex, HttpStatus.UNAUTHORIZED);
    }

    protected ResponseEntity handleUnhandledException(Exception ex, WebRequest request)
    {
        logger.error(ex);
        logger.error(ex.getStackTrace());
        ex.printStackTrace();
        return handleExceptionInternal(ex, ExceptionResponse.UNHANDLED_EXCEPTION, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
    }

    Logger logger;
}
