// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ExceptionResponse.java

package co.sprint1.wp.exception;


public final class ExceptionResponse extends Enum
{

    public static ExceptionResponse[] values()
    {
        return (ExceptionResponse[])$VALUES.clone();
    }

    public static ExceptionResponse valueOf(String name)
    {
        return (ExceptionResponse)Enum.valueOf(co/sprint1/wp/exception/ExceptionResponse, name);
    }

    private ExceptionResponse(String s, int i, String errorCode, String errorMessage)
    {
        super(s, i);
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    public String getErrorCode()
    {
        return errorCode;
    }

    public String getErrorMessage()
    {
        return errorMessage;
    }

    public static ExceptionResponse resolve(String errorCode)
    {
        ExceptionResponse aexceptionresponse[] = values();
        int i = aexceptionresponse.length;
        for(int j = 0; j < i; j++)
        {
            ExceptionResponse error = aexceptionresponse[j];
            if(error.errorCode == errorCode)
                return error;
        }

        return null;
    }

    public static final ExceptionResponse UNHANDLED_EXCEPTION;
    public static final ExceptionResponse SLSC0006;
    private final String errorCode;
    private final String errorMessage;
    private static final ExceptionResponse $VALUES[];

    static 
    {
        UNHANDLED_EXCEPTION = new ExceptionResponse("UNHANDLED_EXCEPTION", 0, "521", "EXCEPTION_UNHANDLED");
        SLSC0006 = new ExceptionResponse("SLSC0006", 1, "SLSC0006", "");
        $VALUES = (new ExceptionResponse[] {
            UNHANDLED_EXCEPTION, SLSC0006
        });
    }
}
