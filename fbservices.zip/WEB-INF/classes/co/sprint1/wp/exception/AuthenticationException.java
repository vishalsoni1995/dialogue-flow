// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AuthenticationException.java

package co.sprint1.wp.exception;


public class AuthenticationException extends Exception
{

    public String getErrorStatus()
    {
        return errorStatus;
    }

    public void setErrorStatus(String errorStatus)
    {
        this.errorStatus = errorStatus;
    }

    public String getErrorMessage()
    {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage)
    {
        this.errorMessage = errorMessage;
    }

    public AuthenticationException()
    {
    }

    public AuthenticationException(String sts, String msg)
    {
        errorStatus = sts;
        setErrorMessage(msg);
    }

    private static final long serialVersionUID = 1L;
    private String errorStatus;
    private String errorMessage;
}
