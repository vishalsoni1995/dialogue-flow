// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SunLifeException.java

package co.sprint1.wp.exception;


public class SunLifeException extends Exception
{

    public String getErrorStatus()
    {
        return errorStatus;
    }

    public void setErrorStatus(String errorStatus)
    {
        this.errorStatus = errorStatus;
    }

    public String getErrorResponse()
    {
        return errorResponse;
    }

    public void setErrorResponse(String errorResponse)
    {
        this.errorResponse = errorResponse;
    }

    public SunLifeException()
    {
    }

    public SunLifeException(String sts, String msg)
    {
        errorStatus = sts;
        errorResponse = msg;
    }

    public SunLifeException(String message)
    {
        super(message);
    }

    public SunLifeException(Throwable cause)
    {
        super(cause);
    }

    public SunLifeException(String message, Throwable cause)
    {
        super(message, cause);
    }

    public SunLifeException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace)
    {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    private static final long serialVersionUID = 1L;
    private String errorStatus;
    private String errorResponse;
}
