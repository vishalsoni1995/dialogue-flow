// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Stockticker.java

package async;

import java.text.DecimalFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class Stockticker
    implements Runnable
{
    public static final class Stock
        implements Cloneable
    {

        public void setCnt(int c)
        {
            cnt = c;
        }

        public int getCnt()
        {
            return cnt;
        }

        public String getSymbol()
        {
            return symbol;
        }

        public double getValue()
        {
            return value;
        }

        public void setValue(double value)
        {
            double old = this.value;
            this.value = value;
            lastchange = value - old;
        }

        public String getValueAsString()
        {
            return df.format(value);
        }

        public double getLastChange()
        {
            return lastchange;
        }

        public void setLastChange(double lastchange)
        {
            this.lastchange = lastchange;
        }

        public String getLastChangeAsString()
        {
            return df.format(lastchange);
        }

        public int hashCode()
        {
            return symbol.hashCode();
        }

        public boolean equals(Object other)
        {
            if(other instanceof Stock)
                return symbol.equals(((Stock)other).symbol);
            else
                return false;
        }

        public String toString()
        {
            StringBuilder buf = new StringBuilder("STOCK#");
            buf.append(getSymbol());
            buf.append("#");
            buf.append(getValueAsString());
            buf.append("#");
            buf.append(getLastChangeAsString());
            buf.append("#");
            buf.append(String.valueOf(getCnt()));
            return buf.toString();
        }

        public Object clone()
        {
            Stock s = new Stock(getSymbol(), getValue());
            s.setLastChange(getLastChange());
            s.setCnt(cnt);
            return s;
        }

        protected static DecimalFormat df = new DecimalFormat("0.00");
        protected String symbol;
        protected double value;
        protected double lastchange;
        protected int cnt;


        public Stock(String symbol, double initvalue)
        {
            this.symbol = "";
            value = 0.0D;
            lastchange = 0.0D;
            cnt = 0;
            this.symbol = symbol;
            value = initvalue;
        }
    }

    public static interface TickListener
    {

        public abstract void tick(Stock stock);
    }


    public Stockticker()
    {
        run = true;
        counter = new AtomicInteger(0);
        listeners = new ArrayList();
        ticker = null;
        ticknr = 0;
    }

    public synchronized void start()
    {
        run = true;
        ticker = new Thread(this);
        ticker.setName("Ticker Thread");
        ticker.start();
    }

    public synchronized void stop()
    {
        run = false;
        try
        {
            ticker.join();
        }
        catch(InterruptedException x)
        {
            Thread.interrupted();
        }
        ticker = null;
    }

    public void addTickListener(TickListener listener)
    {
        if(listeners.add(listener) && counter.incrementAndGet() == 1)
            start();
    }

    public void removeTickListener(TickListener listener)
    {
        if(listeners.remove(listener) && counter.decrementAndGet() == 0)
            stop();
    }

    public void run()
    {
        try
        {
            Stock stocks[] = {
                new Stock("GOOG", 435.43000000000001D), new Stock("YHOO", 27.879999999999999D), new Stock("ASF", 1015.55D)
            };
            Random r = new Random(System.currentTimeMillis());
            while(run) 
            {
                for(int j = 0; j < 1; j++)
                {
                    int i = r.nextInt() % 3;
                    if(i < 0)
                        i *= -1;
                    Stock stock = stocks[i];
                    double change = r.nextDouble();
                    boolean plus = r.nextBoolean();
                    if(plus)
                        stock.setValue(stock.getValue() + change);
                    else
                        stock.setValue(stock.getValue() - change);
                    stock.setCnt(++ticknr);
                    TickListener l;
                    for(Iterator i$ = listeners.iterator(); i$.hasNext(); l.tick(stock))
                        l = (TickListener)i$.next();

                }

                Thread.sleep(850L);
            }
        }
        catch(InterruptedException ix) { }
        catch(Exception x)
        {
            x.printStackTrace();
        }
    }

    public volatile boolean run;
    protected AtomicInteger counter;
    ArrayList listeners;
    protected volatile Thread ticker;
    protected volatile int ticknr;
}
