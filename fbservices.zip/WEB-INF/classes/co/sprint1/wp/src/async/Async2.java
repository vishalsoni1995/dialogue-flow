// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Async2.java

package async;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.*;
import javax.servlet.http.*;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;

public class Async2 extends HttpServlet
{

    public Async2()
    {
    }

    protected void service(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException
    {
        final AsyncContext actx = req.startAsync();
        actx.setTimeout(30000L);
        Runnable run = new Runnable() {

            public void run()
            {
                try
                {
                    Thread.currentThread().setName("Async2-Thread");
                    Async2.log.info("Putting AsyncThread to sleep");
                    Thread.sleep(2000L);
                    Async2.log.info("Writing data.");
                    actx.getResponse().getWriter().write((new StringBuilder()).append("Output from background thread. Time:").append(System.currentTimeMillis()).append("\n").toString());
                    actx.complete();
                }
                catch(InterruptedException x)
                {
                    Async2.log.error("Async2", x);
                }
                catch(IllegalStateException x)
                {
                    Async2.log.error("Async2", x);
                }
                catch(IOException x)
                {
                    Async2.log.error("Async2", x);
                }
            }

            final AsyncContext val$actx;
            final Async2 this$0;

            
            {
                this$0 = Async2.this;
                actx = asynccontext;
                super();
            }
        }
;
        Thread t = new Thread(run);
        t.start();
    }

    private static final long serialVersionUID = 1L;
    private static final Log log = LogFactory.getLog(async/Async2);


}
