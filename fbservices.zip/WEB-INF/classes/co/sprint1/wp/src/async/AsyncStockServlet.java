// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AsyncStockServlet.java

package async;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;
import javax.servlet.*;
import javax.servlet.http.*;

// Referenced classes of package async:
//            Stockticker

public class AsyncStockServlet extends HttpServlet
    implements Stockticker.TickListener, AsyncListener
{

    public AsyncStockServlet()
    {
        System.out.println("AsyncStockServlet created");
    }

    protected void service(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException
    {
        if(req.isAsyncStarted())
            req.getAsyncContext().complete();
        else
        if(req.isAsyncSupported())
        {
            AsyncContext actx = req.startAsync();
            actx.addListener(this);
            resp.setContentType("text/plain");
            clients.add(actx);
            if(clientcount.incrementAndGet() == 1)
                ticker.addTickListener(this);
        } else
        {
            (new Exception("Async Not Supported")).printStackTrace();
            resp.sendError(400, "Async is not supported.");
        }
    }

    public void tick(Stockticker.Stock stock)
    {
        ticks.add((Stockticker.Stock)stock.clone());
        AsyncContext actx;
        for(Iterator it = clients.iterator(); it.hasNext(); writeStock(actx, stock))
            actx = (AsyncContext)it.next();

    }

    public void writeStock(AsyncContext actx, Stockticker.Stock stock)
    {
        HttpServletResponse response = (HttpServletResponse)actx.getResponse();
        try
        {
            PrintWriter writer = response.getWriter();
            writer.write("STOCK#");
            writer.write(stock.getSymbol());
            writer.write("#");
            writer.write(stock.getValueAsString());
            writer.write("#");
            writer.write(stock.getLastChangeAsString());
            writer.write("#");
            writer.write(String.valueOf(stock.getCnt()));
            writer.write("\n");
            writer.flush();
            response.flushBuffer();
        }
        catch(IOException x)
        {
            try
            {
                actx.complete();
            }
            catch(Exception ignore) { }
        }
    }

    public void onComplete(AsyncEvent event)
        throws IOException
    {
        if(clients.remove(event.getAsyncContext()) && clientcount.decrementAndGet() == 0)
            ticker.removeTickListener(this);
    }

    public void onError(AsyncEvent event)
        throws IOException
    {
        event.getAsyncContext().complete();
    }

    public void onTimeout(AsyncEvent event)
        throws IOException
    {
        event.getAsyncContext().complete();
    }

    public void onStartAsync(AsyncEvent asyncevent)
        throws IOException
    {
    }

    private static final long serialVersionUID = 1L;
    public static final String POLL = "POLL";
    public static final String LONG_POLL = "LONG-POLL";
    public static final String STREAM = "STREAM";
    static ArrayList ticks = new ArrayList();
    static ConcurrentLinkedQueue clients = new ConcurrentLinkedQueue();
    static AtomicInteger clientcount = new AtomicInteger(0);
    static Stockticker ticker = new Stockticker();

}
