// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Async0.java

package async;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.AsyncContext;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;

public class Async0 extends HttpServlet
{

    public Async0()
    {
    }

    protected void service(final HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException
    {
        if(Boolean.TRUE == req.getAttribute("dispatch"))
        {
            log.info("Received dispatch, completing on the worker thread.");
            log.info((new StringBuilder()).append("After complete called started:").append(req.isAsyncStarted()).toString());
            resp.getWriter().write((new StringBuilder()).append("Async dispatch worked:+").append(System.currentTimeMillis()).append("\n").toString());
        } else
        {
            resp.setContentType("text/plain");
            final AsyncContext actx = req.startAsync();
            actx.setTimeout(0x7fffffffffffffffL);
            Runnable run = new Runnable() {

                public void run()
                {
                    try
                    {
                        req.setAttribute("dispatch", Boolean.TRUE);
                        Thread.currentThread().setName("Async0-Thread");
                        Async0.log.info("Putting AsyncThread to sleep");
                        Thread.sleep(2000L);
                        Async0.log.info("Dispatching");
                        actx.dispatch();
                    }
                    catch(InterruptedException x)
                    {
                        Async0.log.error("Async1", x);
                    }
                    catch(IllegalStateException x)
                    {
                        Async0.log.error("Async1", x);
                    }
                }

                final HttpServletRequest val$req;
                final AsyncContext val$actx;
                final Async0 this$0;

            
            {
                this$0 = Async0.this;
                req = httpservletrequest;
                actx = asynccontext;
                super();
            }
            }
;
            Thread t = new Thread(run);
            t.start();
        }
    }

    private static final long serialVersionUID = 1L;
    private static final Log log = LogFactory.getLog(async/Async0);


}
