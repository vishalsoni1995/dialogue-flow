// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Async3.java

package async;

import java.io.IOException;
import javax.servlet.AsyncContext;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class Async3 extends HttpServlet
{

    public Async3()
    {
    }

    protected void service(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException
    {
        AsyncContext actx = req.startAsync();
        actx.setTimeout(30000L);
        actx.dispatch("/jsp/async/async3.jsp");
    }

    private static final long serialVersionUID = 1L;
}
