// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Clock2.java

import java.applet.Applet;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Clock2 extends Applet
    implements Runnable
{

    public Clock2()
    {
    }

    public void init()
    {
        lastxs = lastys = lastxm = lastym = lastxh = lastyh = 0;
        formatter = new SimpleDateFormat("EEE MMM dd hh:mm:ss yyyy", Locale.getDefault());
        currentDate = new Date();
        lastdate = formatter.format(currentDate);
        clockFaceFont = new Font("Serif", 0, 14);
        handColor = Color.blue;
        numberColor = Color.darkGray;
        try
        {
            setBackground(new Color(Integer.parseInt(getParameter("bgcolor"), 16)));
        }
        catch(Exception E) { }
        try
        {
            handColor = new Color(Integer.parseInt(getParameter("fgcolor1"), 16));
        }
        catch(Exception E) { }
        try
        {
            numberColor = new Color(Integer.parseInt(getParameter("fgcolor2"), 16));
        }
        catch(Exception E) { }
        resize(300, 300);
    }

    public void plotpoints(int x0, int y0, int x, int y, Graphics g)
    {
        g.drawLine(x0 + x, y0 + y, x0 + x, y0 + y);
        g.drawLine(x0 + y, y0 + x, x0 + y, y0 + x);
        g.drawLine(x0 + y, y0 - x, x0 + y, y0 - x);
        g.drawLine(x0 + x, y0 - y, x0 + x, y0 - y);
        g.drawLine(x0 - x, y0 - y, x0 - x, y0 - y);
        g.drawLine(x0 - y, y0 - x, x0 - y, y0 - x);
        g.drawLine(x0 - y, y0 + x, x0 - y, y0 + x);
        g.drawLine(x0 - x, y0 + y, x0 - x, y0 + y);
    }

    public void circle(int x0, int y0, int r, Graphics g)
    {
        int x = 0;
        int y = r;
        float d = 1 - r;
        plotpoints(x0, y0, x, y, g);
        while(y > x) 
        {
            if(d < 0.0F)
            {
                d = d + (float)(2 * x) + 3F;
                x++;
            } else
            {
                d = d + (float)(2 * (x - y)) + 5F;
                x++;
                y--;
            }
            plotpoints(x0, y0, x, y, g);
        }
    }

    public void paint(Graphics g)
    {
        int s = 0;
        int m = 10;
        int h = 10;
        currentDate = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("s", Locale.getDefault());
        try
        {
            s = Integer.parseInt(formatter.format(currentDate));
        }
        catch(NumberFormatException n)
        {
            s = 0;
        }
        formatter.applyPattern("m");
        try
        {
            m = Integer.parseInt(formatter.format(currentDate));
        }
        catch(NumberFormatException n)
        {
            m = 10;
        }
        formatter.applyPattern("h");
        try
        {
            h = Integer.parseInt(formatter.format(currentDate));
        }
        catch(NumberFormatException n)
        {
            h = 10;
        }
        formatter.applyPattern("EEE MMM dd HH:mm:ss yyyy");
        String today = formatter.format(currentDate);
        int xcenter = 80;
        int ycenter = 55;
        int xs = (int)(Math.cos(((float)s * 3.14F) / 30F - 1.57F) * 45D + (double)xcenter);
        int ys = (int)(Math.sin(((float)s * 3.14F) / 30F - 1.57F) * 45D + (double)ycenter);
        int xm = (int)(Math.cos(((float)m * 3.14F) / 30F - 1.57F) * 40D + (double)xcenter);
        int ym = (int)(Math.sin(((float)m * 3.14F) / 30F - 1.57F) * 40D + (double)ycenter);
        int xh = (int)(Math.cos(((float)(h * 30 + m / 2) * 3.14F) / 180F - 1.57F) * 30D + (double)xcenter);
        int yh = (int)(Math.sin(((float)(h * 30 + m / 2) * 3.14F) / 180F - 1.57F) * 30D + (double)ycenter);
        g.setFont(clockFaceFont);
        g.setColor(handColor);
        circle(xcenter, ycenter, 50, g);
        g.setColor(numberColor);
        g.drawString("9", xcenter - 45, ycenter + 3);
        g.drawString("3", xcenter + 40, ycenter + 3);
        g.drawString("12", xcenter - 5, ycenter - 37);
        g.drawString("6", xcenter - 3, ycenter + 45);
        g.setColor(getBackground());
        if(xs != lastxs || ys != lastys)
        {
            g.drawLine(xcenter, ycenter, lastxs, lastys);
            g.drawString(lastdate, 5, 125);
        }
        if(xm != lastxm || ym != lastym)
        {
            g.drawLine(xcenter, ycenter - 1, lastxm, lastym);
            g.drawLine(xcenter - 1, ycenter, lastxm, lastym);
        }
        if(xh != lastxh || yh != lastyh)
        {
            g.drawLine(xcenter, ycenter - 1, lastxh, lastyh);
            g.drawLine(xcenter - 1, ycenter, lastxh, lastyh);
        }
        g.setColor(numberColor);
        g.drawString("", 5, 125);
        g.drawString(today, 5, 125);
        g.drawLine(xcenter, ycenter, xs, ys);
        g.setColor(handColor);
        g.drawLine(xcenter, ycenter - 1, xm, ym);
        g.drawLine(xcenter - 1, ycenter, xm, ym);
        g.drawLine(xcenter, ycenter - 1, xh, yh);
        g.drawLine(xcenter - 1, ycenter, xh, yh);
        lastxs = xs;
        lastys = ys;
        lastxm = xm;
        lastym = ym;
        lastxh = xh;
        lastyh = yh;
        lastdate = today;
        currentDate = null;
    }

    public void start()
    {
        timer = new Thread(this);
        timer.start();
    }

    public void stop()
    {
        timer = null;
    }

    public void run()
    {
        for(Thread me = Thread.currentThread(); timer == me;)
        {
            try
            {
                Thread.sleep(100L);
            }
            catch(InterruptedException e) { }
            repaint();
        }

    }

    public void update(Graphics g)
    {
        paint(g);
    }

    public String getAppletInfo()
    {
        return "Title: A Clock \nAuthor: Rachel Gollub, 1995 \nAn analog clock.";
    }

    public String[][] getParameterInfo()
    {
        String info[][] = {
            {
                "bgcolor", "hexadecimal RGB number", "The background color. Default is the color of your browser."
            }, {
                "fgcolor1", "hexadecimal RGB number", "The color of the hands and dial. Default is blue."
            }, {
                "fgcolor2", "hexadecimal RGB number", "The color of the seconds hand and numbers. Default is dark gray."
            }
        };
        return info;
    }

    private static final long serialVersionUID = 1L;
    Thread timer;
    int lastxs;
    int lastys;
    int lastxm;
    int lastym;
    int lastxh;
    int lastyh;
    SimpleDateFormat formatter;
    String lastdate;
    Font clockFaceFont;
    Date currentDate;
    Color handColor;
    Color numberColor;
}
