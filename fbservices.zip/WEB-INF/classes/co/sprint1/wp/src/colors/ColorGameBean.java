// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ColorGameBean.java

package colors;


public class ColorGameBean
{

    public ColorGameBean()
    {
        background = "yellow";
        foreground = "red";
        color1 = foreground;
        color2 = background;
        hint = "no";
        attempts = 0;
        intval = 0;
        tookHints = false;
    }

    public void processRequest()
    {
        if(!color1.equals(foreground) && (color1.equalsIgnoreCase("black") || color1.equalsIgnoreCase("cyan")))
            background = color1;
        if(!color2.equals(background) && (color2.equalsIgnoreCase("black") || color2.equalsIgnoreCase("cyan")))
            foreground = color2;
        attempts++;
    }

    public void setColor2(String x)
    {
        color2 = x;
    }

    public void setColor1(String x)
    {
        color1 = x;
    }

    public void setAction(String x)
    {
        if(!tookHints)
            tookHints = x.equalsIgnoreCase("Hint");
        hint = x;
    }

    public String getColor2()
    {
        return background;
    }

    public String getColor1()
    {
        return foreground;
    }

    public int getAttempts()
    {
        return attempts;
    }

    public boolean getHint()
    {
        return hint.equalsIgnoreCase("Hint");
    }

    public boolean getSuccess()
    {
        if(background.equalsIgnoreCase("black") || background.equalsIgnoreCase("cyan"))
            return foreground.equalsIgnoreCase("black") || foreground.equalsIgnoreCase("cyan");
        else
            return false;
    }

    public boolean getHintTaken()
    {
        return tookHints;
    }

    public void reset()
    {
        foreground = "red";
        background = "yellow";
    }

    public void setIntval(int value)
    {
        intval = value;
    }

    public int getIntval()
    {
        return intval;
    }

    private String background;
    private String foreground;
    private String color1;
    private String color2;
    private String hint;
    private int attempts;
    private int intval;
    private boolean tookHints;
}
