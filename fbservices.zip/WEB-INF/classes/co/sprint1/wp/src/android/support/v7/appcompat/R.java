// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   R.java

package android.support.v7.appcompat;


public final class R
{
    public static final class styleable
    {

        public static final int ActionBar[] = {
            0x7f010002, 0x7f01002f, 0x7f010030, 0x7f010031, 0x7f010032, 0x7f010033, 0x7f010034, 0x7f010035, 0x7f010036, 0x7f010037, 
            0x7f010038, 0x7f010039, 0x7f01003a, 0x7f01003b, 0x7f01003c, 0x7f01003d, 0x7f01003e, 0x7f01003f, 0x7f010040, 0x7f010041, 
            0x7f010042, 0x7f010043, 0x7f010044, 0x7f010045, 0x7f010046, 0x7f010047, 0x7f010048, 0x7f010049, 0x7f01008c
        };
        public static final int ActionBar_height = 0;
        public static final int ActionBar_title = 1;
        public static final int ActionBar_navigationMode = 2;
        public static final int ActionBar_displayOptions = 3;
        public static final int ActionBar_subtitle = 4;
        public static final int ActionBar_titleTextStyle = 5;
        public static final int ActionBar_subtitleTextStyle = 6;
        public static final int ActionBar_icon = 7;
        public static final int ActionBar_logo = 8;
        public static final int ActionBar_divider = 9;
        public static final int ActionBar_background = 10;
        public static final int ActionBar_backgroundStacked = 11;
        public static final int ActionBar_backgroundSplit = 12;
        public static final int ActionBar_customNavigationLayout = 13;
        public static final int ActionBar_homeLayout = 14;
        public static final int ActionBar_progressBarStyle = 15;
        public static final int ActionBar_indeterminateProgressStyle = 16;
        public static final int ActionBar_progressBarPadding = 17;
        public static final int ActionBar_itemPadding = 18;
        public static final int ActionBar_hideOnContentScroll = 19;
        public static final int ActionBar_contentInsetStart = 20;
        public static final int ActionBar_contentInsetEnd = 21;
        public static final int ActionBar_contentInsetLeft = 22;
        public static final int ActionBar_contentInsetRight = 23;
        public static final int ActionBar_contentInsetStartWithNavigation = 24;
        public static final int ActionBar_contentInsetEndWithActions = 25;
        public static final int ActionBar_elevation = 26;
        public static final int ActionBar_popupTheme = 27;
        public static final int ActionBar_homeAsUpIndicator = 28;
        public static final int ActionBarLayout[] = {
            0x10100b3
        };
        public static final int ActionBarLayout_android_layout_gravity = 0;
        public static final int ActionMenuItemView[] = {
            0x101013f
        };
        public static final int ActionMenuItemView_android_minWidth = 0;
        public static final int ActionMenuView[] = new int[0];
        public static final int ActionMode[] = {
            0x7f010002, 0x7f010033, 0x7f010034, 0x7f010038, 0x7f01003a, 0x7f01004a
        };
        public static final int ActionMode_height = 0;
        public static final int ActionMode_titleTextStyle = 1;
        public static final int ActionMode_subtitleTextStyle = 2;
        public static final int ActionMode_background = 3;
        public static final int ActionMode_backgroundSplit = 4;
        public static final int ActionMode_closeItemLayout = 5;
        public static final int ActivityChooserView[] = {
            0x7f01004b, 0x7f01004c
        };
        public static final int ActivityChooserView_initialActivityCount = 0;
        public static final int ActivityChooserView_expandActivityOverflowButtonDrawable = 1;
        public static final int AlertDialog[] = {
            0x10100f2, 0x7f01004d, 0x7f01004e, 0x7f01004f, 0x7f010050, 0x7f010051, 0x7f010052
        };
        public static final int AlertDialog_android_layout = 0;
        public static final int AlertDialog_buttonPanelSideLayout = 1;
        public static final int AlertDialog_listLayout = 2;
        public static final int AlertDialog_multiChoiceItemLayout = 3;
        public static final int AlertDialog_singleChoiceItemLayout = 4;
        public static final int AlertDialog_listItemLayout = 5;
        public static final int AlertDialog_showTitle = 6;
        public static final int AppCompatImageView[] = {
            0x1010119, 0x7f010058
        };
        public static final int AppCompatImageView_android_src = 0;
        public static final int AppCompatImageView_srcCompat = 1;
        public static final int AppCompatSeekBar[] = {
            0x1010142, 0x7f010059, 0x7f01005a, 0x7f01005b
        };
        public static final int AppCompatSeekBar_android_thumb = 0;
        public static final int AppCompatSeekBar_tickMark = 1;
        public static final int AppCompatSeekBar_tickMarkTint = 2;
        public static final int AppCompatSeekBar_tickMarkTintMode = 3;
        public static final int AppCompatTextHelper[] = {
            0x1010034, 0x101016d, 0x101016e, 0x101016f, 0x1010170, 0x1010392, 0x1010393
        };
        public static final int AppCompatTextHelper_android_textAppearance = 0;
        public static final int AppCompatTextHelper_android_drawableTop = 1;
        public static final int AppCompatTextHelper_android_drawableBottom = 2;
        public static final int AppCompatTextHelper_android_drawableLeft = 3;
        public static final int AppCompatTextHelper_android_drawableRight = 4;
        public static final int AppCompatTextHelper_android_drawableStart = 5;
        public static final int AppCompatTextHelper_android_drawableEnd = 6;
        public static final int AppCompatTextView[] = {
            0x1010034, 0x7f01005c
        };
        public static final int AppCompatTextView_android_textAppearance = 0;
        public static final int AppCompatTextView_textAllCaps = 1;
        public static final int AppCompatTheme[] = {
            0x1010057, 0x10100ae, 0x7f01005d, 0x7f01005e, 0x7f01005f, 0x7f010060, 0x7f010061, 0x7f010062, 0x7f010063, 0x7f010064, 
            0x7f010065, 0x7f010066, 0x7f010067, 0x7f010068, 0x7f010069, 0x7f01006a, 0x7f01006b, 0x7f01006c, 0x7f01006d, 0x7f01006e, 
            0x7f01006f, 0x7f010070, 0x7f010071, 0x7f010072, 0x7f010073, 0x7f010074, 0x7f010075, 0x7f010076, 0x7f010077, 0x7f010078, 
            0x7f010079, 0x7f01007a, 0x7f01007b, 0x7f01007c, 0x7f01007d, 0x7f01007e, 0x7f01007f, 0x7f010080, 0x7f010081, 0x7f010082, 
            0x7f010083, 0x7f010084, 0x7f010085, 0x7f010086, 0x7f010087, 0x7f010088, 0x7f010089, 0x7f01008a, 0x7f01008b, 0x7f01008c, 
            0x7f01008d, 0x7f01008e, 0x7f01008f, 0x7f010090, 0x7f010091, 0x7f010092, 0x7f010093, 0x7f010094, 0x7f010095, 0x7f010096, 
            0x7f010097, 0x7f010098, 0x7f010099, 0x7f01009a, 0x7f01009b, 0x7f01009c, 0x7f01009d, 0x7f01009e, 0x7f01009f, 0x7f0100a0, 
            0x7f0100a1, 0x7f0100a2, 0x7f0100a3, 0x7f0100a4, 0x7f0100a5, 0x7f0100a6, 0x7f0100a7, 0x7f0100a8, 0x7f0100a9, 0x7f0100aa, 
            0x7f0100ab, 0x7f0100ac, 0x7f0100ad, 0x7f0100ae, 0x7f0100af, 0x7f0100b0, 0x7f0100b1, 0x7f0100b2, 0x7f0100b3, 0x7f0100b4, 
            0x7f0100b5, 0x7f0100b6, 0x7f0100b7, 0x7f0100b8, 0x7f0100b9, 0x7f0100ba, 0x7f0100bb, 0x7f0100bc, 0x7f0100bd, 0x7f0100be, 
            0x7f0100bf, 0x7f0100c0, 0x7f0100c1, 0x7f0100c2, 0x7f0100c3, 0x7f0100c4, 0x7f0100c5, 0x7f0100c6, 0x7f0100c7, 0x7f0100c8, 
            0x7f0100c9, 0x7f0100ca, 0x7f0100cb, 0x7f0100cc, 0x7f0100cd
        };
        public static final int AppCompatTheme_android_windowIsFloating = 0;
        public static final int AppCompatTheme_android_windowAnimationStyle = 1;
        public static final int AppCompatTheme_windowActionBar = 2;
        public static final int AppCompatTheme_windowNoTitle = 3;
        public static final int AppCompatTheme_windowActionBarOverlay = 4;
        public static final int AppCompatTheme_windowActionModeOverlay = 5;
        public static final int AppCompatTheme_windowFixedWidthMajor = 6;
        public static final int AppCompatTheme_windowFixedHeightMinor = 7;
        public static final int AppCompatTheme_windowFixedWidthMinor = 8;
        public static final int AppCompatTheme_windowFixedHeightMajor = 9;
        public static final int AppCompatTheme_windowMinWidthMajor = 10;
        public static final int AppCompatTheme_windowMinWidthMinor = 11;
        public static final int AppCompatTheme_actionBarTabStyle = 12;
        public static final int AppCompatTheme_actionBarTabBarStyle = 13;
        public static final int AppCompatTheme_actionBarTabTextStyle = 14;
        public static final int AppCompatTheme_actionOverflowButtonStyle = 15;
        public static final int AppCompatTheme_actionOverflowMenuStyle = 16;
        public static final int AppCompatTheme_actionBarPopupTheme = 17;
        public static final int AppCompatTheme_actionBarStyle = 18;
        public static final int AppCompatTheme_actionBarSplitStyle = 19;
        public static final int AppCompatTheme_actionBarTheme = 20;
        public static final int AppCompatTheme_actionBarWidgetTheme = 21;
        public static final int AppCompatTheme_actionBarSize = 22;
        public static final int AppCompatTheme_actionBarDivider = 23;
        public static final int AppCompatTheme_actionBarItemBackground = 24;
        public static final int AppCompatTheme_actionMenuTextAppearance = 25;
        public static final int AppCompatTheme_actionMenuTextColor = 26;
        public static final int AppCompatTheme_actionModeStyle = 27;
        public static final int AppCompatTheme_actionModeCloseButtonStyle = 28;
        public static final int AppCompatTheme_actionModeBackground = 29;
        public static final int AppCompatTheme_actionModeSplitBackground = 30;
        public static final int AppCompatTheme_actionModeCloseDrawable = 31;
        public static final int AppCompatTheme_actionModeCutDrawable = 32;
        public static final int AppCompatTheme_actionModeCopyDrawable = 33;
        public static final int AppCompatTheme_actionModePasteDrawable = 34;
        public static final int AppCompatTheme_actionModeSelectAllDrawable = 35;
        public static final int AppCompatTheme_actionModeShareDrawable = 36;
        public static final int AppCompatTheme_actionModeFindDrawable = 37;
        public static final int AppCompatTheme_actionModeWebSearchDrawable = 38;
        public static final int AppCompatTheme_actionModePopupWindowStyle = 39;
        public static final int AppCompatTheme_textAppearanceLargePopupMenu = 40;
        public static final int AppCompatTheme_textAppearanceSmallPopupMenu = 41;
        public static final int AppCompatTheme_textAppearancePopupMenuHeader = 42;
        public static final int AppCompatTheme_dialogTheme = 43;
        public static final int AppCompatTheme_dialogPreferredPadding = 44;
        public static final int AppCompatTheme_listDividerAlertDialog = 45;
        public static final int AppCompatTheme_actionDropDownStyle = 46;
        public static final int AppCompatTheme_dropdownListPreferredItemHeight = 47;
        public static final int AppCompatTheme_spinnerDropDownItemStyle = 48;
        public static final int AppCompatTheme_homeAsUpIndicator = 49;
        public static final int AppCompatTheme_actionButtonStyle = 50;
        public static final int AppCompatTheme_buttonBarStyle = 51;
        public static final int AppCompatTheme_buttonBarButtonStyle = 52;
        public static final int AppCompatTheme_selectableItemBackground = 53;
        public static final int AppCompatTheme_selectableItemBackgroundBorderless = 54;
        public static final int AppCompatTheme_borderlessButtonStyle = 55;
        public static final int AppCompatTheme_dividerVertical = 56;
        public static final int AppCompatTheme_dividerHorizontal = 57;
        public static final int AppCompatTheme_activityChooserViewStyle = 58;
        public static final int AppCompatTheme_toolbarStyle = 59;
        public static final int AppCompatTheme_toolbarNavigationButtonStyle = 60;
        public static final int AppCompatTheme_popupMenuStyle = 61;
        public static final int AppCompatTheme_popupWindowStyle = 62;
        public static final int AppCompatTheme_editTextColor = 63;
        public static final int AppCompatTheme_editTextBackground = 64;
        public static final int AppCompatTheme_imageButtonStyle = 65;
        public static final int AppCompatTheme_textAppearanceSearchResultTitle = 66;
        public static final int AppCompatTheme_textAppearanceSearchResultSubtitle = 67;
        public static final int AppCompatTheme_textColorSearchUrl = 68;
        public static final int AppCompatTheme_searchViewStyle = 69;
        public static final int AppCompatTheme_listPreferredItemHeight = 70;
        public static final int AppCompatTheme_listPreferredItemHeightSmall = 71;
        public static final int AppCompatTheme_listPreferredItemHeightLarge = 72;
        public static final int AppCompatTheme_listPreferredItemPaddingLeft = 73;
        public static final int AppCompatTheme_listPreferredItemPaddingRight = 74;
        public static final int AppCompatTheme_dropDownListViewStyle = 75;
        public static final int AppCompatTheme_listPopupWindowStyle = 76;
        public static final int AppCompatTheme_textAppearanceListItem = 77;
        public static final int AppCompatTheme_textAppearanceListItemSmall = 78;
        public static final int AppCompatTheme_panelBackground = 79;
        public static final int AppCompatTheme_panelMenuListWidth = 80;
        public static final int AppCompatTheme_panelMenuListTheme = 81;
        public static final int AppCompatTheme_listChoiceBackgroundIndicator = 82;
        public static final int AppCompatTheme_colorPrimary = 83;
        public static final int AppCompatTheme_colorPrimaryDark = 84;
        public static final int AppCompatTheme_colorAccent = 85;
        public static final int AppCompatTheme_colorControlNormal = 86;
        public static final int AppCompatTheme_colorControlActivated = 87;
        public static final int AppCompatTheme_colorControlHighlight = 88;
        public static final int AppCompatTheme_colorButtonNormal = 89;
        public static final int AppCompatTheme_colorSwitchThumbNormal = 90;
        public static final int AppCompatTheme_controlBackground = 91;
        public static final int AppCompatTheme_colorBackgroundFloating = 92;
        public static final int AppCompatTheme_alertDialogStyle = 93;
        public static final int AppCompatTheme_alertDialogButtonGroupStyle = 94;
        public static final int AppCompatTheme_alertDialogCenterButtons = 95;
        public static final int AppCompatTheme_alertDialogTheme = 96;
        public static final int AppCompatTheme_textColorAlertDialogListItem = 97;
        public static final int AppCompatTheme_buttonBarPositiveButtonStyle = 98;
        public static final int AppCompatTheme_buttonBarNegativeButtonStyle = 99;
        public static final int AppCompatTheme_buttonBarNeutralButtonStyle = 100;
        public static final int AppCompatTheme_autoCompleteTextViewStyle = 101;
        public static final int AppCompatTheme_buttonStyle = 102;
        public static final int AppCompatTheme_buttonStyleSmall = 103;
        public static final int AppCompatTheme_checkboxStyle = 104;
        public static final int AppCompatTheme_checkedTextViewStyle = 105;
        public static final int AppCompatTheme_editTextStyle = 106;
        public static final int AppCompatTheme_radioButtonStyle = 107;
        public static final int AppCompatTheme_ratingBarStyle = 108;
        public static final int AppCompatTheme_ratingBarStyleIndicator = 109;
        public static final int AppCompatTheme_ratingBarStyleSmall = 110;
        public static final int AppCompatTheme_seekBarStyle = 111;
        public static final int AppCompatTheme_spinnerStyle = 112;
        public static final int AppCompatTheme_switchStyle = 113;
        public static final int AppCompatTheme_listMenuViewStyle = 114;
        public static final int ButtonBarLayout[] = {
            0x7f0100d1
        };
        public static final int ButtonBarLayout_allowStacking = 0;
        public static final int ColorStateListItem[] = {
            0x10101a5, 0x101031f, 0x7f0100ee
        };
        public static final int ColorStateListItem_android_color = 0;
        public static final int ColorStateListItem_android_alpha = 1;
        public static final int ColorStateListItem_alpha = 2;
        public static final int CompoundButton[] = {
            0x1010107, 0x7f0100ef, 0x7f0100f0
        };
        public static final int CompoundButton_android_button = 0;
        public static final int CompoundButton_buttonTint = 1;
        public static final int CompoundButton_buttonTintMode = 2;
        public static final int DrawerArrowToggle[] = {
            0x7f0100fc, 0x7f0100fd, 0x7f0100fe, 0x7f0100ff, 0x7f010100, 0x7f010101, 0x7f010102, 0x7f010103
        };
        public static final int DrawerArrowToggle_color = 0;
        public static final int DrawerArrowToggle_spinBars = 1;
        public static final int DrawerArrowToggle_drawableSize = 2;
        public static final int DrawerArrowToggle_gapBetweenBars = 3;
        public static final int DrawerArrowToggle_arrowHeadLength = 4;
        public static final int DrawerArrowToggle_arrowShaftLength = 5;
        public static final int DrawerArrowToggle_barLength = 6;
        public static final int DrawerArrowToggle_thickness = 7;
        public static final int LinearLayoutCompat[] = {
            0x10100af, 0x10100c4, 0x1010126, 0x1010127, 0x1010128, 0x7f010037, 0x7f01010b, 0x7f01010c, 0x7f01010d
        };
        public static final int LinearLayoutCompat_android_gravity = 0;
        public static final int LinearLayoutCompat_android_orientation = 1;
        public static final int LinearLayoutCompat_android_baselineAligned = 2;
        public static final int LinearLayoutCompat_android_baselineAlignedChildIndex = 3;
        public static final int LinearLayoutCompat_android_weightSum = 4;
        public static final int LinearLayoutCompat_divider = 5;
        public static final int LinearLayoutCompat_measureWithLargestChild = 6;
        public static final int LinearLayoutCompat_showDividers = 7;
        public static final int LinearLayoutCompat_dividerPadding = 8;
        public static final int LinearLayoutCompat_Layout[] = {
            0x10100b3, 0x10100f4, 0x10100f5, 0x1010181
        };
        public static final int LinearLayoutCompat_Layout_android_layout_gravity = 0;
        public static final int LinearLayoutCompat_Layout_android_layout_width = 1;
        public static final int LinearLayoutCompat_Layout_android_layout_height = 2;
        public static final int LinearLayoutCompat_Layout_android_layout_weight = 3;
        public static final int ListPopupWindow[] = {
            0x10102ac, 0x10102ad
        };
        public static final int ListPopupWindow_android_dropDownHorizontalOffset = 0;
        public static final int ListPopupWindow_android_dropDownVerticalOffset = 1;
        public static final int MenuGroup[] = {
            0x101000e, 0x10100d0, 0x1010194, 0x10101de, 0x10101df, 0x10101e0
        };
        public static final int MenuGroup_android_enabled = 0;
        public static final int MenuGroup_android_id = 1;
        public static final int MenuGroup_android_visible = 2;
        public static final int MenuGroup_android_menuCategory = 3;
        public static final int MenuGroup_android_orderInCategory = 4;
        public static final int MenuGroup_android_checkableBehavior = 5;
        public static final int MenuItem[] = {
            0x1010002, 0x101000e, 0x10100d0, 0x1010106, 0x1010194, 0x10101de, 0x10101df, 0x10101e1, 0x10101e2, 0x10101e3, 
            0x10101e4, 0x10101e5, 0x101026f, 0x7f010122, 0x7f010123, 0x7f010124, 0x7f010125
        };
        public static final int MenuItem_android_icon = 0;
        public static final int MenuItem_android_enabled = 1;
        public static final int MenuItem_android_id = 2;
        public static final int MenuItem_android_checked = 3;
        public static final int MenuItem_android_visible = 4;
        public static final int MenuItem_android_menuCategory = 5;
        public static final int MenuItem_android_orderInCategory = 6;
        public static final int MenuItem_android_title = 7;
        public static final int MenuItem_android_titleCondensed = 8;
        public static final int MenuItem_android_alphabeticShortcut = 9;
        public static final int MenuItem_android_numericShortcut = 10;
        public static final int MenuItem_android_checkable = 11;
        public static final int MenuItem_android_onClick = 12;
        public static final int MenuItem_showAsAction = 13;
        public static final int MenuItem_actionLayout = 14;
        public static final int MenuItem_actionViewClass = 15;
        public static final int MenuItem_actionProviderClass = 16;
        public static final int MenuView[] = {
            0x10100ae, 0x101012c, 0x101012d, 0x101012e, 0x101012f, 0x1010130, 0x1010131, 0x7f010126, 0x7f010127
        };
        public static final int MenuView_android_windowAnimationStyle = 0;
        public static final int MenuView_android_itemTextAppearance = 1;
        public static final int MenuView_android_horizontalDivider = 2;
        public static final int MenuView_android_verticalDivider = 3;
        public static final int MenuView_android_headerBackground = 4;
        public static final int MenuView_android_itemBackground = 5;
        public static final int MenuView_android_itemIconDisabledAlpha = 6;
        public static final int MenuView_preserveIconSpacing = 7;
        public static final int MenuView_subMenuArrow = 8;
        public static final int PopupWindow[] = {
            0x1010176, 0x10102c9, 0x7f01012e
        };
        public static final int PopupWindow_android_popupBackground = 0;
        public static final int PopupWindow_android_popupAnimationStyle = 1;
        public static final int PopupWindow_overlapAnchor = 2;
        public static final int PopupWindowBackgroundState[] = {
            0x7f01012f
        };
        public static final int PopupWindowBackgroundState_state_above_anchor = 0;
        public static final int RecycleListView[] = {
            0x7f010130, 0x7f010131
        };
        public static final int RecycleListView_paddingBottomNoButtons = 0;
        public static final int RecycleListView_paddingTopNoTitle = 1;
        public static final int SearchView[] = {
            0x10100da, 0x101011f, 0x1010220, 0x1010264, 0x7f010138, 0x7f010139, 0x7f01013a, 0x7f01013b, 0x7f01013c, 0x7f01013d, 
            0x7f01013e, 0x7f01013f, 0x7f010140, 0x7f010141, 0x7f010142, 0x7f010143, 0x7f010144
        };
        public static final int SearchView_android_focusable = 0;
        public static final int SearchView_android_maxWidth = 1;
        public static final int SearchView_android_inputType = 2;
        public static final int SearchView_android_imeOptions = 3;
        public static final int SearchView_layout = 4;
        public static final int SearchView_iconifiedByDefault = 5;
        public static final int SearchView_queryHint = 6;
        public static final int SearchView_defaultQueryHint = 7;
        public static final int SearchView_closeIcon = 8;
        public static final int SearchView_goIcon = 9;
        public static final int SearchView_searchIcon = 10;
        public static final int SearchView_searchHintIcon = 11;
        public static final int SearchView_voiceIcon = 12;
        public static final int SearchView_commitIcon = 13;
        public static final int SearchView_suggestionRowLayout = 14;
        public static final int SearchView_queryBackground = 15;
        public static final int SearchView_submitBackground = 16;
        public static final int Spinner[] = {
            0x10100b2, 0x1010176, 0x101017b, 0x1010262, 0x7f010049
        };
        public static final int Spinner_android_entries = 0;
        public static final int Spinner_android_popupBackground = 1;
        public static final int Spinner_android_prompt = 2;
        public static final int Spinner_android_dropDownWidth = 3;
        public static final int Spinner_popupTheme = 4;
        public static final int SwitchCompat[] = {
            0x1010124, 0x1010125, 0x1010142, 0x7f010149, 0x7f01014a, 0x7f01014b, 0x7f01014c, 0x7f01014d, 0x7f01014e, 0x7f01014f, 
            0x7f010150, 0x7f010151, 0x7f010152, 0x7f010153
        };
        public static final int SwitchCompat_android_textOn = 0;
        public static final int SwitchCompat_android_textOff = 1;
        public static final int SwitchCompat_android_thumb = 2;
        public static final int SwitchCompat_thumbTint = 3;
        public static final int SwitchCompat_thumbTintMode = 4;
        public static final int SwitchCompat_track = 5;
        public static final int SwitchCompat_trackTint = 6;
        public static final int SwitchCompat_trackTintMode = 7;
        public static final int SwitchCompat_thumbTextPadding = 8;
        public static final int SwitchCompat_switchTextAppearance = 9;
        public static final int SwitchCompat_switchMinWidth = 10;
        public static final int SwitchCompat_switchPadding = 11;
        public static final int SwitchCompat_splitTrack = 12;
        public static final int SwitchCompat_showText = 13;
        public static final int TextAppearance[] = {
            0x1010095, 0x1010096, 0x1010097, 0x1010098, 0x101009a, 0x1010161, 0x1010162, 0x1010163, 0x1010164, 0x7f01005c
        };
        public static final int TextAppearance_android_textSize = 0;
        public static final int TextAppearance_android_typeface = 1;
        public static final int TextAppearance_android_textStyle = 2;
        public static final int TextAppearance_android_textColor = 3;
        public static final int TextAppearance_android_textColorHint = 4;
        public static final int TextAppearance_android_shadowColor = 5;
        public static final int TextAppearance_android_shadowDx = 6;
        public static final int TextAppearance_android_shadowDy = 7;
        public static final int TextAppearance_android_shadowRadius = 8;
        public static final int TextAppearance_textAllCaps = 9;
        public static final int Toolbar[] = {
            0x10100af, 0x1010140, 0x7f01002f, 0x7f010032, 0x7f010036, 0x7f010042, 0x7f010043, 0x7f010044, 0x7f010045, 0x7f010046, 
            0x7f010047, 0x7f010049, 0x7f010172, 0x7f010173, 0x7f010174, 0x7f010175, 0x7f010176, 0x7f010177, 0x7f010178, 0x7f010179, 
            0x7f01017a, 0x7f01017b, 0x7f01017c, 0x7f01017d, 0x7f01017e, 0x7f01017f, 0x7f010180, 0x7f010181, 0x7f010182
        };
        public static final int Toolbar_android_gravity = 0;
        public static final int Toolbar_android_minHeight = 1;
        public static final int Toolbar_title = 2;
        public static final int Toolbar_subtitle = 3;
        public static final int Toolbar_logo = 4;
        public static final int Toolbar_contentInsetStart = 5;
        public static final int Toolbar_contentInsetEnd = 6;
        public static final int Toolbar_contentInsetLeft = 7;
        public static final int Toolbar_contentInsetRight = 8;
        public static final int Toolbar_contentInsetStartWithNavigation = 9;
        public static final int Toolbar_contentInsetEndWithActions = 10;
        public static final int Toolbar_popupTheme = 11;
        public static final int Toolbar_titleTextAppearance = 12;
        public static final int Toolbar_subtitleTextAppearance = 13;
        public static final int Toolbar_titleMargin = 14;
        public static final int Toolbar_titleMarginStart = 15;
        public static final int Toolbar_titleMarginEnd = 16;
        public static final int Toolbar_titleMarginTop = 17;
        public static final int Toolbar_titleMarginBottom = 18;
        public static final int Toolbar_titleMargins = 19;
        public static final int Toolbar_maxButtonHeight = 20;
        public static final int Toolbar_buttonGravity = 21;
        public static final int Toolbar_collapseIcon = 22;
        public static final int Toolbar_collapseContentDescription = 23;
        public static final int Toolbar_navigationIcon = 24;
        public static final int Toolbar_navigationContentDescription = 25;
        public static final int Toolbar_logoDescription = 26;
        public static final int Toolbar_titleTextColor = 27;
        public static final int Toolbar_subtitleTextColor = 28;
        public static final int View[] = {
            0x1010000, 0x10100da, 0x7f010183, 0x7f010184, 0x7f010185
        };
        public static final int View_android_theme = 0;
        public static final int View_android_focusable = 1;
        public static final int View_paddingStart = 2;
        public static final int View_paddingEnd = 3;
        public static final int View_theme = 4;
        public static final int ViewBackgroundHelper[] = {
            0x10100d4, 0x7f010186, 0x7f010187
        };
        public static final int ViewBackgroundHelper_android_background = 0;
        public static final int ViewBackgroundHelper_backgroundTint = 1;
        public static final int ViewBackgroundHelper_backgroundTintMode = 2;
        public static final int ViewStubCompat[] = {
            0x10100d0, 0x10100f2, 0x10100f3
        };
        public static final int ViewStubCompat_android_id = 0;
        public static final int ViewStubCompat_android_layout = 1;
        public static final int ViewStubCompat_android_inflatedId = 2;


        private styleable()
        {
        }
    }

    public static final class style
    {

        public static final int AlertDialog_AppCompat = 0x7f0900a2;
        public static final int AlertDialog_AppCompat_Light = 0x7f0900a3;
        public static final int Animation_AppCompat_Dialog = 0x7f0900a4;
        public static final int Animation_AppCompat_DropDownUp = 0x7f0900a5;
        public static final int Base_AlertDialog_AppCompat = 0x7f0900ab;
        public static final int Base_AlertDialog_AppCompat_Light = 0x7f0900ac;
        public static final int Base_Animation_AppCompat_Dialog = 0x7f0900ad;
        public static final int Base_Animation_AppCompat_DropDownUp = 0x7f0900ae;
        public static final int Base_DialogWindowTitleBackground_AppCompat = 0x7f0900b1;
        public static final int Base_DialogWindowTitle_AppCompat = 0x7f0900b0;
        public static final int Base_TextAppearance_AppCompat = 0x7f090040;
        public static final int Base_TextAppearance_AppCompat_Body1 = 0x7f090041;
        public static final int Base_TextAppearance_AppCompat_Body2 = 0x7f090042;
        public static final int Base_TextAppearance_AppCompat_Button = 0x7f090028;
        public static final int Base_TextAppearance_AppCompat_Caption = 0x7f090043;
        public static final int Base_TextAppearance_AppCompat_Display1 = 0x7f090044;
        public static final int Base_TextAppearance_AppCompat_Display2 = 0x7f090045;
        public static final int Base_TextAppearance_AppCompat_Display3 = 0x7f090046;
        public static final int Base_TextAppearance_AppCompat_Display4 = 0x7f090047;
        public static final int Base_TextAppearance_AppCompat_Headline = 0x7f090048;
        public static final int Base_TextAppearance_AppCompat_Inverse = 0x7f09000c;
        public static final int Base_TextAppearance_AppCompat_Large = 0x7f090049;
        public static final int Base_TextAppearance_AppCompat_Large_Inverse = 0x7f09000d;
        public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 0x7f09004a;
        public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 0x7f09004b;
        public static final int Base_TextAppearance_AppCompat_Medium = 0x7f09004c;
        public static final int Base_TextAppearance_AppCompat_Medium_Inverse = 0x7f09000e;
        public static final int Base_TextAppearance_AppCompat_Menu = 0x7f09004d;
        public static final int Base_TextAppearance_AppCompat_SearchResult = 0x7f0900b2;
        public static final int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 0x7f09004e;
        public static final int Base_TextAppearance_AppCompat_SearchResult_Title = 0x7f09004f;
        public static final int Base_TextAppearance_AppCompat_Small = 0x7f090050;
        public static final int Base_TextAppearance_AppCompat_Small_Inverse = 0x7f09000f;
        public static final int Base_TextAppearance_AppCompat_Subhead = 0x7f090051;
        public static final int Base_TextAppearance_AppCompat_Subhead_Inverse = 0x7f090010;
        public static final int Base_TextAppearance_AppCompat_Title = 0x7f090052;
        public static final int Base_TextAppearance_AppCompat_Title_Inverse = 0x7f090011;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 0x7f090096;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 0x7f090053;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 0x7f090054;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 0x7f090055;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 0x7f090056;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 0x7f090057;
        public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 0x7f090058;
        public static final int Base_TextAppearance_AppCompat_Widget_Button = 0x7f090059;
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 0x7f09009e;
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Colored = 0x7f09009f;
        public static final int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 0x7f090097;
        public static final int Base_TextAppearance_AppCompat_Widget_DropDownItem = 0x7f0900b3;
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Header = 0x7f09005a;
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 0x7f09005b;
        public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 0x7f09005c;
        public static final int Base_TextAppearance_AppCompat_Widget_Switch = 0x7f09005d;
        public static final int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 0x7f09005e;
        public static final int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 0x7f0900b4;
        public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 0x7f09005f;
        public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 0x7f090060;
        public static final int Base_ThemeOverlay_AppCompat = 0x7f0900b9;
        public static final int Base_ThemeOverlay_AppCompat_ActionBar = 0x7f0900ba;
        public static final int Base_ThemeOverlay_AppCompat_Dark = 0x7f0900bb;
        public static final int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 0x7f0900bc;
        public static final int Base_ThemeOverlay_AppCompat_Dialog = 0x7f090018;
        public static final int Base_ThemeOverlay_AppCompat_Dialog_Alert = 0x7f090019;
        public static final int Base_ThemeOverlay_AppCompat_Light = 0x7f0900bd;
        public static final int Base_Theme_AppCompat = 0x7f090061;
        public static final int Base_Theme_AppCompat_CompactMenu = 0x7f0900b5;
        public static final int Base_Theme_AppCompat_Dialog = 0x7f090012;
        public static final int Base_Theme_AppCompat_DialogWhenLarge = 0x7f090002;
        public static final int Base_Theme_AppCompat_Dialog_Alert = 0x7f090013;
        public static final int Base_Theme_AppCompat_Dialog_FixedSize = 0x7f0900b6;
        public static final int Base_Theme_AppCompat_Dialog_MinWidth = 0x7f090014;
        public static final int Base_Theme_AppCompat_Light = 0x7f090062;
        public static final int Base_Theme_AppCompat_Light_DarkActionBar = 0x7f0900b7;
        public static final int Base_Theme_AppCompat_Light_Dialog = 0x7f090015;
        public static final int Base_Theme_AppCompat_Light_DialogWhenLarge = 0x7f090003;
        public static final int Base_Theme_AppCompat_Light_Dialog_Alert = 0x7f090016;
        public static final int Base_Theme_AppCompat_Light_Dialog_FixedSize = 0x7f0900b8;
        public static final int Base_Theme_AppCompat_Light_Dialog_MinWidth = 0x7f090017;
        public static final int Base_V11_ThemeOverlay_AppCompat_Dialog = 0x7f09001c;
        public static final int Base_V11_Theme_AppCompat_Dialog = 0x7f09001a;
        public static final int Base_V11_Theme_AppCompat_Light_Dialog = 0x7f09001b;
        public static final int Base_V12_Widget_AppCompat_AutoCompleteTextView = 0x7f090024;
        public static final int Base_V12_Widget_AppCompat_EditText = 0x7f090025;
        public static final int Base_V21_ThemeOverlay_AppCompat_Dialog = 0x7f090067;
        public static final int Base_V21_Theme_AppCompat = 0x7f090063;
        public static final int Base_V21_Theme_AppCompat_Dialog = 0x7f090064;
        public static final int Base_V21_Theme_AppCompat_Light = 0x7f090065;
        public static final int Base_V21_Theme_AppCompat_Light_Dialog = 0x7f090066;
        public static final int Base_V22_Theme_AppCompat = 0x7f090094;
        public static final int Base_V22_Theme_AppCompat_Light = 0x7f090095;
        public static final int Base_V23_Theme_AppCompat = 0x7f090098;
        public static final int Base_V23_Theme_AppCompat_Light = 0x7f090099;
        public static final int Base_V7_ThemeOverlay_AppCompat_Dialog = 0x7f0900c2;
        public static final int Base_V7_Theme_AppCompat = 0x7f0900be;
        public static final int Base_V7_Theme_AppCompat_Dialog = 0x7f0900bf;
        public static final int Base_V7_Theme_AppCompat_Light = 0x7f0900c0;
        public static final int Base_V7_Theme_AppCompat_Light_Dialog = 0x7f0900c1;
        public static final int Base_V7_Widget_AppCompat_AutoCompleteTextView = 0x7f0900c3;
        public static final int Base_V7_Widget_AppCompat_EditText = 0x7f0900c4;
        public static final int Base_Widget_AppCompat_ActionBar = 0x7f0900c5;
        public static final int Base_Widget_AppCompat_ActionBar_Solid = 0x7f0900c6;
        public static final int Base_Widget_AppCompat_ActionBar_TabBar = 0x7f0900c7;
        public static final int Base_Widget_AppCompat_ActionBar_TabText = 0x7f090068;
        public static final int Base_Widget_AppCompat_ActionBar_TabView = 0x7f090069;
        public static final int Base_Widget_AppCompat_ActionButton = 0x7f09006a;
        public static final int Base_Widget_AppCompat_ActionButton_CloseMode = 0x7f09006b;
        public static final int Base_Widget_AppCompat_ActionButton_Overflow = 0x7f09006c;
        public static final int Base_Widget_AppCompat_ActionMode = 0x7f0900c8;
        public static final int Base_Widget_AppCompat_ActivityChooserView = 0x7f0900c9;
        public static final int Base_Widget_AppCompat_AutoCompleteTextView = 0x7f090026;
        public static final int Base_Widget_AppCompat_Button = 0x7f09006d;
        public static final int Base_Widget_AppCompat_ButtonBar = 0x7f090071;
        public static final int Base_Widget_AppCompat_ButtonBar_AlertDialog = 0x7f0900cb;
        public static final int Base_Widget_AppCompat_Button_Borderless = 0x7f09006e;
        public static final int Base_Widget_AppCompat_Button_Borderless_Colored = 0x7f09006f;
        public static final int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 0x7f0900ca;
        public static final int Base_Widget_AppCompat_Button_Colored = 0x7f09009a;
        public static final int Base_Widget_AppCompat_Button_Small = 0x7f090070;
        public static final int Base_Widget_AppCompat_CompoundButton_CheckBox = 0x7f090072;
        public static final int Base_Widget_AppCompat_CompoundButton_RadioButton = 0x7f090073;
        public static final int Base_Widget_AppCompat_CompoundButton_Switch = 0x7f0900cc;
        public static final int Base_Widget_AppCompat_DrawerArrowToggle = 0x7f090000;
        public static final int Base_Widget_AppCompat_DrawerArrowToggle_Common = 0x7f0900cd;
        public static final int Base_Widget_AppCompat_DropDownItem_Spinner = 0x7f090074;
        public static final int Base_Widget_AppCompat_EditText = 0x7f090027;
        public static final int Base_Widget_AppCompat_ImageButton = 0x7f090075;
        public static final int Base_Widget_AppCompat_Light_ActionBar = 0x7f0900ce;
        public static final int Base_Widget_AppCompat_Light_ActionBar_Solid = 0x7f0900cf;
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabBar = 0x7f0900d0;
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabText = 0x7f090076;
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 0x7f090077;
        public static final int Base_Widget_AppCompat_Light_ActionBar_TabView = 0x7f090078;
        public static final int Base_Widget_AppCompat_Light_PopupMenu = 0x7f090079;
        public static final int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 0x7f09007a;
        public static final int Base_Widget_AppCompat_ListMenuView = 0x7f0900d1;
        public static final int Base_Widget_AppCompat_ListPopupWindow = 0x7f09007b;
        public static final int Base_Widget_AppCompat_ListView = 0x7f09007c;
        public static final int Base_Widget_AppCompat_ListView_DropDown = 0x7f09007d;
        public static final int Base_Widget_AppCompat_ListView_Menu = 0x7f09007e;
        public static final int Base_Widget_AppCompat_PopupMenu = 0x7f09007f;
        public static final int Base_Widget_AppCompat_PopupMenu_Overflow = 0x7f090080;
        public static final int Base_Widget_AppCompat_PopupWindow = 0x7f0900d2;
        public static final int Base_Widget_AppCompat_ProgressBar = 0x7f09001d;
        public static final int Base_Widget_AppCompat_ProgressBar_Horizontal = 0x7f09001e;
        public static final int Base_Widget_AppCompat_RatingBar = 0x7f090081;
        public static final int Base_Widget_AppCompat_RatingBar_Indicator = 0x7f09009b;
        public static final int Base_Widget_AppCompat_RatingBar_Small = 0x7f09009c;
        public static final int Base_Widget_AppCompat_SearchView = 0x7f0900d3;
        public static final int Base_Widget_AppCompat_SearchView_ActionBar = 0x7f0900d4;
        public static final int Base_Widget_AppCompat_SeekBar = 0x7f090082;
        public static final int Base_Widget_AppCompat_SeekBar_Discrete = 0x7f0900d5;
        public static final int Base_Widget_AppCompat_Spinner = 0x7f090083;
        public static final int Base_Widget_AppCompat_Spinner_Underlined = 0x7f090004;
        public static final int Base_Widget_AppCompat_TextView_SpinnerItem = 0x7f090084;
        public static final int Base_Widget_AppCompat_Toolbar = 0x7f0900d6;
        public static final int Base_Widget_AppCompat_Toolbar_Button_Navigation = 0x7f090085;
        public static final int Platform_AppCompat = 0x7f09001f;
        public static final int Platform_AppCompat_Light = 0x7f090020;
        public static final int Platform_ThemeOverlay_AppCompat = 0x7f090086;
        public static final int Platform_ThemeOverlay_AppCompat_Dark = 0x7f090087;
        public static final int Platform_ThemeOverlay_AppCompat_Light = 0x7f090088;
        public static final int Platform_V11_AppCompat = 0x7f090021;
        public static final int Platform_V11_AppCompat_Light = 0x7f090022;
        public static final int Platform_V14_AppCompat = 0x7f090029;
        public static final int Platform_V14_AppCompat_Light = 0x7f09002a;
        public static final int Platform_V21_AppCompat = 0x7f090089;
        public static final int Platform_V21_AppCompat_Light = 0x7f09008a;
        public static final int Platform_V25_AppCompat = 0x7f0900a0;
        public static final int Platform_V25_AppCompat_Light = 0x7f0900a1;
        public static final int Platform_Widget_AppCompat_Spinner = 0x7f090023;
        public static final int RtlOverlay_DialogWindowTitle_AppCompat = 0x7f090032;
        public static final int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 0x7f090033;
        public static final int RtlOverlay_Widget_AppCompat_DialogTitle_Icon = 0x7f090034;
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem = 0x7f090035;
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 0x7f090036;
        public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 0x7f090037;
        public static final int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 0x7f09003d;
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown = 0x7f090038;
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 0x7f090039;
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 0x7f09003a;
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 0x7f09003b;
        public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 0x7f09003c;
        public static final int RtlUnderlay_Widget_AppCompat_ActionButton = 0x7f09003e;
        public static final int RtlUnderlay_Widget_AppCompat_ActionButton_Overflow = 0x7f09003f;
        public static final int TextAppearance_AppCompat = 0x7f0900df;
        public static final int TextAppearance_AppCompat_Body1 = 0x7f0900e0;
        public static final int TextAppearance_AppCompat_Body2 = 0x7f0900e1;
        public static final int TextAppearance_AppCompat_Button = 0x7f0900e2;
        public static final int TextAppearance_AppCompat_Caption = 0x7f0900e3;
        public static final int TextAppearance_AppCompat_Display1 = 0x7f0900e4;
        public static final int TextAppearance_AppCompat_Display2 = 0x7f0900e5;
        public static final int TextAppearance_AppCompat_Display3 = 0x7f0900e6;
        public static final int TextAppearance_AppCompat_Display4 = 0x7f0900e7;
        public static final int TextAppearance_AppCompat_Headline = 0x7f0900e8;
        public static final int TextAppearance_AppCompat_Inverse = 0x7f0900e9;
        public static final int TextAppearance_AppCompat_Large = 0x7f0900ea;
        public static final int TextAppearance_AppCompat_Large_Inverse = 0x7f0900eb;
        public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 0x7f0900ec;
        public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 0x7f0900ed;
        public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 0x7f0900ee;
        public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 0x7f0900ef;
        public static final int TextAppearance_AppCompat_Medium = 0x7f0900f0;
        public static final int TextAppearance_AppCompat_Medium_Inverse = 0x7f0900f1;
        public static final int TextAppearance_AppCompat_Menu = 0x7f0900f2;
        public static final int TextAppearance_AppCompat_Notification = 0x7f09002b;
        public static final int TextAppearance_AppCompat_Notification_Info = 0x7f09008b;
        public static final int TextAppearance_AppCompat_Notification_Info_Media = 0x7f09008c;
        public static final int TextAppearance_AppCompat_Notification_Line2 = 0x7f0900f3;
        public static final int TextAppearance_AppCompat_Notification_Line2_Media = 0x7f0900f4;
        public static final int TextAppearance_AppCompat_Notification_Media = 0x7f09008d;
        public static final int TextAppearance_AppCompat_Notification_Time = 0x7f09008e;
        public static final int TextAppearance_AppCompat_Notification_Time_Media = 0x7f09008f;
        public static final int TextAppearance_AppCompat_Notification_Title = 0x7f09002c;
        public static final int TextAppearance_AppCompat_Notification_Title_Media = 0x7f090090;
        public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 0x7f0900f5;
        public static final int TextAppearance_AppCompat_SearchResult_Title = 0x7f0900f6;
        public static final int TextAppearance_AppCompat_Small = 0x7f0900f7;
        public static final int TextAppearance_AppCompat_Small_Inverse = 0x7f0900f8;
        public static final int TextAppearance_AppCompat_Subhead = 0x7f0900f9;
        public static final int TextAppearance_AppCompat_Subhead_Inverse = 0x7f0900fa;
        public static final int TextAppearance_AppCompat_Title = 0x7f0900fb;
        public static final int TextAppearance_AppCompat_Title_Inverse = 0x7f0900fc;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 0x7f0900fd;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 0x7f0900fe;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 0x7f0900ff;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 0x7f090100;
        public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 0x7f090101;
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 0x7f090102;
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 0x7f090103;
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 0x7f090104;
        public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 0x7f090105;
        public static final int TextAppearance_AppCompat_Widget_Button = 0x7f090106;
        public static final int TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 0x7f090107;
        public static final int TextAppearance_AppCompat_Widget_Button_Colored = 0x7f090108;
        public static final int TextAppearance_AppCompat_Widget_Button_Inverse = 0x7f090109;
        public static final int TextAppearance_AppCompat_Widget_DropDownItem = 0x7f09010a;
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Header = 0x7f09010b;
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 0x7f09010c;
        public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 0x7f09010d;
        public static final int TextAppearance_AppCompat_Widget_Switch = 0x7f09010e;
        public static final int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 0x7f09010f;
        public static final int TextAppearance_StatusBar_EventContent = 0x7f09002d;
        public static final int TextAppearance_StatusBar_EventContent_Info = 0x7f09002e;
        public static final int TextAppearance_StatusBar_EventContent_Line2 = 0x7f09002f;
        public static final int TextAppearance_StatusBar_EventContent_Time = 0x7f090030;
        public static final int TextAppearance_StatusBar_EventContent_Title = 0x7f090031;
        public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 0x7f090117;
        public static final int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 0x7f090118;
        public static final int TextAppearance_Widget_AppCompat_Toolbar_Title = 0x7f090119;
        public static final int ThemeOverlay_AppCompat = 0x7f09012e;
        public static final int ThemeOverlay_AppCompat_ActionBar = 0x7f09012f;
        public static final int ThemeOverlay_AppCompat_Dark = 0x7f090130;
        public static final int ThemeOverlay_AppCompat_Dark_ActionBar = 0x7f090131;
        public static final int ThemeOverlay_AppCompat_Dialog = 0x7f090132;
        public static final int ThemeOverlay_AppCompat_Dialog_Alert = 0x7f090133;
        public static final int ThemeOverlay_AppCompat_Light = 0x7f090134;
        public static final int Theme_AppCompat = 0x7f09011a;
        public static final int Theme_AppCompat_CompactMenu = 0x7f09011b;
        public static final int Theme_AppCompat_DayNight = 0x7f090005;
        public static final int Theme_AppCompat_DayNight_DarkActionBar = 0x7f090006;
        public static final int Theme_AppCompat_DayNight_Dialog = 0x7f090007;
        public static final int Theme_AppCompat_DayNight_DialogWhenLarge = 0x7f09000a;
        public static final int Theme_AppCompat_DayNight_Dialog_Alert = 0x7f090008;
        public static final int Theme_AppCompat_DayNight_Dialog_MinWidth = 0x7f090009;
        public static final int Theme_AppCompat_DayNight_NoActionBar = 0x7f09000b;
        public static final int Theme_AppCompat_Dialog = 0x7f09011c;
        public static final int Theme_AppCompat_DialogWhenLarge = 0x7f09011f;
        public static final int Theme_AppCompat_Dialog_Alert = 0x7f09011d;
        public static final int Theme_AppCompat_Dialog_MinWidth = 0x7f09011e;
        public static final int Theme_AppCompat_Light = 0x7f090120;
        public static final int Theme_AppCompat_Light_DarkActionBar = 0x7f090121;
        public static final int Theme_AppCompat_Light_Dialog = 0x7f090122;
        public static final int Theme_AppCompat_Light_DialogWhenLarge = 0x7f090125;
        public static final int Theme_AppCompat_Light_Dialog_Alert = 0x7f090123;
        public static final int Theme_AppCompat_Light_Dialog_MinWidth = 0x7f090124;
        public static final int Theme_AppCompat_Light_NoActionBar = 0x7f090126;
        public static final int Theme_AppCompat_NoActionBar = 0x7f090127;
        public static final int Widget_AppCompat_ActionBar = 0x7f090135;
        public static final int Widget_AppCompat_ActionBar_Solid = 0x7f090136;
        public static final int Widget_AppCompat_ActionBar_TabBar = 0x7f090137;
        public static final int Widget_AppCompat_ActionBar_TabText = 0x7f090138;
        public static final int Widget_AppCompat_ActionBar_TabView = 0x7f090139;
        public static final int Widget_AppCompat_ActionButton = 0x7f09013a;
        public static final int Widget_AppCompat_ActionButton_CloseMode = 0x7f09013b;
        public static final int Widget_AppCompat_ActionButton_Overflow = 0x7f09013c;
        public static final int Widget_AppCompat_ActionMode = 0x7f09013d;
        public static final int Widget_AppCompat_ActivityChooserView = 0x7f09013e;
        public static final int Widget_AppCompat_AutoCompleteTextView = 0x7f09013f;
        public static final int Widget_AppCompat_Button = 0x7f090140;
        public static final int Widget_AppCompat_ButtonBar = 0x7f090146;
        public static final int Widget_AppCompat_ButtonBar_AlertDialog = 0x7f090147;
        public static final int Widget_AppCompat_Button_Borderless = 0x7f090141;
        public static final int Widget_AppCompat_Button_Borderless_Colored = 0x7f090142;
        public static final int Widget_AppCompat_Button_ButtonBar_AlertDialog = 0x7f090143;
        public static final int Widget_AppCompat_Button_Colored = 0x7f090144;
        public static final int Widget_AppCompat_Button_Small = 0x7f090145;
        public static final int Widget_AppCompat_CompoundButton_CheckBox = 0x7f090148;
        public static final int Widget_AppCompat_CompoundButton_RadioButton = 0x7f090149;
        public static final int Widget_AppCompat_CompoundButton_Switch = 0x7f09014a;
        public static final int Widget_AppCompat_DrawerArrowToggle = 0x7f09014b;
        public static final int Widget_AppCompat_DropDownItem_Spinner = 0x7f09014c;
        public static final int Widget_AppCompat_EditText = 0x7f09014d;
        public static final int Widget_AppCompat_ImageButton = 0x7f09014e;
        public static final int Widget_AppCompat_Light_ActionBar = 0x7f09014f;
        public static final int Widget_AppCompat_Light_ActionBar_Solid = 0x7f090150;
        public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 0x7f090151;
        public static final int Widget_AppCompat_Light_ActionBar_TabBar = 0x7f090152;
        public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 0x7f090153;
        public static final int Widget_AppCompat_Light_ActionBar_TabText = 0x7f090154;
        public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 0x7f090155;
        public static final int Widget_AppCompat_Light_ActionBar_TabView = 0x7f090156;
        public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 0x7f090157;
        public static final int Widget_AppCompat_Light_ActionButton = 0x7f090158;
        public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 0x7f090159;
        public static final int Widget_AppCompat_Light_ActionButton_Overflow = 0x7f09015a;
        public static final int Widget_AppCompat_Light_ActionMode_Inverse = 0x7f09015b;
        public static final int Widget_AppCompat_Light_ActivityChooserView = 0x7f09015c;
        public static final int Widget_AppCompat_Light_AutoCompleteTextView = 0x7f09015d;
        public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 0x7f09015e;
        public static final int Widget_AppCompat_Light_ListPopupWindow = 0x7f09015f;
        public static final int Widget_AppCompat_Light_ListView_DropDown = 0x7f090160;
        public static final int Widget_AppCompat_Light_PopupMenu = 0x7f090161;
        public static final int Widget_AppCompat_Light_PopupMenu_Overflow = 0x7f090162;
        public static final int Widget_AppCompat_Light_SearchView = 0x7f090163;
        public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 0x7f090164;
        public static final int Widget_AppCompat_ListMenuView = 0x7f090165;
        public static final int Widget_AppCompat_ListPopupWindow = 0x7f090166;
        public static final int Widget_AppCompat_ListView = 0x7f090167;
        public static final int Widget_AppCompat_ListView_DropDown = 0x7f090168;
        public static final int Widget_AppCompat_ListView_Menu = 0x7f090169;
        public static final int Widget_AppCompat_NotificationActionContainer = 0x7f090091;
        public static final int Widget_AppCompat_NotificationActionText = 0x7f090092;
        public static final int Widget_AppCompat_PopupMenu = 0x7f09016a;
        public static final int Widget_AppCompat_PopupMenu_Overflow = 0x7f09016b;
        public static final int Widget_AppCompat_PopupWindow = 0x7f09016c;
        public static final int Widget_AppCompat_ProgressBar = 0x7f09016d;
        public static final int Widget_AppCompat_ProgressBar_Horizontal = 0x7f09016e;
        public static final int Widget_AppCompat_RatingBar = 0x7f09016f;
        public static final int Widget_AppCompat_RatingBar_Indicator = 0x7f090170;
        public static final int Widget_AppCompat_RatingBar_Small = 0x7f090171;
        public static final int Widget_AppCompat_SearchView = 0x7f090172;
        public static final int Widget_AppCompat_SearchView_ActionBar = 0x7f090173;
        public static final int Widget_AppCompat_SeekBar = 0x7f090174;
        public static final int Widget_AppCompat_SeekBar_Discrete = 0x7f090175;
        public static final int Widget_AppCompat_Spinner = 0x7f090176;
        public static final int Widget_AppCompat_Spinner_DropDown = 0x7f090177;
        public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 0x7f090178;
        public static final int Widget_AppCompat_Spinner_Underlined = 0x7f090179;
        public static final int Widget_AppCompat_TextView_SpinnerItem = 0x7f09017a;
        public static final int Widget_AppCompat_Toolbar = 0x7f09017b;
        public static final int Widget_AppCompat_Toolbar_Button_Navigation = 0x7f09017c;

        private style()
        {
        }
    }

    public static final class string
    {

        public static final int abc_action_bar_home_description = 0x7f070000;
        public static final int abc_action_bar_home_description_format = 0x7f070001;
        public static final int abc_action_bar_home_subtitle_description_format = 0x7f070002;
        public static final int abc_action_bar_up_description = 0x7f070003;
        public static final int abc_action_menu_overflow_description = 0x7f070004;
        public static final int abc_action_mode_done = 0x7f070005;
        public static final int abc_activity_chooser_view_see_all = 0x7f070006;
        public static final int abc_activitychooserview_choose_application = 0x7f070007;
        public static final int abc_capital_off = 0x7f070008;
        public static final int abc_capital_on = 0x7f070009;
        public static final int abc_font_family_body_1_material = 0x7f070036;
        public static final int abc_font_family_body_2_material = 0x7f070037;
        public static final int abc_font_family_button_material = 0x7f070038;
        public static final int abc_font_family_caption_material = 0x7f070039;
        public static final int abc_font_family_display_1_material = 0x7f07003a;
        public static final int abc_font_family_display_2_material = 0x7f07003b;
        public static final int abc_font_family_display_3_material = 0x7f07003c;
        public static final int abc_font_family_display_4_material = 0x7f07003d;
        public static final int abc_font_family_headline_material = 0x7f07003e;
        public static final int abc_font_family_menu_material = 0x7f07003f;
        public static final int abc_font_family_subhead_material = 0x7f070040;
        public static final int abc_font_family_title_material = 0x7f070041;
        public static final int abc_search_hint = 0x7f07000a;
        public static final int abc_searchview_description_clear = 0x7f07000b;
        public static final int abc_searchview_description_query = 0x7f07000c;
        public static final int abc_searchview_description_search = 0x7f07000d;
        public static final int abc_searchview_description_submit = 0x7f07000e;
        public static final int abc_searchview_description_voice = 0x7f07000f;
        public static final int abc_shareactionprovider_share_with = 0x7f070010;
        public static final int abc_shareactionprovider_share_with_application = 0x7f070011;
        public static final int abc_toolbar_collapse_description = 0x7f070012;
        public static final int search_menu_title = 0x7f070034;
        public static final int status_bar_notification_info_overflow = 0x7f070035;

        private string()
        {
        }
    }

    public static final class layout
    {

        public static final int abc_action_bar_title_item = 0x7f040000;
        public static final int abc_action_bar_up_container = 0x7f040001;
        public static final int abc_action_bar_view_list_nav_layout = 0x7f040002;
        public static final int abc_action_menu_item_layout = 0x7f040003;
        public static final int abc_action_menu_layout = 0x7f040004;
        public static final int abc_action_mode_bar = 0x7f040005;
        public static final int abc_action_mode_close_item_material = 0x7f040006;
        public static final int abc_activity_chooser_view = 0x7f040007;
        public static final int abc_activity_chooser_view_list_item = 0x7f040008;
        public static final int abc_alert_dialog_button_bar_material = 0x7f040009;
        public static final int abc_alert_dialog_material = 0x7f04000a;
        public static final int abc_alert_dialog_title_material = 0x7f04000b;
        public static final int abc_dialog_title_material = 0x7f04000c;
        public static final int abc_expanded_menu_layout = 0x7f04000d;
        public static final int abc_list_menu_item_checkbox = 0x7f04000e;
        public static final int abc_list_menu_item_icon = 0x7f04000f;
        public static final int abc_list_menu_item_layout = 0x7f040010;
        public static final int abc_list_menu_item_radio = 0x7f040011;
        public static final int abc_popup_menu_header_item_layout = 0x7f040012;
        public static final int abc_popup_menu_item_layout = 0x7f040013;
        public static final int abc_screen_content_include = 0x7f040014;
        public static final int abc_screen_simple = 0x7f040015;
        public static final int abc_screen_simple_overlay_action_mode = 0x7f040016;
        public static final int abc_screen_toolbar = 0x7f040017;
        public static final int abc_search_dropdown_item_icons_2line = 0x7f040018;
        public static final int abc_search_view = 0x7f040019;
        public static final int abc_select_dialog_material = 0x7f04001a;
        public static final int notification_action = 0x7f040032;
        public static final int notification_action_tombstone = 0x7f040033;
        public static final int notification_media_action = 0x7f040034;
        public static final int notification_media_cancel_action = 0x7f040035;
        public static final int notification_template_big_media = 0x7f040036;
        public static final int notification_template_big_media_custom = 0x7f040037;
        public static final int notification_template_big_media_narrow = 0x7f040038;
        public static final int notification_template_big_media_narrow_custom = 0x7f040039;
        public static final int notification_template_custom_big = 0x7f04003a;
        public static final int notification_template_icon_group = 0x7f04003b;
        public static final int notification_template_lines_media = 0x7f04003c;
        public static final int notification_template_media = 0x7f04003d;
        public static final int notification_template_media_custom = 0x7f04003e;
        public static final int notification_template_part_chronometer = 0x7f04003f;
        public static final int notification_template_part_time = 0x7f040040;
        public static final int select_dialog_item_material = 0x7f040045;
        public static final int select_dialog_multichoice_material = 0x7f040046;
        public static final int select_dialog_singlechoice_material = 0x7f040047;
        public static final int support_simple_spinner_dropdown_item = 0x7f040048;

        private layout()
        {
        }
    }

    public static final class integer
    {

        public static final int abc_config_activityDefaultDur = 0x7f0b0001;
        public static final int abc_config_activityShortDur = 0x7f0b0002;
        public static final int cancel_button_image_alpha = 0x7f0b0005;
        public static final int status_bar_notification_info_maxnum = 0x7f0b0009;

        private integer()
        {
        }
    }

    public static final class id
    {

        public static final int action0 = 0x7f0d00b6;
        public static final int action_bar = 0x7f0d0075;
        public static final int action_bar_activity_content = 0x7f0d0000;
        public static final int action_bar_container = 0x7f0d0074;
        public static final int action_bar_root = 0x7f0d0070;
        public static final int action_bar_spinner = 0x7f0d0001;
        public static final int action_bar_subtitle = 0x7f0d0053;
        public static final int action_bar_title = 0x7f0d0052;
        public static final int action_container = 0x7f0d00b3;
        public static final int action_context_bar = 0x7f0d0076;
        public static final int action_divider = 0x7f0d00ba;
        public static final int action_image = 0x7f0d00b4;
        public static final int action_menu_divider = 0x7f0d0002;
        public static final int action_menu_presenter = 0x7f0d0003;
        public static final int action_mode_bar = 0x7f0d0072;
        public static final int action_mode_bar_stub = 0x7f0d0071;
        public static final int action_mode_close_button = 0x7f0d0054;
        public static final int action_text = 0x7f0d00b5;
        public static final int actions = 0x7f0d00c2;
        public static final int activity_chooser_view_content = 0x7f0d0055;
        public static final int add = 0x7f0d0026;
        public static final int alertTitle = 0x7f0d0069;
        public static final int always = 0x7f0d0046;
        public static final int beginning = 0x7f0d003f;
        public static final int bottom = 0x7f0d002e;
        public static final int buttonPanel = 0x7f0d005c;
        public static final int cancel_action = 0x7f0d00b7;
        public static final int checkbox = 0x7f0d006c;
        public static final int chronometer = 0x7f0d00bf;
        public static final int collapseActionView = 0x7f0d0047;
        public static final int contentPanel = 0x7f0d005f;
        public static final int custom = 0x7f0d0066;
        public static final int customPanel = 0x7f0d0065;
        public static final int decor_content_parent = 0x7f0d0073;
        public static final int default_activity_button = 0x7f0d0058;
        public static final int disableHome = 0x7f0d001b;
        public static final int edit_query = 0x7f0d0077;
        public static final int end = 0x7f0d0032;
        public static final int end_padder = 0x7f0d00c9;
        public static final int expand_activities_button = 0x7f0d0056;
        public static final int expanded_menu = 0x7f0d006b;
        public static final int home = 0x7f0d0004;
        public static final int homeAsUp = 0x7f0d001c;
        public static final int icon = 0x7f0d005a;
        public static final int icon_group = 0x7f0d00c3;
        public static final int ifRoom = 0x7f0d0048;
        public static final int image = 0x7f0d0057;
        public static final int info = 0x7f0d00c0;
        public static final int line1 = 0x7f0d00c5;
        public static final int line3 = 0x7f0d00c7;
        public static final int listMode = 0x7f0d0018;
        public static final int list_item = 0x7f0d0059;
        public static final int media_actions = 0x7f0d00b9;
        public static final int middle = 0x7f0d0040;
        public static final int multiply = 0x7f0d0027;
        public static final int never = 0x7f0d0049;
        public static final int none = 0x7f0d0017;
        public static final int normal = 0x7f0d0019;
        public static final int notification_background = 0x7f0d00c1;
        public static final int notification_main_column = 0x7f0d00bc;
        public static final int notification_main_column_container = 0x7f0d00bb;
        public static final int parentPanel = 0x7f0d005e;
        public static final int progress_circular = 0x7f0d0006;
        public static final int progress_horizontal = 0x7f0d0007;
        public static final int radio = 0x7f0d006e;
        public static final int right_icon = 0x7f0d00c4;
        public static final int right_side = 0x7f0d00bd;
        public static final int screen = 0x7f0d0028;
        public static final int scrollIndicatorDown = 0x7f0d0064;
        public static final int scrollIndicatorUp = 0x7f0d0060;
        public static final int scrollView = 0x7f0d0061;
        public static final int search_badge = 0x7f0d0079;
        public static final int search_bar = 0x7f0d0078;
        public static final int search_button = 0x7f0d007a;
        public static final int search_close_btn = 0x7f0d007f;
        public static final int search_edit_frame = 0x7f0d007b;
        public static final int search_go_btn = 0x7f0d0081;
        public static final int search_mag_icon = 0x7f0d007c;
        public static final int search_plate = 0x7f0d007d;
        public static final int search_src_text = 0x7f0d007e;
        public static final int search_voice_btn = 0x7f0d0082;
        public static final int select_dialog_listview = 0x7f0d0083;
        public static final int shortcut = 0x7f0d006d;
        public static final int showCustom = 0x7f0d001d;
        public static final int showHome = 0x7f0d001e;
        public static final int showTitle = 0x7f0d001f;
        public static final int spacer = 0x7f0d005d;
        public static final int split_action_bar = 0x7f0d0008;
        public static final int src_atop = 0x7f0d0029;
        public static final int src_in = 0x7f0d002a;
        public static final int src_over = 0x7f0d002b;
        public static final int status_bar_latest_event_content = 0x7f0d00b8;
        public static final int submenuarrow = 0x7f0d006f;
        public static final int submit_area = 0x7f0d0080;
        public static final int tabMode = 0x7f0d001a;
        public static final int text = 0x7f0d00c8;
        public static final int text2 = 0x7f0d00c6;
        public static final int textSpacerNoButtons = 0x7f0d0063;
        public static final int textSpacerNoTitle = 0x7f0d0062;
        public static final int time = 0x7f0d00be;
        public static final int title = 0x7f0d005b;
        public static final int titleDividerNoCustom = 0x7f0d006a;
        public static final int title_template = 0x7f0d0068;
        public static final int top = 0x7f0d0037;
        public static final int topPanel = 0x7f0d0067;
        public static final int up = 0x7f0d000d;
        public static final int useLogo = 0x7f0d0020;
        public static final int withText = 0x7f0d004a;
        public static final int wrap_content = 0x7f0d002c;

        private id()
        {
        }
    }

    public static final class drawable
    {

        public static final int abc_ab_share_pack_mtrl_alpha = 0x7f020000;
        public static final int abc_action_bar_item_background_material = 0x7f020001;
        public static final int abc_btn_borderless_material = 0x7f020002;
        public static final int abc_btn_check_material = 0x7f020003;
        public static final int abc_btn_check_to_on_mtrl_000 = 0x7f020004;
        public static final int abc_btn_check_to_on_mtrl_015 = 0x7f020005;
        public static final int abc_btn_colored_material = 0x7f020006;
        public static final int abc_btn_default_mtrl_shape = 0x7f020007;
        public static final int abc_btn_radio_material = 0x7f020008;
        public static final int abc_btn_radio_to_on_mtrl_000 = 0x7f020009;
        public static final int abc_btn_radio_to_on_mtrl_015 = 0x7f02000a;
        public static final int abc_btn_switch_to_on_mtrl_00001 = 0x7f02000b;
        public static final int abc_btn_switch_to_on_mtrl_00012 = 0x7f02000c;
        public static final int abc_cab_background_internal_bg = 0x7f02000d;
        public static final int abc_cab_background_top_material = 0x7f02000e;
        public static final int abc_cab_background_top_mtrl_alpha = 0x7f02000f;
        public static final int abc_control_background_material = 0x7f020010;
        public static final int abc_dialog_material_background = 0x7f020011;
        public static final int abc_edit_text_material = 0x7f020012;
        public static final int abc_ic_ab_back_material = 0x7f020013;
        public static final int abc_ic_arrow_drop_right_black_24dp = 0x7f020014;
        public static final int abc_ic_clear_material = 0x7f020015;
        public static final int abc_ic_commit_search_api_mtrl_alpha = 0x7f020016;
        public static final int abc_ic_go_search_api_material = 0x7f020017;
        public static final int abc_ic_menu_copy_mtrl_am_alpha = 0x7f020018;
        public static final int abc_ic_menu_cut_mtrl_alpha = 0x7f020019;
        public static final int abc_ic_menu_overflow_material = 0x7f02001a;
        public static final int abc_ic_menu_paste_mtrl_am_alpha = 0x7f02001b;
        public static final int abc_ic_menu_selectall_mtrl_alpha = 0x7f02001c;
        public static final int abc_ic_menu_share_mtrl_alpha = 0x7f02001d;
        public static final int abc_ic_search_api_material = 0x7f02001e;
        public static final int abc_ic_star_black_16dp = 0x7f02001f;
        public static final int abc_ic_star_black_36dp = 0x7f020020;
        public static final int abc_ic_star_black_48dp = 0x7f020021;
        public static final int abc_ic_star_half_black_16dp = 0x7f020022;
        public static final int abc_ic_star_half_black_36dp = 0x7f020023;
        public static final int abc_ic_star_half_black_48dp = 0x7f020024;
        public static final int abc_ic_voice_search_api_material = 0x7f020025;
        public static final int abc_item_background_holo_dark = 0x7f020026;
        public static final int abc_item_background_holo_light = 0x7f020027;
        public static final int abc_list_divider_mtrl_alpha = 0x7f020028;
        public static final int abc_list_focused_holo = 0x7f020029;
        public static final int abc_list_longpressed_holo = 0x7f02002a;
        public static final int abc_list_pressed_holo_dark = 0x7f02002b;
        public static final int abc_list_pressed_holo_light = 0x7f02002c;
        public static final int abc_list_selector_background_transition_holo_dark = 0x7f02002d;
        public static final int abc_list_selector_background_transition_holo_light = 0x7f02002e;
        public static final int abc_list_selector_disabled_holo_dark = 0x7f02002f;
        public static final int abc_list_selector_disabled_holo_light = 0x7f020030;
        public static final int abc_list_selector_holo_dark = 0x7f020031;
        public static final int abc_list_selector_holo_light = 0x7f020032;
        public static final int abc_menu_hardkey_panel_mtrl_mult = 0x7f020033;
        public static final int abc_popup_background_mtrl_mult = 0x7f020034;
        public static final int abc_ratingbar_indicator_material = 0x7f020035;
        public static final int abc_ratingbar_material = 0x7f020036;
        public static final int abc_ratingbar_small_material = 0x7f020037;
        public static final int abc_scrubber_control_off_mtrl_alpha = 0x7f020038;
        public static final int abc_scrubber_control_to_pressed_mtrl_000 = 0x7f020039;
        public static final int abc_scrubber_control_to_pressed_mtrl_005 = 0x7f02003a;
        public static final int abc_scrubber_primary_mtrl_alpha = 0x7f02003b;
        public static final int abc_scrubber_track_mtrl_alpha = 0x7f02003c;
        public static final int abc_seekbar_thumb_material = 0x7f02003d;
        public static final int abc_seekbar_tick_mark_material = 0x7f02003e;
        public static final int abc_seekbar_track_material = 0x7f02003f;
        public static final int abc_spinner_mtrl_am_alpha = 0x7f020040;
        public static final int abc_spinner_textfield_background_material = 0x7f020041;
        public static final int abc_switch_thumb_material = 0x7f020042;
        public static final int abc_switch_track_mtrl_alpha = 0x7f020043;
        public static final int abc_tab_indicator_material = 0x7f020044;
        public static final int abc_tab_indicator_mtrl_alpha = 0x7f020045;
        public static final int abc_text_cursor_material = 0x7f020046;
        public static final int abc_text_select_handle_left_mtrl_dark = 0x7f020047;
        public static final int abc_text_select_handle_left_mtrl_light = 0x7f020048;
        public static final int abc_text_select_handle_middle_mtrl_dark = 0x7f020049;
        public static final int abc_text_select_handle_middle_mtrl_light = 0x7f02004a;
        public static final int abc_text_select_handle_right_mtrl_dark = 0x7f02004b;
        public static final int abc_text_select_handle_right_mtrl_light = 0x7f02004c;
        public static final int abc_textfield_activated_mtrl_alpha = 0x7f02004d;
        public static final int abc_textfield_default_mtrl_alpha = 0x7f02004e;
        public static final int abc_textfield_search_activated_mtrl_alpha = 0x7f02004f;
        public static final int abc_textfield_search_default_mtrl_alpha = 0x7f020050;
        public static final int abc_textfield_search_material = 0x7f020051;
        public static final int abc_vector_test = 0x7f020052;
        public static final int notification_action_background = 0x7f020092;
        public static final int notification_bg = 0x7f020093;
        public static final int notification_bg_low = 0x7f020094;
        public static final int notification_bg_low_normal = 0x7f020095;
        public static final int notification_bg_low_pressed = 0x7f020096;
        public static final int notification_bg_normal = 0x7f020097;
        public static final int notification_bg_normal_pressed = 0x7f020098;
        public static final int notification_icon_background = 0x7f020099;
        public static final int notification_template_icon_bg = 0x7f0200a3;
        public static final int notification_template_icon_low_bg = 0x7f0200a4;
        public static final int notification_tile_bg = 0x7f02009a;
        public static final int notify_panel_notification_icon_bg = 0x7f02009b;

        private drawable()
        {
        }
    }

    public static final class dimen
    {

        public static final int abc_action_bar_content_inset_material = 0x7f08000c;
        public static final int abc_action_bar_content_inset_with_nav = 0x7f08000d;
        public static final int abc_action_bar_default_height_material = 0x7f080001;
        public static final int abc_action_bar_default_padding_end_material = 0x7f08000e;
        public static final int abc_action_bar_default_padding_start_material = 0x7f08000f;
        public static final int abc_action_bar_elevation_material = 0x7f08001d;
        public static final int abc_action_bar_icon_vertical_padding_material = 0x7f08001e;
        public static final int abc_action_bar_overflow_padding_end_material = 0x7f08001f;
        public static final int abc_action_bar_overflow_padding_start_material = 0x7f080020;
        public static final int abc_action_bar_progress_bar_size = 0x7f080002;
        public static final int abc_action_bar_stacked_max_height = 0x7f080021;
        public static final int abc_action_bar_stacked_tab_max_width = 0x7f080022;
        public static final int abc_action_bar_subtitle_bottom_margin_material = 0x7f080023;
        public static final int abc_action_bar_subtitle_top_margin_material = 0x7f080024;
        public static final int abc_action_button_min_height_material = 0x7f080025;
        public static final int abc_action_button_min_width_material = 0x7f080026;
        public static final int abc_action_button_min_width_overflow_material = 0x7f080027;
        public static final int abc_alert_dialog_button_bar_height = 0x7f080000;
        public static final int abc_button_inset_horizontal_material = 0x7f080028;
        public static final int abc_button_inset_vertical_material = 0x7f080029;
        public static final int abc_button_padding_horizontal_material = 0x7f08002a;
        public static final int abc_button_padding_vertical_material = 0x7f08002b;
        public static final int abc_cascading_menus_min_smallest_width = 0x7f08002c;
        public static final int abc_config_prefDialogWidth = 0x7f080005;
        public static final int abc_control_corner_material = 0x7f08002d;
        public static final int abc_control_inset_material = 0x7f08002e;
        public static final int abc_control_padding_material = 0x7f08002f;
        public static final int abc_dialog_fixed_height_major = 0x7f080006;
        public static final int abc_dialog_fixed_height_minor = 0x7f080007;
        public static final int abc_dialog_fixed_width_major = 0x7f080008;
        public static final int abc_dialog_fixed_width_minor = 0x7f080009;
        public static final int abc_dialog_list_padding_bottom_no_buttons = 0x7f080030;
        public static final int abc_dialog_list_padding_top_no_title = 0x7f080031;
        public static final int abc_dialog_min_width_major = 0x7f08000a;
        public static final int abc_dialog_min_width_minor = 0x7f08000b;
        public static final int abc_dialog_padding_material = 0x7f080032;
        public static final int abc_dialog_padding_top_material = 0x7f080033;
        public static final int abc_dialog_title_divider_material = 0x7f080034;
        public static final int abc_disabled_alpha_material_dark = 0x7f080035;
        public static final int abc_disabled_alpha_material_light = 0x7f080036;
        public static final int abc_dropdownitem_icon_width = 0x7f080037;
        public static final int abc_dropdownitem_text_padding_left = 0x7f080038;
        public static final int abc_dropdownitem_text_padding_right = 0x7f080039;
        public static final int abc_edit_text_inset_bottom_material = 0x7f08003a;
        public static final int abc_edit_text_inset_horizontal_material = 0x7f08003b;
        public static final int abc_edit_text_inset_top_material = 0x7f08003c;
        public static final int abc_floating_window_z = 0x7f08003d;
        public static final int abc_list_item_padding_horizontal_material = 0x7f08003e;
        public static final int abc_panel_menu_list_width = 0x7f08003f;
        public static final int abc_progress_bar_height_material = 0x7f080040;
        public static final int abc_search_view_preferred_height = 0x7f080041;
        public static final int abc_search_view_preferred_width = 0x7f080042;
        public static final int abc_seekbar_track_background_height_material = 0x7f080043;
        public static final int abc_seekbar_track_progress_height_material = 0x7f080044;
        public static final int abc_select_dialog_padding_start_material = 0x7f080045;
        public static final int abc_switch_padding = 0x7f080019;
        public static final int abc_text_size_body_1_material = 0x7f080046;
        public static final int abc_text_size_body_2_material = 0x7f080047;
        public static final int abc_text_size_button_material = 0x7f080048;
        public static final int abc_text_size_caption_material = 0x7f080049;
        public static final int abc_text_size_display_1_material = 0x7f08004a;
        public static final int abc_text_size_display_2_material = 0x7f08004b;
        public static final int abc_text_size_display_3_material = 0x7f08004c;
        public static final int abc_text_size_display_4_material = 0x7f08004d;
        public static final int abc_text_size_headline_material = 0x7f08004e;
        public static final int abc_text_size_large_material = 0x7f08004f;
        public static final int abc_text_size_medium_material = 0x7f080050;
        public static final int abc_text_size_menu_header_material = 0x7f080051;
        public static final int abc_text_size_menu_material = 0x7f080052;
        public static final int abc_text_size_small_material = 0x7f080053;
        public static final int abc_text_size_subhead_material = 0x7f080054;
        public static final int abc_text_size_subtitle_material_toolbar = 0x7f080003;
        public static final int abc_text_size_title_material = 0x7f080055;
        public static final int abc_text_size_title_material_toolbar = 0x7f080004;
        public static final int disabled_alpha_material_dark = 0x7f080079;
        public static final int disabled_alpha_material_light = 0x7f08007a;
        public static final int highlight_alpha_material_colored = 0x7f08007c;
        public static final int highlight_alpha_material_dark = 0x7f08007d;
        public static final int highlight_alpha_material_light = 0x7f08007e;
        public static final int hint_alpha_material_dark = 0x7f08007f;
        public static final int hint_alpha_material_light = 0x7f080080;
        public static final int hint_pressed_alpha_material_dark = 0x7f080081;
        public static final int hint_pressed_alpha_material_light = 0x7f080082;
        public static final int notification_action_icon_size = 0x7f080089;
        public static final int notification_action_text_size = 0x7f08008a;
        public static final int notification_big_circle_margin = 0x7f08008b;
        public static final int notification_content_margin_start = 0x7f08001a;
        public static final int notification_large_icon_height = 0x7f08008c;
        public static final int notification_large_icon_width = 0x7f08008d;
        public static final int notification_main_column_padding_top = 0x7f08001b;
        public static final int notification_media_narrow_margin = 0x7f08001c;
        public static final int notification_right_icon_size = 0x7f08008e;
        public static final int notification_right_side_padding_top = 0x7f080018;
        public static final int notification_small_icon_background_padding = 0x7f08008f;
        public static final int notification_small_icon_size_as_large = 0x7f080090;
        public static final int notification_subtext_size = 0x7f080091;
        public static final int notification_top_pad = 0x7f080092;
        public static final int notification_top_pad_large_text = 0x7f080093;

        private dimen()
        {
        }
    }

    public static final class color
    {

        public static final int abc_background_cache_hint_selector_material_dark = 0x7f0c0071;
        public static final int abc_background_cache_hint_selector_material_light = 0x7f0c0072;
        public static final int abc_btn_colored_borderless_text_material = 0x7f0c0073;
        public static final int abc_btn_colored_text_material = 0x7f0c0074;
        public static final int abc_color_highlight_material = 0x7f0c0075;
        public static final int abc_hint_foreground_material_dark = 0x7f0c0076;
        public static final int abc_hint_foreground_material_light = 0x7f0c0077;
        public static final int abc_input_method_navigation_guard = 0x7f0c0001;
        public static final int abc_primary_text_disable_only_material_dark = 0x7f0c0078;
        public static final int abc_primary_text_disable_only_material_light = 0x7f0c0079;
        public static final int abc_primary_text_material_dark = 0x7f0c007a;
        public static final int abc_primary_text_material_light = 0x7f0c007b;
        public static final int abc_search_url_text = 0x7f0c007c;
        public static final int abc_search_url_text_normal = 0x7f0c0002;
        public static final int abc_search_url_text_pressed = 0x7f0c0003;
        public static final int abc_search_url_text_selected = 0x7f0c0004;
        public static final int abc_secondary_text_material_dark = 0x7f0c007d;
        public static final int abc_secondary_text_material_light = 0x7f0c007e;
        public static final int abc_tint_btn_checkable = 0x7f0c007f;
        public static final int abc_tint_default = 0x7f0c0080;
        public static final int abc_tint_edittext = 0x7f0c0081;
        public static final int abc_tint_seek_thumb = 0x7f0c0082;
        public static final int abc_tint_spinner = 0x7f0c0083;
        public static final int abc_tint_switch_thumb = 0x7f0c0084;
        public static final int abc_tint_switch_track = 0x7f0c0085;
        public static final int accent_material_dark = 0x7f0c0005;
        public static final int accent_material_light = 0x7f0c0006;
        public static final int background_floating_material_dark = 0x7f0c0007;
        public static final int background_floating_material_light = 0x7f0c0008;
        public static final int background_material_dark = 0x7f0c0009;
        public static final int background_material_light = 0x7f0c000a;
        public static final int bright_foreground_disabled_material_dark = 0x7f0c000e;
        public static final int bright_foreground_disabled_material_light = 0x7f0c000f;
        public static final int bright_foreground_inverse_material_dark = 0x7f0c0010;
        public static final int bright_foreground_inverse_material_light = 0x7f0c0011;
        public static final int bright_foreground_material_dark = 0x7f0c0012;
        public static final int bright_foreground_material_light = 0x7f0c0013;
        public static final int button_material_dark = 0x7f0c0017;
        public static final int button_material_light = 0x7f0c0018;
        public static final int dim_foreground_disabled_material_dark = 0x7f0c003b;
        public static final int dim_foreground_disabled_material_light = 0x7f0c003c;
        public static final int dim_foreground_material_dark = 0x7f0c003d;
        public static final int dim_foreground_material_light = 0x7f0c003e;
        public static final int foreground_material_dark = 0x7f0c003f;
        public static final int foreground_material_light = 0x7f0c0040;
        public static final int highlighted_text_material_dark = 0x7f0c0041;
        public static final int highlighted_text_material_light = 0x7f0c0042;
        public static final int material_blue_grey_800 = 0x7f0c0049;
        public static final int material_blue_grey_900 = 0x7f0c004a;
        public static final int material_blue_grey_950 = 0x7f0c004b;
        public static final int material_deep_teal_200 = 0x7f0c004c;
        public static final int material_deep_teal_500 = 0x7f0c004d;
        public static final int material_grey_100 = 0x7f0c004e;
        public static final int material_grey_300 = 0x7f0c004f;
        public static final int material_grey_50 = 0x7f0c0050;
        public static final int material_grey_600 = 0x7f0c0051;
        public static final int material_grey_800 = 0x7f0c0052;
        public static final int material_grey_850 = 0x7f0c0053;
        public static final int material_grey_900 = 0x7f0c0054;
        public static final int notification_action_color_filter = 0x7f0c0000;
        public static final int notification_icon_bg_color = 0x7f0c0055;
        public static final int notification_material_background_media_default_color = 0x7f0c0056;
        public static final int primary_dark_material_dark = 0x7f0c005d;
        public static final int primary_dark_material_light = 0x7f0c005e;
        public static final int primary_material_dark = 0x7f0c005f;
        public static final int primary_material_light = 0x7f0c0060;
        public static final int primary_text_default_material_dark = 0x7f0c0061;
        public static final int primary_text_default_material_light = 0x7f0c0062;
        public static final int primary_text_disabled_material_dark = 0x7f0c0063;
        public static final int primary_text_disabled_material_light = 0x7f0c0064;
        public static final int ripple_material_dark = 0x7f0c0065;
        public static final int ripple_material_light = 0x7f0c0066;
        public static final int secondary_text_default_material_dark = 0x7f0c0067;
        public static final int secondary_text_default_material_light = 0x7f0c0068;
        public static final int secondary_text_disabled_material_dark = 0x7f0c0069;
        public static final int secondary_text_disabled_material_light = 0x7f0c006a;
        public static final int switch_thumb_disabled_material_dark = 0x7f0c006b;
        public static final int switch_thumb_disabled_material_light = 0x7f0c006c;
        public static final int switch_thumb_material_dark = 0x7f0c008c;
        public static final int switch_thumb_material_light = 0x7f0c008d;
        public static final int switch_thumb_normal_material_dark = 0x7f0c006d;
        public static final int switch_thumb_normal_material_light = 0x7f0c006e;

        private color()
        {
        }
    }

    public static final class bool
    {

        public static final int abc_action_bar_embed_tabs = 0x7f0a0000;
        public static final int abc_allow_stacked_button_bar = 0x7f0a0001;
        public static final int abc_config_actionMenuItemAllCaps = 0x7f0a0002;
        public static final int abc_config_closeDialogWhenTouchOutside = 0x7f0a0003;
        public static final int abc_config_showMenuShortcutsWhenKeyboardPresent = 0x7f0a0004;

        private bool()
        {
        }
    }

    public static final class attr
    {

        public static final int actionBarDivider = 0x7f010072;
        public static final int actionBarItemBackground = 0x7f010073;
        public static final int actionBarPopupTheme = 0x7f01006c;
        public static final int actionBarSize = 0x7f010071;
        public static final int actionBarSplitStyle = 0x7f01006e;
        public static final int actionBarStyle = 0x7f01006d;
        public static final int actionBarTabBarStyle = 0x7f010068;
        public static final int actionBarTabStyle = 0x7f010067;
        public static final int actionBarTabTextStyle = 0x7f010069;
        public static final int actionBarTheme = 0x7f01006f;
        public static final int actionBarWidgetTheme = 0x7f010070;
        public static final int actionButtonStyle = 0x7f01008d;
        public static final int actionDropDownStyle = 0x7f010089;
        public static final int actionLayout = 0x7f010123;
        public static final int actionMenuTextAppearance = 0x7f010074;
        public static final int actionMenuTextColor = 0x7f010075;
        public static final int actionModeBackground = 0x7f010078;
        public static final int actionModeCloseButtonStyle = 0x7f010077;
        public static final int actionModeCloseDrawable = 0x7f01007a;
        public static final int actionModeCopyDrawable = 0x7f01007c;
        public static final int actionModeCutDrawable = 0x7f01007b;
        public static final int actionModeFindDrawable = 0x7f010080;
        public static final int actionModePasteDrawable = 0x7f01007d;
        public static final int actionModePopupWindowStyle = 0x7f010082;
        public static final int actionModeSelectAllDrawable = 0x7f01007e;
        public static final int actionModeShareDrawable = 0x7f01007f;
        public static final int actionModeSplitBackground = 0x7f010079;
        public static final int actionModeStyle = 0x7f010076;
        public static final int actionModeWebSearchDrawable = 0x7f010081;
        public static final int actionOverflowButtonStyle = 0x7f01006a;
        public static final int actionOverflowMenuStyle = 0x7f01006b;
        public static final int actionProviderClass = 0x7f010125;
        public static final int actionViewClass = 0x7f010124;
        public static final int activityChooserViewStyle = 0x7f010095;
        public static final int alertDialogButtonGroupStyle = 0x7f0100b9;
        public static final int alertDialogCenterButtons = 0x7f0100ba;
        public static final int alertDialogStyle = 0x7f0100b8;
        public static final int alertDialogTheme = 0x7f0100bb;
        public static final int allowStacking = 0x7f0100d1;
        public static final int alpha = 0x7f0100ee;
        public static final int arrowHeadLength = 0x7f010100;
        public static final int arrowShaftLength = 0x7f010101;
        public static final int autoCompleteTextViewStyle = 0x7f0100c0;
        public static final int background = 0x7f010038;
        public static final int backgroundSplit = 0x7f01003a;
        public static final int backgroundStacked = 0x7f010039;
        public static final int backgroundTint = 0x7f010186;
        public static final int backgroundTintMode = 0x7f010187;
        public static final int barLength = 0x7f010102;
        public static final int borderlessButtonStyle = 0x7f010092;
        public static final int buttonBarButtonStyle = 0x7f01008f;
        public static final int buttonBarNegativeButtonStyle = 0x7f0100be;
        public static final int buttonBarNeutralButtonStyle = 0x7f0100bf;
        public static final int buttonBarPositiveButtonStyle = 0x7f0100bd;
        public static final int buttonBarStyle = 0x7f01008e;
        public static final int buttonGravity = 0x7f01017b;
        public static final int buttonPanelSideLayout = 0x7f01004d;
        public static final int buttonStyle = 0x7f0100c1;
        public static final int buttonStyleSmall = 0x7f0100c2;
        public static final int buttonTint = 0x7f0100ef;
        public static final int buttonTintMode = 0x7f0100f0;
        public static final int checkboxStyle = 0x7f0100c3;
        public static final int checkedTextViewStyle = 0x7f0100c4;
        public static final int closeIcon = 0x7f01013c;
        public static final int closeItemLayout = 0x7f01004a;
        public static final int collapseContentDescription = 0x7f01017d;
        public static final int collapseIcon = 0x7f01017c;
        public static final int color = 0x7f0100fc;
        public static final int colorAccent = 0x7f0100b0;
        public static final int colorBackgroundFloating = 0x7f0100b7;
        public static final int colorButtonNormal = 0x7f0100b4;
        public static final int colorControlActivated = 0x7f0100b2;
        public static final int colorControlHighlight = 0x7f0100b3;
        public static final int colorControlNormal = 0x7f0100b1;
        public static final int colorPrimary = 0x7f0100ae;
        public static final int colorPrimaryDark = 0x7f0100af;
        public static final int colorSwitchThumbNormal = 0x7f0100b5;
        public static final int commitIcon = 0x7f010141;
        public static final int contentInsetEnd = 0x7f010043;
        public static final int contentInsetEndWithActions = 0x7f010047;
        public static final int contentInsetLeft = 0x7f010044;
        public static final int contentInsetRight = 0x7f010045;
        public static final int contentInsetStart = 0x7f010042;
        public static final int contentInsetStartWithNavigation = 0x7f010046;
        public static final int controlBackground = 0x7f0100b6;
        public static final int customNavigationLayout = 0x7f01003b;
        public static final int defaultQueryHint = 0x7f01013b;
        public static final int dialogPreferredPadding = 0x7f010087;
        public static final int dialogTheme = 0x7f010086;
        public static final int displayOptions = 0x7f010031;
        public static final int divider = 0x7f010037;
        public static final int dividerHorizontal = 0x7f010094;
        public static final int dividerPadding = 0x7f01010d;
        public static final int dividerVertical = 0x7f010093;
        public static final int drawableSize = 0x7f0100fe;
        public static final int drawerArrowStyle = 0x7f010001;
        public static final int dropDownListViewStyle = 0x7f0100a6;
        public static final int dropdownListPreferredItemHeight = 0x7f01008a;
        public static final int editTextBackground = 0x7f01009b;
        public static final int editTextColor = 0x7f01009a;
        public static final int editTextStyle = 0x7f0100c5;
        public static final int elevation = 0x7f010048;
        public static final int expandActivityOverflowButtonDrawable = 0x7f01004c;
        public static final int gapBetweenBars = 0x7f0100ff;
        public static final int goIcon = 0x7f01013d;
        public static final int height = 0x7f010002;
        public static final int hideOnContentScroll = 0x7f010041;
        public static final int homeAsUpIndicator = 0x7f01008c;
        public static final int homeLayout = 0x7f01003c;
        public static final int icon = 0x7f010035;
        public static final int iconifiedByDefault = 0x7f010139;
        public static final int imageButtonStyle = 0x7f01009c;
        public static final int indeterminateProgressStyle = 0x7f01003e;
        public static final int initialActivityCount = 0x7f01004b;
        public static final int isLightTheme = 0x7f010003;
        public static final int itemPadding = 0x7f010040;
        public static final int layout = 0x7f010138;
        public static final int listChoiceBackgroundIndicator = 0x7f0100ad;
        public static final int listDividerAlertDialog = 0x7f010088;
        public static final int listItemLayout = 0x7f010051;
        public static final int listLayout = 0x7f01004e;
        public static final int listMenuViewStyle = 0x7f0100cd;
        public static final int listPopupWindowStyle = 0x7f0100a7;
        public static final int listPreferredItemHeight = 0x7f0100a1;
        public static final int listPreferredItemHeightLarge = 0x7f0100a3;
        public static final int listPreferredItemHeightSmall = 0x7f0100a2;
        public static final int listPreferredItemPaddingLeft = 0x7f0100a4;
        public static final int listPreferredItemPaddingRight = 0x7f0100a5;
        public static final int logo = 0x7f010036;
        public static final int logoDescription = 0x7f010180;
        public static final int maxButtonHeight = 0x7f01017a;
        public static final int measureWithLargestChild = 0x7f01010b;
        public static final int multiChoiceItemLayout = 0x7f01004f;
        public static final int navigationContentDescription = 0x7f01017f;
        public static final int navigationIcon = 0x7f01017e;
        public static final int navigationMode = 0x7f010030;
        public static final int overlapAnchor = 0x7f01012e;
        public static final int paddingBottomNoButtons = 0x7f010130;
        public static final int paddingEnd = 0x7f010184;
        public static final int paddingStart = 0x7f010183;
        public static final int paddingTopNoTitle = 0x7f010131;
        public static final int panelBackground = 0x7f0100aa;
        public static final int panelMenuListTheme = 0x7f0100ac;
        public static final int panelMenuListWidth = 0x7f0100ab;
        public static final int popupMenuStyle = 0x7f010098;
        public static final int popupTheme = 0x7f010049;
        public static final int popupWindowStyle = 0x7f010099;
        public static final int preserveIconSpacing = 0x7f010126;
        public static final int progressBarPadding = 0x7f01003f;
        public static final int progressBarStyle = 0x7f01003d;
        public static final int queryBackground = 0x7f010143;
        public static final int queryHint = 0x7f01013a;
        public static final int radioButtonStyle = 0x7f0100c6;
        public static final int ratingBarStyle = 0x7f0100c7;
        public static final int ratingBarStyleIndicator = 0x7f0100c8;
        public static final int ratingBarStyleSmall = 0x7f0100c9;
        public static final int searchHintIcon = 0x7f01013f;
        public static final int searchIcon = 0x7f01013e;
        public static final int searchViewStyle = 0x7f0100a0;
        public static final int seekBarStyle = 0x7f0100ca;
        public static final int selectableItemBackground = 0x7f010090;
        public static final int selectableItemBackgroundBorderless = 0x7f010091;
        public static final int showAsAction = 0x7f010122;
        public static final int showDividers = 0x7f01010c;
        public static final int showText = 0x7f010153;
        public static final int showTitle = 0x7f010052;
        public static final int singleChoiceItemLayout = 0x7f010050;
        public static final int spinBars = 0x7f0100fd;
        public static final int spinnerDropDownItemStyle = 0x7f01008b;
        public static final int spinnerStyle = 0x7f0100cb;
        public static final int splitTrack = 0x7f010152;
        public static final int srcCompat = 0x7f010058;
        public static final int state_above_anchor = 0x7f01012f;
        public static final int subMenuArrow = 0x7f010127;
        public static final int submitBackground = 0x7f010144;
        public static final int subtitle = 0x7f010032;
        public static final int subtitleTextAppearance = 0x7f010173;
        public static final int subtitleTextColor = 0x7f010182;
        public static final int subtitleTextStyle = 0x7f010034;
        public static final int suggestionRowLayout = 0x7f010142;
        public static final int switchMinWidth = 0x7f010150;
        public static final int switchPadding = 0x7f010151;
        public static final int switchStyle = 0x7f0100cc;
        public static final int switchTextAppearance = 0x7f01014f;
        public static final int textAllCaps = 0x7f01005c;
        public static final int textAppearanceLargePopupMenu = 0x7f010083;
        public static final int textAppearanceListItem = 0x7f0100a8;
        public static final int textAppearanceListItemSmall = 0x7f0100a9;
        public static final int textAppearancePopupMenuHeader = 0x7f010085;
        public static final int textAppearanceSearchResultSubtitle = 0x7f01009e;
        public static final int textAppearanceSearchResultTitle = 0x7f01009d;
        public static final int textAppearanceSmallPopupMenu = 0x7f010084;
        public static final int textColorAlertDialogListItem = 0x7f0100bc;
        public static final int textColorSearchUrl = 0x7f01009f;
        public static final int theme = 0x7f010185;
        public static final int thickness = 0x7f010103;
        public static final int thumbTextPadding = 0x7f01014e;
        public static final int thumbTint = 0x7f010149;
        public static final int thumbTintMode = 0x7f01014a;
        public static final int tickMark = 0x7f010059;
        public static final int tickMarkTint = 0x7f01005a;
        public static final int tickMarkTintMode = 0x7f01005b;
        public static final int title = 0x7f01002f;
        public static final int titleMargin = 0x7f010174;
        public static final int titleMarginBottom = 0x7f010178;
        public static final int titleMarginEnd = 0x7f010176;
        public static final int titleMarginStart = 0x7f010175;
        public static final int titleMarginTop = 0x7f010177;
        public static final int titleMargins = 0x7f010179;
        public static final int titleTextAppearance = 0x7f010172;
        public static final int titleTextColor = 0x7f010181;
        public static final int titleTextStyle = 0x7f010033;
        public static final int toolbarNavigationButtonStyle = 0x7f010097;
        public static final int toolbarStyle = 0x7f010096;
        public static final int track = 0x7f01014b;
        public static final int trackTint = 0x7f01014c;
        public static final int trackTintMode = 0x7f01014d;
        public static final int voiceIcon = 0x7f010140;
        public static final int windowActionBar = 0x7f01005d;
        public static final int windowActionBarOverlay = 0x7f01005f;
        public static final int windowActionModeOverlay = 0x7f010060;
        public static final int windowFixedHeightMajor = 0x7f010064;
        public static final int windowFixedHeightMinor = 0x7f010062;
        public static final int windowFixedWidthMajor = 0x7f010061;
        public static final int windowFixedWidthMinor = 0x7f010063;
        public static final int windowMinWidthMajor = 0x7f010065;
        public static final int windowMinWidthMinor = 0x7f010066;
        public static final int windowNoTitle = 0x7f01005e;

        private attr()
        {
        }
    }

    public static final class anim
    {

        public static final int abc_fade_in = 0x7f050000;
        public static final int abc_fade_out = 0x7f050001;
        public static final int abc_grow_fade_in_from_bottom = 0x7f050002;
        public static final int abc_popup_enter = 0x7f050003;
        public static final int abc_popup_exit = 0x7f050004;
        public static final int abc_shrink_fade_out_from_bottom = 0x7f050005;
        public static final int abc_slide_in_bottom = 0x7f050006;
        public static final int abc_slide_in_top = 0x7f050007;
        public static final int abc_slide_out_bottom = 0x7f050008;
        public static final int abc_slide_out_top = 0x7f050009;

        private anim()
        {
        }
    }


    private R()
    {
    }
}
