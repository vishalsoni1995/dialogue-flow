// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   R.java

package android.support.v7.recyclerview;


public final class R
{
    public static final class styleable
    {

        public static final int RecyclerView[] = {
            0x10100c4, 0x10100f1, 0x7f010132, 0x7f010133, 0x7f010134, 0x7f010135
        };
        public static final int RecyclerView_android_orientation = 0;
        public static final int RecyclerView_android_descendantFocusability = 1;
        public static final int RecyclerView_layoutManager = 2;
        public static final int RecyclerView_spanCount = 3;
        public static final int RecyclerView_reverseLayout = 4;
        public static final int RecyclerView_stackFromEnd = 5;


        private styleable()
        {
        }
    }

    public static final class id
    {

        public static final int item_touch_helper_previous_elevation = 0x7f0d0005;

        private id()
        {
        }
    }

    public static final class dimen
    {

        public static final int item_touch_helper_max_drag_scroll_per_frame = 0x7f080083;
        public static final int item_touch_helper_swipe_escape_max_velocity = 0x7f080084;
        public static final int item_touch_helper_swipe_escape_velocity = 0x7f080085;

        private dimen()
        {
        }
    }

    public static final class attr
    {

        public static final int layoutManager = 0x7f010132;
        public static final int reverseLayout = 0x7f010134;
        public static final int spanCount = 0x7f010133;
        public static final int stackFromEnd = 0x7f010135;

        private attr()
        {
        }
    }


    private R()
    {
    }
}
