// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   R.java

package android.support.v7.cardview;


public final class R
{
    public static final class styleable
    {

        public static final int CardView[] = {
            0x101013f, 0x1010140, 0x7f0100d2, 0x7f0100d3, 0x7f0100d4, 0x7f0100d5, 0x7f0100d6, 0x7f0100d7, 0x7f0100d8, 0x7f0100d9, 
            0x7f0100da, 0x7f0100db, 0x7f0100dc
        };
        public static final int CardView_android_minWidth = 0;
        public static final int CardView_android_minHeight = 1;
        public static final int CardView_cardBackgroundColor = 2;
        public static final int CardView_cardCornerRadius = 3;
        public static final int CardView_cardElevation = 4;
        public static final int CardView_cardMaxElevation = 5;
        public static final int CardView_cardUseCompatPadding = 6;
        public static final int CardView_cardPreventCornerOverlap = 7;
        public static final int CardView_contentPadding = 8;
        public static final int CardView_contentPaddingLeft = 9;
        public static final int CardView_contentPaddingRight = 10;
        public static final int CardView_contentPaddingTop = 11;
        public static final int CardView_contentPaddingBottom = 12;


        private styleable()
        {
        }
    }

    public static final class style
    {

        public static final int Base_CardView = 0x7f0900af;
        public static final int CardView = 0x7f09009d;
        public static final int CardView_Dark = 0x7f0900d9;
        public static final int CardView_Light = 0x7f0900da;

        private style()
        {
        }
    }

    public static final class dimen
    {

        public static final int cardview_compat_inset_shadow = 0x7f080058;
        public static final int cardview_default_elevation = 0x7f080059;
        public static final int cardview_default_radius = 0x7f08005a;

        private dimen()
        {
        }
    }

    public static final class color
    {

        public static final int cardview_dark_background = 0x7f0c0019;
        public static final int cardview_light_background = 0x7f0c001a;
        public static final int cardview_shadow_end_color = 0x7f0c001b;
        public static final int cardview_shadow_start_color = 0x7f0c001c;

        private color()
        {
        }
    }

    public static final class attr
    {

        public static final int cardBackgroundColor = 0x7f0100d2;
        public static final int cardCornerRadius = 0x7f0100d3;
        public static final int cardElevation = 0x7f0100d4;
        public static final int cardMaxElevation = 0x7f0100d5;
        public static final int cardPreventCornerOverlap = 0x7f0100d7;
        public static final int cardUseCompatPadding = 0x7f0100d6;
        public static final int contentPadding = 0x7f0100d8;
        public static final int contentPaddingBottom = 0x7f0100dc;
        public static final int contentPaddingLeft = 0x7f0100d9;
        public static final int contentPaddingRight = 0x7f0100da;
        public static final int contentPaddingTop = 0x7f0100db;

        private attr()
        {
        }
    }


    private R()
    {
    }
}
