// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   R.java

package android.support.constraint;


public final class R
{
    public static final class styleable
    {

        public static final int ConstraintLayout_Layout[] = {
            0x10100c4, 0x101011f, 0x1010120, 0x101013f, 0x1010140, 0x7f010000, 0x7f010004, 0x7f010005, 0x7f010006, 0x7f010007, 
            0x7f010008, 0x7f010009, 0x7f01000a, 0x7f01000b, 0x7f01000c, 0x7f01000d, 0x7f01000e, 0x7f01000f, 0x7f010010, 0x7f010011, 
            0x7f010012, 0x7f010013, 0x7f010014, 0x7f010015, 0x7f010016, 0x7f010017, 0x7f010018, 0x7f010019, 0x7f01001a, 0x7f01001b, 
            0x7f01001c, 0x7f01001d, 0x7f01001e, 0x7f01001f, 0x7f010020, 0x7f010021, 0x7f010022, 0x7f010023, 0x7f010024, 0x7f010025, 
            0x7f010026, 0x7f010027, 0x7f010028, 0x7f010029, 0x7f01002a, 0x7f01002b, 0x7f01002c, 0x7f01002d, 0x7f01002e
        };
        public static final int ConstraintLayout_Layout_android_orientation = 0;
        public static final int ConstraintLayout_Layout_android_maxWidth = 1;
        public static final int ConstraintLayout_Layout_android_maxHeight = 2;
        public static final int ConstraintLayout_Layout_android_minWidth = 3;
        public static final int ConstraintLayout_Layout_android_minHeight = 4;
        public static final int ConstraintLayout_Layout_constraintSet = 5;
        public static final int ConstraintLayout_Layout_layout_constraintBaseline_creator = 6;
        public static final int ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf = 7;
        public static final int ConstraintLayout_Layout_layout_constraintBottom_creator = 8;
        public static final int ConstraintLayout_Layout_layout_constraintBottom_toBottomOf = 9;
        public static final int ConstraintLayout_Layout_layout_constraintBottom_toTopOf = 10;
        public static final int ConstraintLayout_Layout_layout_constraintDimensionRatio = 11;
        public static final int ConstraintLayout_Layout_layout_constraintEnd_toEndOf = 12;
        public static final int ConstraintLayout_Layout_layout_constraintEnd_toStartOf = 13;
        public static final int ConstraintLayout_Layout_layout_constraintGuide_begin = 14;
        public static final int ConstraintLayout_Layout_layout_constraintGuide_end = 15;
        public static final int ConstraintLayout_Layout_layout_constraintGuide_percent = 16;
        public static final int ConstraintLayout_Layout_layout_constraintHeight_default = 17;
        public static final int ConstraintLayout_Layout_layout_constraintHeight_max = 18;
        public static final int ConstraintLayout_Layout_layout_constraintHeight_min = 19;
        public static final int ConstraintLayout_Layout_layout_constraintHorizontal_bias = 20;
        public static final int ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle = 21;
        public static final int ConstraintLayout_Layout_layout_constraintHorizontal_weight = 22;
        public static final int ConstraintLayout_Layout_layout_constraintLeft_creator = 23;
        public static final int ConstraintLayout_Layout_layout_constraintLeft_toLeftOf = 24;
        public static final int ConstraintLayout_Layout_layout_constraintLeft_toRightOf = 25;
        public static final int ConstraintLayout_Layout_layout_constraintRight_creator = 26;
        public static final int ConstraintLayout_Layout_layout_constraintRight_toLeftOf = 27;
        public static final int ConstraintLayout_Layout_layout_constraintRight_toRightOf = 28;
        public static final int ConstraintLayout_Layout_layout_constraintStart_toEndOf = 29;
        public static final int ConstraintLayout_Layout_layout_constraintStart_toStartOf = 30;
        public static final int ConstraintLayout_Layout_layout_constraintTop_creator = 31;
        public static final int ConstraintLayout_Layout_layout_constraintTop_toBottomOf = 32;
        public static final int ConstraintLayout_Layout_layout_constraintTop_toTopOf = 33;
        public static final int ConstraintLayout_Layout_layout_constraintVertical_bias = 34;
        public static final int ConstraintLayout_Layout_layout_constraintVertical_chainStyle = 35;
        public static final int ConstraintLayout_Layout_layout_constraintVertical_weight = 36;
        public static final int ConstraintLayout_Layout_layout_constraintWidth_default = 37;
        public static final int ConstraintLayout_Layout_layout_constraintWidth_max = 38;
        public static final int ConstraintLayout_Layout_layout_constraintWidth_min = 39;
        public static final int ConstraintLayout_Layout_layout_editor_absoluteX = 40;
        public static final int ConstraintLayout_Layout_layout_editor_absoluteY = 41;
        public static final int ConstraintLayout_Layout_layout_goneMarginBottom = 42;
        public static final int ConstraintLayout_Layout_layout_goneMarginEnd = 43;
        public static final int ConstraintLayout_Layout_layout_goneMarginLeft = 44;
        public static final int ConstraintLayout_Layout_layout_goneMarginRight = 45;
        public static final int ConstraintLayout_Layout_layout_goneMarginStart = 46;
        public static final int ConstraintLayout_Layout_layout_goneMarginTop = 47;
        public static final int ConstraintLayout_Layout_layout_optimizationLevel = 48;
        public static final int ConstraintSet[] = {
            0x10100c4, 0x10100d0, 0x10100dc, 0x10100f4, 0x10100f5, 0x10100f7, 0x10100f8, 0x10100f9, 0x10100fa, 0x101031f, 
            0x1010320, 0x1010321, 0x1010322, 0x1010323, 0x1010324, 0x1010325, 0x1010327, 0x1010328, 0x10103b5, 0x10103b6, 
            0x10103fa, 0x1010440, 0x7f010004, 0x7f010005, 0x7f010006, 0x7f010007, 0x7f010008, 0x7f010009, 0x7f01000a, 0x7f01000b, 
            0x7f01000c, 0x7f01000d, 0x7f01000e, 0x7f01000f, 0x7f010010, 0x7f010011, 0x7f010012, 0x7f010013, 0x7f010014, 0x7f010015, 
            0x7f010016, 0x7f010017, 0x7f010018, 0x7f010019, 0x7f01001a, 0x7f01001b, 0x7f01001c, 0x7f01001d, 0x7f01001e, 0x7f01001f, 
            0x7f010020, 0x7f010021, 0x7f010022, 0x7f010023, 0x7f010024, 0x7f010025, 0x7f010026, 0x7f010027, 0x7f010028, 0x7f010029, 
            0x7f01002a, 0x7f01002b, 0x7f01002c, 0x7f01002d
        };
        public static final int ConstraintSet_android_orientation = 0;
        public static final int ConstraintSet_android_id = 1;
        public static final int ConstraintSet_android_visibility = 2;
        public static final int ConstraintSet_android_layout_width = 3;
        public static final int ConstraintSet_android_layout_height = 4;
        public static final int ConstraintSet_android_layout_marginLeft = 5;
        public static final int ConstraintSet_android_layout_marginTop = 6;
        public static final int ConstraintSet_android_layout_marginRight = 7;
        public static final int ConstraintSet_android_layout_marginBottom = 8;
        public static final int ConstraintSet_android_alpha = 9;
        public static final int ConstraintSet_android_transformPivotX = 10;
        public static final int ConstraintSet_android_transformPivotY = 11;
        public static final int ConstraintSet_android_translationX = 12;
        public static final int ConstraintSet_android_translationY = 13;
        public static final int ConstraintSet_android_scaleX = 14;
        public static final int ConstraintSet_android_scaleY = 15;
        public static final int ConstraintSet_android_rotationX = 16;
        public static final int ConstraintSet_android_rotationY = 17;
        public static final int ConstraintSet_android_layout_marginStart = 18;
        public static final int ConstraintSet_android_layout_marginEnd = 19;
        public static final int ConstraintSet_android_translationZ = 20;
        public static final int ConstraintSet_android_elevation = 21;
        public static final int ConstraintSet_layout_constraintBaseline_creator = 22;
        public static final int ConstraintSet_layout_constraintBaseline_toBaselineOf = 23;
        public static final int ConstraintSet_layout_constraintBottom_creator = 24;
        public static final int ConstraintSet_layout_constraintBottom_toBottomOf = 25;
        public static final int ConstraintSet_layout_constraintBottom_toTopOf = 26;
        public static final int ConstraintSet_layout_constraintDimensionRatio = 27;
        public static final int ConstraintSet_layout_constraintEnd_toEndOf = 28;
        public static final int ConstraintSet_layout_constraintEnd_toStartOf = 29;
        public static final int ConstraintSet_layout_constraintGuide_begin = 30;
        public static final int ConstraintSet_layout_constraintGuide_end = 31;
        public static final int ConstraintSet_layout_constraintGuide_percent = 32;
        public static final int ConstraintSet_layout_constraintHeight_default = 33;
        public static final int ConstraintSet_layout_constraintHeight_max = 34;
        public static final int ConstraintSet_layout_constraintHeight_min = 35;
        public static final int ConstraintSet_layout_constraintHorizontal_bias = 36;
        public static final int ConstraintSet_layout_constraintHorizontal_chainStyle = 37;
        public static final int ConstraintSet_layout_constraintHorizontal_weight = 38;
        public static final int ConstraintSet_layout_constraintLeft_creator = 39;
        public static final int ConstraintSet_layout_constraintLeft_toLeftOf = 40;
        public static final int ConstraintSet_layout_constraintLeft_toRightOf = 41;
        public static final int ConstraintSet_layout_constraintRight_creator = 42;
        public static final int ConstraintSet_layout_constraintRight_toLeftOf = 43;
        public static final int ConstraintSet_layout_constraintRight_toRightOf = 44;
        public static final int ConstraintSet_layout_constraintStart_toEndOf = 45;
        public static final int ConstraintSet_layout_constraintStart_toStartOf = 46;
        public static final int ConstraintSet_layout_constraintTop_creator = 47;
        public static final int ConstraintSet_layout_constraintTop_toBottomOf = 48;
        public static final int ConstraintSet_layout_constraintTop_toTopOf = 49;
        public static final int ConstraintSet_layout_constraintVertical_bias = 50;
        public static final int ConstraintSet_layout_constraintVertical_chainStyle = 51;
        public static final int ConstraintSet_layout_constraintVertical_weight = 52;
        public static final int ConstraintSet_layout_constraintWidth_default = 53;
        public static final int ConstraintSet_layout_constraintWidth_max = 54;
        public static final int ConstraintSet_layout_constraintWidth_min = 55;
        public static final int ConstraintSet_layout_editor_absoluteX = 56;
        public static final int ConstraintSet_layout_editor_absoluteY = 57;
        public static final int ConstraintSet_layout_goneMarginBottom = 58;
        public static final int ConstraintSet_layout_goneMarginEnd = 59;
        public static final int ConstraintSet_layout_goneMarginLeft = 60;
        public static final int ConstraintSet_layout_goneMarginRight = 61;
        public static final int ConstraintSet_layout_goneMarginStart = 62;
        public static final int ConstraintSet_layout_goneMarginTop = 63;
        public static final int LinearConstraintLayout[] = {
            0x10100c4
        };
        public static final int LinearConstraintLayout_android_orientation = 0;


        private styleable()
        {
        }
    }

    public static final class id
    {

        public static final int all = 0x7f0d0014;
        public static final int basic = 0x7f0d0015;
        public static final int chains = 0x7f0d0016;
        public static final int none = 0x7f0d0017;
        public static final int packed = 0x7f0d0012;
        public static final int parent = 0x7f0d000f;
        public static final int spread = 0x7f0d0010;
        public static final int spread_inside = 0x7f0d0013;
        public static final int wrap = 0x7f0d0011;

        private id()
        {
        }
    }

    public static final class attr
    {

        public static final int constraintSet = 0x7f010000;
        public static final int layout_constraintBaseline_creator = 0x7f010004;
        public static final int layout_constraintBaseline_toBaselineOf = 0x7f010005;
        public static final int layout_constraintBottom_creator = 0x7f010006;
        public static final int layout_constraintBottom_toBottomOf = 0x7f010007;
        public static final int layout_constraintBottom_toTopOf = 0x7f010008;
        public static final int layout_constraintDimensionRatio = 0x7f010009;
        public static final int layout_constraintEnd_toEndOf = 0x7f01000a;
        public static final int layout_constraintEnd_toStartOf = 0x7f01000b;
        public static final int layout_constraintGuide_begin = 0x7f01000c;
        public static final int layout_constraintGuide_end = 0x7f01000d;
        public static final int layout_constraintGuide_percent = 0x7f01000e;
        public static final int layout_constraintHeight_default = 0x7f01000f;
        public static final int layout_constraintHeight_max = 0x7f010010;
        public static final int layout_constraintHeight_min = 0x7f010011;
        public static final int layout_constraintHorizontal_bias = 0x7f010012;
        public static final int layout_constraintHorizontal_chainStyle = 0x7f010013;
        public static final int layout_constraintHorizontal_weight = 0x7f010014;
        public static final int layout_constraintLeft_creator = 0x7f010015;
        public static final int layout_constraintLeft_toLeftOf = 0x7f010016;
        public static final int layout_constraintLeft_toRightOf = 0x7f010017;
        public static final int layout_constraintRight_creator = 0x7f010018;
        public static final int layout_constraintRight_toLeftOf = 0x7f010019;
        public static final int layout_constraintRight_toRightOf = 0x7f01001a;
        public static final int layout_constraintStart_toEndOf = 0x7f01001b;
        public static final int layout_constraintStart_toStartOf = 0x7f01001c;
        public static final int layout_constraintTop_creator = 0x7f01001d;
        public static final int layout_constraintTop_toBottomOf = 0x7f01001e;
        public static final int layout_constraintTop_toTopOf = 0x7f01001f;
        public static final int layout_constraintVertical_bias = 0x7f010020;
        public static final int layout_constraintVertical_chainStyle = 0x7f010021;
        public static final int layout_constraintVertical_weight = 0x7f010022;
        public static final int layout_constraintWidth_default = 0x7f010023;
        public static final int layout_constraintWidth_max = 0x7f010024;
        public static final int layout_constraintWidth_min = 0x7f010025;
        public static final int layout_editor_absoluteX = 0x7f010026;
        public static final int layout_editor_absoluteY = 0x7f010027;
        public static final int layout_goneMarginBottom = 0x7f010028;
        public static final int layout_goneMarginEnd = 0x7f010029;
        public static final int layout_goneMarginLeft = 0x7f01002a;
        public static final int layout_goneMarginRight = 0x7f01002b;
        public static final int layout_goneMarginStart = 0x7f01002c;
        public static final int layout_goneMarginTop = 0x7f01002d;
        public static final int layout_optimizationLevel = 0x7f01002e;

        private attr()
        {
        }
    }


    private R()
    {
    }
}
