// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   R.java

package android.support.transition;


public final class R
{
    public static final class id
    {

        public static final int transition_current_scene = 0x7f0d000b;
        public static final int transition_scene_layoutid_cache = 0x7f0d000c;

        private id()
        {
        }
    }


    private R()
    {
    }
}
