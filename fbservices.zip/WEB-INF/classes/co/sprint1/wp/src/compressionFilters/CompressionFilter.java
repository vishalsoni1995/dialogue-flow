// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CompressionFilter.java

package compressionFilters;

import java.io.IOException;
import java.io.PrintStream;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// Referenced classes of package compressionFilters:
//            CompressionServletResponseWrapper

public class CompressionFilter
    implements Filter
{

    public CompressionFilter()
    {
        config = null;
        minThreshold = 128;
        compressionThreshold = 0;
        minBuffer = 8192;
        compressionBuffer = 0;
        debug = 0;
    }

    public void init(FilterConfig filterConfig)
    {
        config = filterConfig;
        if(filterConfig != null)
        {
            String value = filterConfig.getInitParameter("debug");
            if(value != null)
                debug = Integer.parseInt(value);
            String str = filterConfig.getInitParameter("compressionThreshold");
            if(str != null)
            {
                compressionThreshold = Integer.parseInt(str);
                if(compressionThreshold != 0 && compressionThreshold < minThreshold)
                {
                    if(debug > 0)
                    {
                        System.out.println((new StringBuilder()).append("compressionThreshold should be either 0 - no compression or >= ").append(minThreshold).toString());
                        System.out.println((new StringBuilder()).append("compressionThreshold set to ").append(minThreshold).toString());
                    }
                    compressionThreshold = minThreshold;
                }
            }
            str = filterConfig.getInitParameter("compressionBuffer");
            if(str != null)
            {
                compressionBuffer = Integer.parseInt(str);
                if(compressionBuffer < minBuffer)
                {
                    if(debug > 0)
                    {
                        System.out.println((new StringBuilder()).append("compressionBuffer should be >= ").append(minBuffer).toString());
                        System.out.println((new StringBuilder()).append("compressionBuffer set to ").append(minBuffer).toString());
                    }
                    compressionBuffer = minBuffer;
                }
            }
            str = filterConfig.getInitParameter("compressionMimeTypes");
            if(str != null)
            {
                List values = new ArrayList();
                StringTokenizer st = new StringTokenizer(str, ",");
                do
                {
                    if(!st.hasMoreTokens())
                        break;
                    String token = st.nextToken().trim();
                    if(token.length() > 0)
                        values.add(token);
                } while(true);
                if(values.size() > 0)
                    compressionMimeTypes = (String[])values.toArray(new String[values.size()]);
                else
                    compressionMimeTypes = null;
                if(debug > 0)
                    System.out.println((new StringBuilder()).append("compressionMimeTypes set to ").append(compressionMimeTypes).toString());
            }
        }
    }

    public void destroy()
    {
        config = null;
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
        throws IOException, ServletException
    {
        CompressionServletResponseWrapper wrappedResponse;
        if(debug > 0)
            System.out.println("@doFilter");
        if(compressionThreshold == 0)
        {
            if(debug > 0)
                System.out.println("doFilter got called, but compressionTreshold is set to 0 - no compression");
            chain.doFilter(request, response);
            return;
        }
        boolean supportCompression = false;
        if(request instanceof HttpServletRequest)
        {
            if(debug > 1)
                System.out.println((new StringBuilder()).append("requestURI = ").append(((HttpServletRequest)request).getRequestURI()).toString());
            String s = ((HttpServletRequest)request).getParameter("gzip");
            if("false".equals(s))
            {
                if(debug > 0)
                    System.out.println("got parameter gzip=false --> don't compress, just chain filter");
                chain.doFilter(request, response);
                return;
            }
            Enumeration e = ((HttpServletRequest)request).getHeaders("Accept-Encoding");
            do
            {
                if(!e.hasMoreElements())
                    break;
                String name = (String)e.nextElement();
                if(name.indexOf("gzip") != -1)
                {
                    if(debug > 0)
                        System.out.println("supports compression");
                    supportCompression = true;
                } else
                if(debug > 0)
                    System.out.println("no support for compression");
            } while(true);
        }
        if(!supportCompression)
            break MISSING_BLOCK_LABEL_333;
        if(!(response instanceof HttpServletResponse))
            break MISSING_BLOCK_LABEL_357;
        wrappedResponse = new CompressionServletResponseWrapper((HttpServletResponse)response);
        wrappedResponse.setDebugLevel(debug);
        wrappedResponse.setCompressionThreshold(compressionThreshold);
        wrappedResponse.setCompressionBuffer(compressionBuffer);
        wrappedResponse.setCompressionMimeTypes(compressionMimeTypes);
        if(debug > 0)
            System.out.println("doFilter gets called with compression");
        chain.doFilter(request, wrappedResponse);
        wrappedResponse.finishResponse();
        break MISSING_BLOCK_LABEL_332;
        Exception exception;
        exception;
        wrappedResponse.finishResponse();
        throw exception;
        return;
        if(debug > 0)
            System.out.println("doFilter gets called w/o compression");
        chain.doFilter(request, response);
        return;
    }

    public void setFilterConfig(FilterConfig filterConfig)
    {
        init(filterConfig);
    }

    public FilterConfig getFilterConfig()
    {
        return config;
    }

    private FilterConfig config;
    private int minThreshold;
    protected int compressionThreshold;
    private int minBuffer;
    protected int compressionBuffer;
    protected String compressionMimeTypes[] = {
        "text/html", "text/xml", "text/plain"
    };
    private int debug;
}
