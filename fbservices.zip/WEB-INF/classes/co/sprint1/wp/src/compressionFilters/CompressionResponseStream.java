// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CompressionResponseStream.java

package compressionFilters;

import java.io.*;
import java.util.zip.GZIPOutputStream;
import javax.servlet.ServletOutputStream;

// Referenced classes of package compressionFilters:
//            CompressionServletResponseWrapper

public class CompressionResponseStream extends ServletOutputStream
{

    public CompressionResponseStream(CompressionServletResponseWrapper responseWrapper, ServletOutputStream originalOutput)
    {
        compressionThreshold = 0;
        compressionBuffer = 0;
        debug = 0;
        buffer = null;
        bufferCount = 0;
        gzipstream = null;
        closed = false;
        length = -1;
        response = null;
        output = null;
        closed = false;
        response = responseWrapper;
        output = originalOutput;
    }

    public void setDebugLevel(int debug)
    {
        this.debug = debug;
    }

    protected void setCompressionThreshold(int compressionThreshold)
    {
        this.compressionThreshold = compressionThreshold;
        buffer = new byte[this.compressionThreshold];
        if(debug > 1)
            System.out.println((new StringBuilder()).append("compressionThreshold is set to ").append(this.compressionThreshold).toString());
    }

    protected void setCompressionBuffer(int compressionBuffer)
    {
        this.compressionBuffer = compressionBuffer;
        if(debug > 1)
            System.out.println((new StringBuilder()).append("compressionBuffer is set to ").append(this.compressionBuffer).toString());
    }

    public void setCompressionMimeTypes(String compressionMimeTypes[])
    {
        this.compressionMimeTypes = compressionMimeTypes;
        if(debug > 1)
            System.out.println((new StringBuilder()).append("compressionMimeTypes is set to ").append(this.compressionMimeTypes).toString());
    }

    public void close()
        throws IOException
    {
        if(debug > 1)
            System.out.println("close() @ CompressionResponseStream");
        if(closed)
            throw new IOException("This output stream has already been closed");
        if(gzipstream != null)
        {
            flushToGZip();
            gzipstream.close();
            gzipstream = null;
        } else
        if(bufferCount > 0)
        {
            if(debug > 2)
            {
                System.out.print("output.write(");
                System.out.write(buffer, 0, bufferCount);
                System.out.println(")");
            }
            output.write(buffer, 0, bufferCount);
            bufferCount = 0;
        }
        output.close();
        closed = true;
    }

    public void flush()
        throws IOException
    {
        if(debug > 1)
            System.out.println("flush() @ CompressionResponseStream");
        if(closed)
            throw new IOException("Cannot flush a closed output stream");
        if(gzipstream != null)
            gzipstream.flush();
    }

    public void flushToGZip()
        throws IOException
    {
        if(debug > 1)
            System.out.println("flushToGZip() @ CompressionResponseStream");
        if(bufferCount > 0)
        {
            if(debug > 1)
                System.out.println((new StringBuilder()).append("flushing out to GZipStream, bufferCount = ").append(bufferCount).toString());
            writeToGZip(buffer, 0, bufferCount);
            bufferCount = 0;
        }
    }

    public void write(int b)
        throws IOException
    {
        if(debug > 1)
            System.out.println((new StringBuilder()).append("write ").append(b).append(" in CompressionResponseStream ").toString());
        if(closed)
            throw new IOException("Cannot write to a closed output stream");
        if(bufferCount >= buffer.length)
            flushToGZip();
        buffer[bufferCount++] = (byte)b;
    }

    public void write(byte b[])
        throws IOException
    {
        write(b, 0, b.length);
    }

    public void write(byte b[], int off, int len)
        throws IOException
    {
        if(debug > 1)
            System.out.println((new StringBuilder()).append("write, bufferCount = ").append(bufferCount).append(" len = ").append(len).append(" off = ").append(off).toString());
        if(debug > 2)
        {
            System.out.print("write(");
            System.out.write(b, off, len);
            System.out.println(")");
        }
        if(closed)
            throw new IOException("Cannot write to a closed output stream");
        if(len == 0)
            return;
        if(len <= buffer.length - bufferCount)
        {
            System.arraycopy(b, off, buffer, bufferCount, len);
            bufferCount += len;
            return;
        }
        flushToGZip();
        if(len <= buffer.length - bufferCount)
        {
            System.arraycopy(b, off, buffer, bufferCount, len);
            bufferCount += len;
            return;
        } else
        {
            writeToGZip(b, off, len);
            return;
        }
    }

    public void writeToGZip(byte b[], int off, int len)
        throws IOException
    {
        if(debug > 1)
            System.out.println((new StringBuilder()).append("writeToGZip, len = ").append(len).toString());
        if(debug > 2)
        {
            System.out.print("writeToGZip(");
            System.out.write(b, off, len);
            System.out.println(")");
        }
        if(gzipstream == null)
        {
            if(debug > 1)
                System.out.println("new GZIPOutputStream");
            boolean alreadyCompressed = false;
            String contentEncoding = response.getHeader("Content-Encoding");
            if(contentEncoding != null)
                if(contentEncoding.contains("gzip"))
                {
                    alreadyCompressed = true;
                    if(debug > 0)
                        System.out.println("content is already compressed");
                } else
                if(debug > 0)
                    System.out.println("content is not compressed yet");
            boolean compressibleMimeType = false;
            if(compressionMimeTypes != null)
                if(startsWithStringArray(compressionMimeTypes, response.getContentType()))
                {
                    compressibleMimeType = true;
                    if(debug > 0)
                        System.out.println((new StringBuilder()).append("mime type ").append(response.getContentType()).append(" is compressible").toString());
                } else
                if(debug > 0)
                    System.out.println((new StringBuilder()).append("mime type ").append(response.getContentType()).append(" is not compressible").toString());
            if(response.isCommitted())
            {
                if(debug > 1)
                    System.out.print("Response already committed. Using original output stream");
                gzipstream = output;
            } else
            if(alreadyCompressed)
            {
                if(debug > 1)
                    System.out.print("Response already compressed. Using original output stream");
                gzipstream = output;
            } else
            if(!compressibleMimeType)
            {
                if(debug > 1)
                    System.out.print("Response mime type is not compressible. Using original output stream");
                gzipstream = output;
            } else
            {
                response.addHeader("Content-Encoding", "gzip");
                response.setContentLength(-1);
                response.setBufferSize(compressionBuffer);
                gzipstream = new GZIPOutputStream(output);
            }
        }
        gzipstream.write(b, off, len);
    }

    public boolean closed()
    {
        return closed;
    }

    private boolean startsWithStringArray(String sArray[], String value)
    {
        if(value == null)
            return false;
        for(int i = 0; i < sArray.length; i++)
            if(value.startsWith(sArray[i]))
                return true;

        return false;
    }

    protected int compressionThreshold;
    protected int compressionBuffer;
    protected String compressionMimeTypes[] = {
        "text/html", "text/xml", "text/plain"
    };
    private int debug;
    protected byte buffer[];
    protected int bufferCount;
    protected OutputStream gzipstream;
    protected boolean closed;
    protected int length;
    protected CompressionServletResponseWrapper response;
    protected ServletOutputStream output;
}
