// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CompressionServletResponseWrapper.java

package compressionFilters;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

// Referenced classes of package compressionFilters:
//            CompressionResponseStream

public class CompressionServletResponseWrapper extends HttpServletResponseWrapper
{

    public CompressionServletResponseWrapper(HttpServletResponse response)
    {
        super(response);
        origResponse = null;
        stream = null;
        writer = null;
        compressionThreshold = 0;
        compressionBuffer = 8192;
        debug = 0;
        headerCopies = new HashMap();
        origResponse = response;
        if(debug > 1)
            System.out.println("CompressionServletResponseWrapper constructor gets called");
    }

    public void setCompressionThreshold(int threshold)
    {
        if(debug > 1)
            System.out.println((new StringBuilder()).append("setCompressionThreshold to ").append(threshold).toString());
        compressionThreshold = threshold;
    }

    public void setCompressionBuffer(int buffer)
    {
        if(debug > 1)
            System.out.println((new StringBuilder()).append("setCompressionBuffer to ").append(buffer).toString());
        compressionBuffer = buffer;
    }

    public void setCompressionMimeTypes(String mimeTypes[])
    {
        if(debug > 1)
            System.out.println((new StringBuilder()).append("setCompressionMimeTypes to ").append(mimeTypes).toString());
        compressionMimeTypes = mimeTypes;
    }

    public void setDebugLevel(int debug)
    {
        this.debug = debug;
    }

    public ServletOutputStream createOutputStream()
        throws IOException
    {
        if(debug > 1)
            System.out.println("createOutputStream gets called");
        CompressionResponseStream stream = new CompressionResponseStream(this, origResponse.getOutputStream());
        stream.setDebugLevel(debug);
        stream.setCompressionThreshold(compressionThreshold);
        stream.setCompressionBuffer(compressionBuffer);
        stream.setCompressionMimeTypes(compressionMimeTypes);
        return stream;
    }

    public void finishResponse()
    {
        try
        {
            if(writer != null)
                writer.close();
            else
            if(stream != null)
                stream.close();
        }
        catch(IOException e) { }
    }

    public void flushBuffer()
        throws IOException
    {
        if(debug > 1)
            System.out.println("flush buffer @ GZipServletResponseWrapper");
        ((CompressionResponseStream)stream).flush();
    }

    public ServletOutputStream getOutputStream()
        throws IOException
    {
        if(writer != null)
            throw new IllegalStateException("getWriter() has already been called for this response");
        if(stream == null)
            stream = createOutputStream();
        if(debug > 1)
            System.out.println((new StringBuilder()).append("stream is set to ").append(stream).append(" in getOutputStream").toString());
        return stream;
    }

    public PrintWriter getWriter()
        throws IOException
    {
        if(writer != null)
            return writer;
        if(stream != null)
            throw new IllegalStateException("getOutputStream() has already been called for this response");
        stream = createOutputStream();
        if(debug > 1)
            System.out.println((new StringBuilder()).append("stream is set to ").append(stream).append(" in getWriter").toString());
        String charEnc = origResponse.getCharacterEncoding();
        if(debug > 1)
            System.out.println((new StringBuilder()).append("character encoding is ").append(charEnc).toString());
        if(charEnc != null)
            writer = new PrintWriter(new OutputStreamWriter(stream, charEnc));
        else
            writer = new PrintWriter(stream);
        return writer;
    }

    public String getHeader(String name)
    {
        return (String)headerCopies.get(name);
    }

    public void addHeader(String name, String value)
    {
        if(headerCopies.containsKey(name))
        {
            String existingValue = (String)headerCopies.get(name);
            if(existingValue != null && existingValue.length() > 0)
                headerCopies.put(name, (new StringBuilder()).append(existingValue).append(",").append(value).toString());
            else
                headerCopies.put(name, value);
        } else
        {
            headerCopies.put(name, value);
        }
        super.addHeader(name, value);
    }

    public void setHeader(String name, String value)
    {
        headerCopies.put(name, value);
        super.setHeader(name, value);
    }

    protected HttpServletResponse origResponse;
    protected static final String info = "CompressionServletResponseWrapper";
    protected ServletOutputStream stream;
    protected PrintWriter writer;
    protected int compressionThreshold;
    protected int compressionBuffer;
    protected String compressionMimeTypes[] = {
        "text/html", "text/xml", "text/plain"
    };
    protected int debug;
    private Map headerCopies;
}
