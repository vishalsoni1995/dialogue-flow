// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Entries.java

package cal;

import java.util.Hashtable;
import javax.servlet.http.HttpServletRequest;

// Referenced classes of package cal:
//            Entry

public class Entries
{

    public Entries()
    {
        entries = new Hashtable(12);
        for(int i = 0; i < 12; i++)
            entries.put(time[i], new Entry(time[i]));

    }

    public int getRows()
    {
        return 12;
    }

    public Entry getEntry(int index)
    {
        return (Entry)entries.get(time[index]);
    }

    public int getIndex(String tm)
    {
        for(int i = 0; i < 12; i++)
            if(tm.equals(time[i]))
                return i;

        return -1;
    }

    public void processRequest(HttpServletRequest request, String tm)
    {
        int index = getIndex(tm);
        if(index >= 0)
        {
            String descr = request.getParameter("description");
            ((Entry)entries.get(time[index])).setDescription(descr);
        }
    }

    private Hashtable entries;
    private static final String time[] = {
        "8am", "9am", "10am", "11am", "12pm", "1pm", "2pm", "3pm", "4pm", "5pm", 
        "6pm", "7pm", "8pm"
    };
    public static final int rows = 12;

}
