// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TableBean.java

package cal;

import java.util.Hashtable;
import javax.servlet.http.HttpServletRequest;

// Referenced classes of package cal:
//            JspCalendar, Entries

public class TableBean
{

    public TableBean()
    {
        name = null;
        email = null;
        processError = false;
        table = new Hashtable(10);
        JspCal = new JspCalendar();
        date = JspCal.getCurrentDate();
    }

    public void setName(String nm)
    {
        name = nm;
    }

    public String getName()
    {
        return name;
    }

    public void setEmail(String mail)
    {
        email = mail;
    }

    public String getEmail()
    {
        return email;
    }

    public String getDate()
    {
        return date;
    }

    public Entries getEntries()
    {
        return entries;
    }

    public void processRequest(HttpServletRequest request)
    {
        processError = false;
        if(name == null || name.equals(""))
            setName(request.getParameter("name"));
        if(email == null || email.equals(""))
            setEmail(request.getParameter("email"));
        if(name == null || email == null || name.equals("") || email.equals(""))
        {
            processError = true;
            return;
        }
        String dateR = request.getParameter("date");
        if(dateR == null)
            date = JspCal.getCurrentDate();
        else
        if(dateR.equalsIgnoreCase("next"))
            date = JspCal.getNextDate();
        else
        if(dateR.equalsIgnoreCase("prev"))
            date = JspCal.getPrevDate();
        entries = (Entries)table.get(date);
        if(entries == null)
        {
            entries = new Entries();
            table.put(date, entries);
        }
        String time = request.getParameter("time");
        if(time != null)
            entries.processRequest(request, time);
    }

    public boolean getProcessError()
    {
        return processError;
    }

    Hashtable table;
    JspCalendar JspCal;
    Entries entries;
    String date;
    String name;
    String email;
    boolean processError;
}
