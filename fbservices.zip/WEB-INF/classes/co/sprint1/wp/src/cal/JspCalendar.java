// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   JspCalendar.java

package cal;

import java.util.Calendar;
import java.util.Date;

public class JspCalendar
{

    public JspCalendar()
    {
        calendar = null;
        calendar = Calendar.getInstance();
        Date trialTime = new Date();
        calendar.setTime(trialTime);
    }

    public int getYear()
    {
        return calendar.get(1);
    }

    public String getMonth()
    {
        int m = getMonthInt();
        String months[] = {
            "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", 
            "November", "December"
        };
        if(m > 12)
            return "Unknown to Man";
        else
            return months[m - 1];
    }

    public String getDay()
    {
        int x = getDayOfWeek();
        String days[] = {
            "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
        };
        if(x > 7)
            return "Unknown to Man";
        else
            return days[x - 1];
    }

    public int getMonthInt()
    {
        return 1 + calendar.get(2);
    }

    public String getDate()
    {
        return (new StringBuilder()).append(getMonthInt()).append("/").append(getDayOfMonth()).append("/").append(getYear()).toString();
    }

    public String getCurrentDate()
    {
        Date dt = new Date();
        calendar.setTime(dt);
        return (new StringBuilder()).append(getMonthInt()).append("/").append(getDayOfMonth()).append("/").append(getYear()).toString();
    }

    public String getNextDate()
    {
        calendar.set(5, getDayOfMonth() + 1);
        return getDate();
    }

    public String getPrevDate()
    {
        calendar.set(5, getDayOfMonth() - 1);
        return getDate();
    }

    public String getTime()
    {
        return (new StringBuilder()).append(getHour()).append(":").append(getMinute()).append(":").append(getSecond()).toString();
    }

    public int getDayOfMonth()
    {
        return calendar.get(5);
    }

    public int getDayOfYear()
    {
        return calendar.get(6);
    }

    public int getWeekOfYear()
    {
        return calendar.get(3);
    }

    public int getWeekOfMonth()
    {
        return calendar.get(4);
    }

    public int getDayOfWeek()
    {
        return calendar.get(7);
    }

    public int getHour()
    {
        return calendar.get(11);
    }

    public int getMinute()
    {
        return calendar.get(12);
    }

    public int getSecond()
    {
        return calendar.get(13);
    }

    public int getEra()
    {
        return calendar.get(0);
    }

    public String getUSTimeZone()
    {
        String zones[] = {
            "Hawaii", "Alaskan", "Pacific", "Mountain", "Central", "Eastern"
        };
        return zones[10 + getZoneOffset()];
    }

    public int getZoneOffset()
    {
        return calendar.get(15) / 0x36ee80;
    }

    public int getDSTOffset()
    {
        return calendar.get(16) / 0x36ee80;
    }

    public int getAMPM()
    {
        return calendar.get(9);
    }

    Calendar calendar;
}
