// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Entry.java

package cal;


public class Entry
{

    public Entry(String hour)
    {
        this.hour = hour;
        description = "";
    }

    public String getHour()
    {
        return hour;
    }

    public String getColor()
    {
        if(description.equals(""))
            return "lightblue";
        else
            return "red";
    }

    public String getDescription()
    {
        if(description.equals(""))
            return "None";
        else
            return description;
    }

    public void setDescription(String descr)
    {
        description = descr;
    }

    String hour;
    String description;
}
