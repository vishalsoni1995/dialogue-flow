// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.IntentSender;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.zzaa;

// Referenced classes of package com.google.android.gms.common:
//            zzb

public final class ConnectionResult extends AbstractSafeParcelable
{

    ConnectionResult(int i, int j, PendingIntent pendingintent, String s)
    {
        mVersionCode = i;
        ob = j;
        mPendingIntent = pendingintent;
        qS = s;
    }

    public ConnectionResult(int i)
    {
        ConnectionResult(i, null, null);
    }

    public ConnectionResult(int i, PendingIntent pendingintent)
    {
        ConnectionResult(i, pendingintent, null);
    }

    public ConnectionResult(int i, PendingIntent pendingintent, String s)
    {
        ConnectionResult(1, i, pendingintent, s);
    }

    public void startResolutionForResult(Activity activity, int i)
        throws android.content.IntentSender.SendIntentException
    {
        if(!hasResolution())
        {
            return;
        } else
        {
            activity.startIntentSenderForResult(mPendingIntent.getIntentSender(), i, null, 0, 0, 0);
            return;
        }
    }

    public boolean hasResolution()
    {
        return ob != 0 && mPendingIntent != null;
    }

    public boolean isSuccess()
    {
        return ob == 0;
    }

    public int getErrorCode()
    {
        return ob;
    }

    public PendingIntent getResolution()
    {
        return mPendingIntent;
    }

    public String getErrorMessage()
    {
        return qS;
    }

    static String getStatusString(int i)
    {
        switch(i)
        {
        case 0: // '\0'
            return "SUCCESS";

        case 1: // '\001'
            return "SERVICE_MISSING";

        case 2: // '\002'
            return "SERVICE_VERSION_UPDATE_REQUIRED";

        case 3: // '\003'
            return "SERVICE_DISABLED";

        case 4: // '\004'
            return "SIGN_IN_REQUIRED";

        case 5: // '\005'
            return "INVALID_ACCOUNT";

        case 6: // '\006'
            return "RESOLUTION_REQUIRED";

        case 7: // '\007'
            return "NETWORK_ERROR";

        case 8: // '\b'
            return "INTERNAL_ERROR";

        case 9: // '\t'
            return "SERVICE_INVALID";

        case 10: // '\n'
            return "DEVELOPER_ERROR";

        case 11: // '\013'
            return "LICENSE_CHECK_FAILED";

        case 13: // '\r'
            return "CANCELED";

        case 14: // '\016'
            return "TIMEOUT";

        case 15: // '\017'
            return "INTERRUPTED";

        case 16: // '\020'
            return "API_UNAVAILABLE";

        case 17: // '\021'
            return "SIGN_IN_FAILED";

        case 18: // '\022'
            return "SERVICE_UPDATING";

        case 19: // '\023'
            return "SERVICE_MISSING_PERMISSION";

        case 20: // '\024'
            return "RESTRICTED_PROFILE";

        case 21: // '\025'
            return "API_VERSION_UPDATE_REQUIRED";

        case 42: // '*'
            return "UPDATE_ANDROID_WEAR";

        case 1500: 
            return "DRIVE_EXTERNAL_STORAGE_REQUIRED";

        case 99: // 'c'
            return "UNFINISHED";

        case -1: 
            return "UNKNOWN";
        }
        return (new StringBuilder(31)).append("UNKNOWN_ERROR_CODE(").append(i).append(")").toString();
    }

    public boolean equals(Object obj)
    {
        if(obj == this)
            return true;
        if(!(obj instanceof ConnectionResult))
        {
            return false;
        } else
        {
            ConnectionResult connectionresult = (ConnectionResult)obj;
            return ob == connectionresult.ob && zzaa.equal(mPendingIntent, connectionresult.mPendingIntent) && zzaa.equal(qS, connectionresult.qS);
        }
    }

    public int hashCode()
    {
        return zzaa.hashCode(new Object[] {
            Integer.valueOf(ob), mPendingIntent, qS
        });
    }

    public String toString()
    {
        return zzaa.zzz(this).zzg("statusCode", getStatusString(ob)).zzg("resolution", mPendingIntent).zzg("message", qS).toString();
    }

    public void writeToParcel(Parcel parcel, int i)
    {
        zzb.zza(this, parcel, i);
    }

    public static final int SUCCESS = 0;
    public static final int SERVICE_MISSING = 1;
    public static final int SERVICE_VERSION_UPDATE_REQUIRED = 2;
    public static final int SERVICE_DISABLED = 3;
    public static final int SIGN_IN_REQUIRED = 4;
    public static final int INVALID_ACCOUNT = 5;
    public static final int RESOLUTION_REQUIRED = 6;
    public static final int NETWORK_ERROR = 7;
    public static final int INTERNAL_ERROR = 8;
    public static final int SERVICE_INVALID = 9;
    public static final int DEVELOPER_ERROR = 10;
    public static final int LICENSE_CHECK_FAILED = 11;
    public static final int CANCELED = 13;
    public static final int TIMEOUT = 14;
    public static final int INTERRUPTED = 15;
    public static final int API_UNAVAILABLE = 16;
    public static final int SIGN_IN_FAILED = 17;
    public static final int SERVICE_UPDATING = 18;
    public static final int SERVICE_MISSING_PERMISSION = 19;
    public static final int RESTRICTED_PROFILE = 20;
    /**
     * @deprecated Field DRIVE_EXTERNAL_STORAGE_REQUIRED is deprecated
     */
    public static final int DRIVE_EXTERNAL_STORAGE_REQUIRED = 1500;
    public static final ConnectionResult qR = new ConnectionResult(0);
    public static final android.os.Parcelable.Creator CREATOR = new zzb();
    final int mVersionCode;
    private final int ob;
    private final PendingIntent mPendingIntent;
    private final String qS;

}
