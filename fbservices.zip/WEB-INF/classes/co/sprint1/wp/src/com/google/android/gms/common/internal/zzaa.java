// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.internal;

import java.util.*;

// Referenced classes of package com.google.android.gms.common.internal:
//            zzab

public final class zzaa
{
    public static final class zza
    {

        public zza zzg(String s, Object obj)
        {
            String s1;
            String s2;
            yU.add((new StringBuilder(1 + String.valueOf(s1 = (String)zzab.zzaa(s)).length() + String.valueOf(s2 = String.valueOf(String.valueOf(obj))).length())).append(s1).append("=").append(s2).toString());
            return this;
        }

        public String toString()
        {
            StringBuilder stringbuilder = (new StringBuilder(100)).append(zzcmy.getClass().getSimpleName()).append('{');
            int i = yU.size();
            for(int j = 0; j < i; j++)
            {
                stringbuilder.append((String)yU.get(j));
                if(j < i - 1)
                    stringbuilder.append(", ");
            }

            return stringbuilder.append('}').toString();
        }

        private final List yU;
        private final Object zzcmy;

        private zza(Object obj)
        {
            zzcmy = zzab.zzaa(obj);
            yU = new ArrayList();
        }

    }


    public static boolean equal(Object obj, Object obj1)
    {
        return obj == obj1 || obj != null && obj.equals(obj1);
    }

    public static transient int hashCode(Object aobj[])
    {
        return Arrays.hashCode(aobj);
    }

    public static zza zzz(Object obj)
    {
        return new zza(obj);
    }
}
