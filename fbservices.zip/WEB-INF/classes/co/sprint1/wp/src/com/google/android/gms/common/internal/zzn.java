// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.internal;

import android.content.*;
import android.os.*;
import com.google.android.gms.common.stats.zzb;
import java.util.*;

// Referenced classes of package com.google.android.gms.common.internal:
//            zzm, zzab, zzaa

final class zzn extends zzm
    implements android.os.Handler.Callback
{
    private static final class zza
    {

        public String toString()
        {
            return zzcvf != null ? zzcvf : yF.flattenToString();
        }

        public Intent zzasu()
        {
            Intent intent;
            if(zzcvf != null)
                intent = (new Intent(zzcvf)).setPackage(yE);
            else
                intent = (new Intent()).setComponent(yF);
            return intent;
        }

        public int hashCode()
        {
            return zzaa.hashCode(new Object[] {
                zzcvf, yF
            });
        }

        public boolean equals(Object obj)
        {
            if(this == obj)
                return true;
            if(!(obj instanceof zza))
            {
                return false;
            } else
            {
                zza zza1 = (zza)obj;
                return zzaa.equal(zzcvf, zza1.zzcvf) && zzaa.equal(yF, zza1.yF);
            }
        }

        private final String zzcvf;
        private final String yE;
        private final ComponentName yF;

        public zza(String s, String s1)
        {
            zzcvf = zzab.zzhs(s);
            yE = zzab.zzhs(s1);
            yF = null;
        }

        public zza(ComponentName componentname)
        {
            zzcvf = null;
            yE = null;
            yF = (ComponentName)zzab.zzaa(componentname);
        }
    }

    private final class zzb
    {
        public class zza
            implements ServiceConnection
        {

            public void onServiceConnected(ComponentName componentname, IBinder ibinder)
            {
                synchronized(zzn.zza(yL.yK))
                {
                    zzb.zza(yL, ibinder);
                    zzb.zza(yL, componentname);
                    ServiceConnection serviceconnection;
                    for(Iterator iterator = com.google.android.gms.common.internal.zzb.zzb(yL).iterator(); iterator.hasNext(); serviceconnection.onServiceConnected(componentname, ibinder))
                        serviceconnection = (ServiceConnection)iterator.next();

                    zzb.zza(yL, 1);
                }
            }

            public void onServiceDisconnected(ComponentName componentname)
            {
                synchronized(zzn.zza(yL.yK))
                {
                    zzb.zza(yL, null);
                    zzb.zza(yL, componentname);
                    ServiceConnection serviceconnection;
                    for(Iterator iterator = com.google.android.gms.common.internal.zzb.zzb(yL).iterator(); iterator.hasNext(); serviceconnection.onServiceDisconnected(componentname))
                        serviceconnection = (ServiceConnection)iterator.next();

                    zzb.zza(yL, 2);
                }
            }

            final zzb yL;

            public zza()
            {
                yL = zzb.this;
                Object();
            }
        }


        public void zzhn(String s)
        {
            mState = 3;
            yI = zzn.zzc(yK).zza(com.google.android.gms.common.internal.zzn.zzb(yK), s, yJ.zzasu(), yG, 129);
            if(!yI)
            {
                mState = 2;
                try
                {
                    zzn.zzc(yK).zza(com.google.android.gms.common.internal.zzn.zzb(yK), yG);
                }
                catch(IllegalArgumentException illegalargumentexception) { }
            }
        }

        public void zzho(String s)
        {
            zzn.zzc(yK).zza(com.google.android.gms.common.internal.zzn.zzb(yK), yG);
            yI = false;
            mState = 2;
        }

        public void zza(ServiceConnection serviceconnection, String s)
        {
            zzn.zzc(yK).zza(com.google.android.gms.common.internal.zzn.zzb(yK), serviceconnection, s, yJ.zzasu());
            yH.add(serviceconnection);
        }

        public void zzb(ServiceConnection serviceconnection, String s)
        {
            zzn.zzc(yK).zzb(com.google.android.gms.common.internal.zzn.zzb(yK), serviceconnection);
            yH.remove(serviceconnection);
        }

        public boolean isBound()
        {
            return yI;
        }

        public int getState()
        {
            return mState;
        }

        public boolean zza(ServiceConnection serviceconnection)
        {
            return yH.contains(serviceconnection);
        }

        public boolean zzasv()
        {
            return yH.isEmpty();
        }

        public IBinder getBinder()
        {
            return xA;
        }

        public ComponentName getComponentName()
        {
            return yF;
        }

        static zza zza(zzb zzb1)
        {
            return zzb1.yJ;
        }

        static Set zzb(zzb zzb1)
        {
            return zzb1.yH;
        }

        static IBinder zza(zzb zzb1, IBinder ibinder)
        {
            return zzb1.xA = ibinder;
        }

        static ComponentName zza(zzb zzb1, ComponentName componentname)
        {
            return zzb1.yF = componentname;
        }

        static int zza(zzb zzb1, int i)
        {
            return zzb1.mState = i;
        }

        private final zza yG = new zza();
        private final Set yH = new HashSet();
        private int mState;
        private boolean yI;
        private IBinder xA;
        private final zza yJ;
        private ComponentName yF;
        final zzn yK;

        public zzb(zza zza1)
        {
            yK = zzn.this;
            Object();
            yJ = zza1;
            mState = 2;
        }
    }


    zzn(Context context)
    {
        zzaqj = context.getApplicationContext();
        mHandler = new Handler(context.getMainLooper(), this);
    }

    public boolean zza(String s, String s1, ServiceConnection serviceconnection, String s2)
    {
        return zza(new zza(s, s1), serviceconnection, s2);
    }

    public boolean zza(ComponentName componentname, ServiceConnection serviceconnection, String s)
    {
        return zza(new zza(componentname), serviceconnection, s);
    }

    private boolean zza(zza zza1, ServiceConnection serviceconnection, String s)
    {
        com.google.android.gms.common.internal.zzab.zzb(serviceconnection, "ServiceConnection must not be null");
        HashMap hashmap = yB;
        JVM INSTR monitorenter ;
        zzb zzb1 = (zzb)yB.get(zza1);
        if(zzb1 == null)
        {
            zzb1 = new zzb(zza1);
            zzb1.zza(serviceconnection, s);
            zzb1.zzhn(s);
            yB.put(zza1, zzb1);
        } else
        {
            mHandler.removeMessages(0, zzb1);
            if(zzb1.zza(serviceconnection))
            {
                String s1 = String.valueOf(zza1);
                throw new IllegalStateException((new StringBuilder(81 + String.valueOf(s1).length())).append("Trying to bind a GmsServiceConnection that was already connected before.  config=").append(s1).toString());
            }
            zzb1.zza(serviceconnection, s);
            switch(zzb1.getState())
            {
            case 1: // '\001'
                serviceconnection.onServiceConnected(zzb1.getComponentName(), zzb1.getBinder());
                break;

            case 2: // '\002'
                zzb1.zzhn(s);
                break;
            }
        }
        return zzb1.isBound();
        Exception exception;
        exception;
        throw exception;
    }

    public void zzb(String s, String s1, ServiceConnection serviceconnection, String s2)
    {
        zzb(new zza(s, s1), serviceconnection, s2);
    }

    public void zzb(ComponentName componentname, ServiceConnection serviceconnection, String s)
    {
        zzb(new zza(componentname), serviceconnection, s);
    }

    private void zzb(zza zza1, ServiceConnection serviceconnection, String s)
    {
        com.google.android.gms.common.internal.zzab.zzb(serviceconnection, "ServiceConnection must not be null");
        synchronized(yB)
        {
            zzb zzb1 = (zzb)yB.get(zza1);
            if(zzb1 == null)
            {
                String s1 = String.valueOf(zza1);
                throw new IllegalStateException((new StringBuilder(50 + String.valueOf(s1).length())).append("Nonexistent connection status for service config: ").append(s1).toString());
            }
            if(!zzb1.zza(serviceconnection))
            {
                String s2 = String.valueOf(zza1);
                throw new IllegalStateException((new StringBuilder(76 + String.valueOf(s2).length())).append("Trying to unbind a GmsServiceConnection  that was not bound before.  config=").append(s2).toString());
            }
            zzb1.zzb(serviceconnection, s);
            if(zzb1.zzasv())
            {
                Message message = mHandler.obtainMessage(0, zzb1);
                mHandler.sendMessageDelayed(message, yD);
            }
        }
    }

    public boolean handleMessage(Message message)
    {
        switch(message.what)
        {
        case 0: // '\0'
            zzb zzb1 = (zzb)message.obj;
            synchronized(yB)
            {
                if(zzb1.zzasv())
                {
                    if(zzb1.isBound())
                        zzb1.zzho("GmsClientSupervisor");
                    yB.remove(zzb.zza(zzb1));
                }
            }
            return true;
        }
        return false;
    }

    static HashMap zza(zzn zzn1)
    {
        return zzn1.yB;
    }

    static Context zzb(zzn zzn1)
    {
        return zzn1.zzaqj;
    }

    static com.google.android.gms.common.stats.zzb zzc(zzn zzn1)
    {
        return zzn1.yC;
    }

    private final HashMap yB = new HashMap();
    private final Context zzaqj;
    private final Handler mHandler;
    private final com.google.android.gms.common.stats.zzb yC = com.google.android.gms.common.stats.zzb.zzaut();
    private final long yD = 5000L;
}
