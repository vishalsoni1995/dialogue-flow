// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.*;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

// Referenced classes of package com.google.android.gms.common.internal:
//            GetServiceRequest

public class zzj
    implements android.os.Parcelable.Creator
{

    public zzj()
    {
    }

    public GetServiceRequest zzcf(Parcel parcel)
    {
        int i = com.google.android.gms.common.internal.safeparcel.zza.zzcl(parcel);
        int j = 0;
        int k = 0;
        int l = 0;
        String s = null;
        IBinder ibinder = null;
        Scope ascope[] = null;
        Bundle bundle = null;
        Account account = null;
        long l1 = 0L;
        do
        {
            if(parcel.dataPosition() >= i)
                break;
            int i1 = com.google.android.gms.common.internal.safeparcel.zza.zzck(parcel);
            switch(com.google.android.gms.common.internal.safeparcel.zza.zzgi(i1))
            {
            case 1: // '\001'
                j = com.google.android.gms.common.internal.safeparcel.zza.zzg(parcel, i1);
                break;

            case 2: // '\002'
                k = com.google.android.gms.common.internal.safeparcel.zza.zzg(parcel, i1);
                break;

            case 3: // '\003'
                l = com.google.android.gms.common.internal.safeparcel.zza.zzg(parcel, i1);
                break;

            case 4: // '\004'
                s = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, i1);
                break;

            case 5: // '\005'
                ibinder = com.google.android.gms.common.internal.safeparcel.zza.zzr(parcel, i1);
                break;

            case 6: // '\006'
                ascope = (Scope[])com.google.android.gms.common.internal.safeparcel.zza.zzb(parcel, i1, Scope.CREATOR);
                break;

            case 7: // '\007'
                bundle = com.google.android.gms.common.internal.safeparcel.zza.zzs(parcel, i1);
                break;

            case 8: // '\b'
                account = (Account)com.google.android.gms.common.internal.safeparcel.zza.zza(parcel, i1, Account.CREATOR);
                break;

            case 9: // '\t'
                l1 = com.google.android.gms.common.internal.safeparcel.zza.zzi(parcel, i1);
                break;

            default:
                com.google.android.gms.common.internal.safeparcel.zza.zzb(parcel, i1);
                break;
            }
        } while(true);
        if(parcel.dataPosition() != i)
        {
            throw new zza((new StringBuilder(37)).append("Overread allowed size end=").append(i).toString(), parcel);
        } else
        {
            GetServiceRequest getservicerequest = new GetServiceRequest(j, k, l, s, ibinder, ascope, bundle, account, l1);
            return getservicerequest;
        }
    }

    public GetServiceRequest[] zzga(int i)
    {
        return new GetServiceRequest[i];
    }

    static void zza(GetServiceRequest getservicerequest, Parcel parcel, int i)
    {
        int j = zzb.zzcm(parcel);
        zzb.zzc(parcel, 1, getservicerequest.version);
        zzb.zzc(parcel, 2, getservicerequest.yi);
        zzb.zzc(parcel, 3, getservicerequest.yj);
        zzb.zza(parcel, 4, getservicerequest.yk, false);
        zzb.zza(parcel, 5, getservicerequest.yl, false);
        zzb.zza(parcel, 6, getservicerequest.ym, i, false);
        zzb.zza(parcel, 7, getservicerequest.yn, false);
        zzb.zza(parcel, 8, getservicerequest.yo, i, false);
        zzb.zza(parcel, 9, getservicerequest.yp);
        zzb.zzaj(parcel, j);
    }

    public Object[] newArray(int i)
    {
        return zzga(i);
    }

    public Object createFromParcel(Parcel parcel)
    {
        return zzcf(parcel);
    }
}
