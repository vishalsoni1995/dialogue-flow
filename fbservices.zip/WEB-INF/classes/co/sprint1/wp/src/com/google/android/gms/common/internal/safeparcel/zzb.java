// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.internal.safeparcel;

import android.os.*;
import java.util.List;

public class zzb
{

    private static void zzb(Parcel parcel, int i, int j)
    {
        if(j >= 65535)
        {
            parcel.writeInt(0xffff0000 | i);
            parcel.writeInt(j);
        } else
        {
            parcel.writeInt(j << 16 | i);
        }
    }

    private static int zzah(Parcel parcel, int i)
    {
        parcel.writeInt(0xffff0000 | i);
        parcel.writeInt(0);
        return parcel.dataPosition();
    }

    private static void zzai(Parcel parcel, int i)
    {
        int j = parcel.dataPosition();
        int k = j - i;
        parcel.setDataPosition(i - 4);
        parcel.writeInt(k);
        parcel.setDataPosition(j);
    }

    public static int zzcm(Parcel parcel)
    {
        return zzah(parcel, 20293);
    }

    public static void zzaj(Parcel parcel, int i)
    {
        zzai(parcel, i);
    }

    public static void zza(Parcel parcel, int i, boolean flag)
    {
        zzb(parcel, i, 4);
        parcel.writeInt(flag ? 1 : 0);
    }

    public static void zza(Parcel parcel, int i, Boolean boolean1, boolean flag)
    {
        if(boolean1 == null)
        {
            if(flag)
                zzb(parcel, i, 0);
            return;
        } else
        {
            zzb(parcel, i, 4);
            parcel.writeInt(boolean1.booleanValue() ? 1 : 0);
            return;
        }
    }

    public static void zza(Parcel parcel, int i, byte byte0)
    {
        zzb(parcel, i, 4);
        parcel.writeInt(byte0);
    }

    public static void zza(Parcel parcel, int i, short word0)
    {
        zzb(parcel, i, 4);
        parcel.writeInt(word0);
    }

    public static void zzc(Parcel parcel, int i, int j)
    {
        zzb(parcel, i, 4);
        parcel.writeInt(j);
    }

    public static void zza(Parcel parcel, int i, Integer integer, boolean flag)
    {
        if(integer == null)
        {
            if(flag)
                zzb(parcel, i, 0);
            return;
        } else
        {
            zzb(parcel, i, 4);
            parcel.writeInt(integer.intValue());
            return;
        }
    }

    public static void zza(Parcel parcel, int i, long l)
    {
        zzb(parcel, i, 8);
        parcel.writeLong(l);
    }

    public static void zza(Parcel parcel, int i, Long long1, boolean flag)
    {
        if(long1 == null)
        {
            if(flag)
                zzb(parcel, i, 0);
            return;
        } else
        {
            zzb(parcel, i, 8);
            parcel.writeLong(long1.longValue());
            return;
        }
    }

    public static void zza(Parcel parcel, int i, float f)
    {
        zzb(parcel, i, 4);
        parcel.writeFloat(f);
    }

    public static void zza(Parcel parcel, int i, Float float1, boolean flag)
    {
        if(float1 == null)
        {
            if(flag)
                zzb(parcel, i, 0);
            return;
        } else
        {
            zzb(parcel, i, 4);
            parcel.writeFloat(float1.floatValue());
            return;
        }
    }

    public static void zza(Parcel parcel, int i, double d)
    {
        zzb(parcel, i, 8);
        parcel.writeDouble(d);
    }

    public static void zza(Parcel parcel, int i, Double double1, boolean flag)
    {
        if(double1 == null)
        {
            if(flag)
                zzb(parcel, i, 0);
            return;
        } else
        {
            zzb(parcel, i, 8);
            parcel.writeDouble(double1.doubleValue());
            return;
        }
    }

    public static void zza(Parcel parcel, int i, String s, boolean flag)
    {
        if(s == null)
        {
            if(flag)
                zzb(parcel, i, 0);
            return;
        } else
        {
            int j = zzah(parcel, i);
            parcel.writeString(s);
            zzai(parcel, j);
            return;
        }
    }

    public static void zza(Parcel parcel, int i, IBinder ibinder, boolean flag)
    {
        if(ibinder == null)
        {
            if(flag)
                zzb(parcel, i, 0);
            return;
        } else
        {
            int j = zzah(parcel, i);
            parcel.writeStrongBinder(ibinder);
            zzai(parcel, j);
            return;
        }
    }

    public static void zza(Parcel parcel, int i, Parcelable parcelable, int j, boolean flag)
    {
        if(parcelable == null)
        {
            if(flag)
                zzb(parcel, i, 0);
            return;
        } else
        {
            int k = zzah(parcel, i);
            parcelable.writeToParcel(parcel, j);
            zzai(parcel, k);
            return;
        }
    }

    public static void zza(Parcel parcel, int i, Bundle bundle, boolean flag)
    {
        if(bundle == null)
        {
            if(flag)
                zzb(parcel, i, 0);
            return;
        } else
        {
            int j = zzah(parcel, i);
            parcel.writeBundle(bundle);
            zzai(parcel, j);
            return;
        }
    }

    public static void zza(Parcel parcel, int i, byte abyte0[], boolean flag)
    {
        if(abyte0 == null)
        {
            if(flag)
                zzb(parcel, i, 0);
            return;
        } else
        {
            int j = zzah(parcel, i);
            parcel.writeByteArray(abyte0);
            zzai(parcel, j);
            return;
        }
    }

    public static void zza(Parcel parcel, int i, byte abyte0[][], boolean flag)
    {
        if(abyte0 == null)
        {
            if(flag)
                zzb(parcel, i, 0);
            return;
        }
        int j = zzah(parcel, i);
        int k = abyte0.length;
        parcel.writeInt(k);
        for(int l = 0; l < k; l++)
            parcel.writeByteArray(abyte0[l]);

        zzai(parcel, j);
    }

    public static void zza(Parcel parcel, int i, boolean aflag[], boolean flag)
    {
        if(aflag == null)
        {
            if(flag)
                zzb(parcel, i, 0);
            return;
        } else
        {
            int j = zzah(parcel, i);
            parcel.writeBooleanArray(aflag);
            zzai(parcel, j);
            return;
        }
    }

    public static void zza(Parcel parcel, int i, int ai[], boolean flag)
    {
        if(ai == null)
        {
            if(flag)
                zzb(parcel, i, 0);
            return;
        } else
        {
            int j = zzah(parcel, i);
            parcel.writeIntArray(ai);
            zzai(parcel, j);
            return;
        }
    }

    public static void zza(Parcel parcel, int i, long al[], boolean flag)
    {
        if(al == null)
        {
            if(flag)
                zzb(parcel, i, 0);
            return;
        } else
        {
            int j = zzah(parcel, i);
            parcel.writeLongArray(al);
            zzai(parcel, j);
            return;
        }
    }

    public static void zza(Parcel parcel, int i, float af[], boolean flag)
    {
        if(af == null)
        {
            if(flag)
                zzb(parcel, i, 0);
            return;
        } else
        {
            int j = zzah(parcel, i);
            parcel.writeFloatArray(af);
            zzai(parcel, j);
            return;
        }
    }

    public static void zza(Parcel parcel, int i, String as[], boolean flag)
    {
        if(as == null)
        {
            if(flag)
                zzb(parcel, i, 0);
            return;
        } else
        {
            int j = zzah(parcel, i);
            parcel.writeStringArray(as);
            zzai(parcel, j);
            return;
        }
    }

    public static void zza(Parcel parcel, int i, List list, boolean flag)
    {
        if(list == null)
        {
            if(flag)
                zzb(parcel, i, 0);
            return;
        }
        int j = zzah(parcel, i);
        int k = list.size();
        parcel.writeInt(k);
        for(int l = 0; l < k; l++)
            parcel.writeInt(((Integer)list.get(l)).intValue());

        zzai(parcel, j);
    }

    public static void zzb(Parcel parcel, int i, List list, boolean flag)
    {
        if(list == null)
        {
            if(flag)
                zzb(parcel, i, 0);
            return;
        } else
        {
            int j = zzah(parcel, i);
            parcel.writeStringList(list);
            zzai(parcel, j);
            return;
        }
    }

    public static void zza(Parcel parcel, int i, Parcelable aparcelable[], int j, boolean flag)
    {
        if(aparcelable == null)
        {
            if(flag)
                zzb(parcel, i, 0);
            return;
        }
        int k = zzah(parcel, i);
        int l = aparcelable.length;
        parcel.writeInt(l);
        for(int i1 = 0; i1 < l; i1++)
        {
            Parcelable parcelable = aparcelable[i1];
            if(parcelable == null)
                parcel.writeInt(0);
            else
                zza(parcel, parcelable, j);
        }

        zzai(parcel, k);
    }

    public static void zzc(Parcel parcel, int i, List list, boolean flag)
    {
        if(list == null)
        {
            if(flag)
                zzb(parcel, i, 0);
            return;
        }
        int j = zzah(parcel, i);
        int k = list.size();
        parcel.writeInt(k);
        for(int l = 0; l < k; l++)
        {
            Parcelable parcelable = (Parcelable)list.get(l);
            if(parcelable == null)
                parcel.writeInt(0);
            else
                zza(parcel, parcelable, 0);
        }

        zzai(parcel, j);
    }

    private static void zza(Parcel parcel, Parcelable parcelable, int i)
    {
        int j = parcel.dataPosition();
        parcel.writeInt(1);
        int k = parcel.dataPosition();
        parcelable.writeToParcel(parcel, i);
        int l = parcel.dataPosition();
        parcel.setDataPosition(j);
        parcel.writeInt(l - k);
        parcel.setDataPosition(l);
    }

    public static void zza(Parcel parcel, int i, Parcel parcel1, boolean flag)
    {
        if(parcel1 == null)
        {
            if(flag)
                zzb(parcel, i, 0);
            return;
        } else
        {
            int j = zzah(parcel, i);
            parcel.appendFrom(parcel1, 0, parcel1.dataSize());
            zzai(parcel, j);
            return;
        }
    }

    public static void zzd(Parcel parcel, int i, List list, boolean flag)
    {
        if(list == null)
        {
            if(flag)
                zzb(parcel, i, 0);
            return;
        } else
        {
            int j = zzah(parcel, i);
            parcel.writeList(list);
            zzai(parcel, j);
            return;
        }
    }
}
