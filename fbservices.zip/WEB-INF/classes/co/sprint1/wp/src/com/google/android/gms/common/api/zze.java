// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.api;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

// Referenced classes of package com.google.android.gms.common.api:
//            Scope

public class zze
    implements android.os.Parcelable.Creator
{

    public zze()
    {
    }

    public Scope zzby(Parcel parcel)
    {
        int i = com.google.android.gms.common.internal.safeparcel.zza.zzcl(parcel);
        int j = 0;
        String s = null;
        do
        {
            if(parcel.dataPosition() >= i)
                break;
            int k = com.google.android.gms.common.internal.safeparcel.zza.zzck(parcel);
            switch(com.google.android.gms.common.internal.safeparcel.zza.zzgi(k))
            {
            case 1: // '\001'
                j = com.google.android.gms.common.internal.safeparcel.zza.zzg(parcel, k);
                break;

            case 2: // '\002'
                s = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, k);
                break;

            default:
                com.google.android.gms.common.internal.safeparcel.zza.zzb(parcel, k);
                break;
            }
        } while(true);
        if(parcel.dataPosition() != i)
        {
            throw new zza((new StringBuilder(37)).append("Overread allowed size end=").append(i).toString(), parcel);
        } else
        {
            Scope scope = new Scope(j, s);
            return scope;
        }
    }

    public Scope[] zzfd(int i)
    {
        return new Scope[i];
    }

    static void zza(Scope scope, Parcel parcel, int i)
    {
        int j = zzb.zzcm(parcel);
        zzb.zzc(parcel, 1, scope.mVersionCode);
        zzb.zza(parcel, 2, scope.zzaoh(), false);
        zzb.zzaj(parcel, j);
    }

    public Object[] newArray(int i)
    {
        return zzfd(i);
    }

    public Object createFromParcel(Parcel parcel)
    {
        return zzby(parcel);
    }
}
