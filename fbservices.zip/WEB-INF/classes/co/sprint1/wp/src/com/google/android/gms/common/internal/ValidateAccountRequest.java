// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.internal;

import android.os.*;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

// Referenced classes of package com.google.android.gms.common.internal:
//            zzaj, zzq

/**
 * @deprecated Class ValidateAccountRequest is deprecated
 */

public class ValidateAccountRequest extends AbstractSafeParcelable
{

    ValidateAccountRequest(int i, int j, IBinder ibinder, Scope ascope[], Bundle bundle, String s)
    {
        mVersionCode = i;
        ze = j;
        wY = ibinder;
        ro = ascope;
        zf = bundle;
        zg = s;
    }

    public int zzatk()
    {
        return ze;
    }

    public Scope[] zzati()
    {
        return ro;
    }

    public String getCallingPackage()
    {
        return zg;
    }

    public Bundle zzatl()
    {
        return zf;
    }

    public void writeToParcel(Parcel parcel, int i)
    {
        zzaj.zza(this, parcel, i);
    }

    public static final android.os.Parcelable.Creator CREATOR = new zzaj();
    final int mVersionCode;
    private final int ze;
    final IBinder wY;
    private final Scope ro[];
    private final Bundle zf;
    private final String zg;

}
