// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.internal;

import android.content.Intent;
import android.net.Uri;
import android.support.v4.app.ShareCompat;
import android.text.TextUtils;

public class zzo
{

    public static Intent zzhp(String s)
    {
        Uri uri = Uri.fromParts("package", s, null);
        Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
        intent.setData(uri);
        return intent;
    }

    private static Uri zzac(String s, String s1)
    {
        android.net.Uri.Builder builder = Uri.parse("market://details").buildUpon().appendQueryParameter("id", s);
        if(!TextUtils.isEmpty(s1))
            builder.appendQueryParameter("pcampaignid", s1);
        return builder.build();
    }

    public static Intent zzad(String s, String s1)
    {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(zzac(s, s1));
        intent.setPackage("com.android.vending");
        intent.addFlags(0x80000);
        return intent;
    }

    public static Intent zzasw()
    {
        Intent intent = new Intent("com.google.android.clockwork.home.UPDATE_ANDROID_WEAR_ACTION");
        intent.setPackage("com.google.android.wearable.app");
        return intent;
    }

    private static final Uri yM;
    private static final Uri yN;

    static 
    {
        yM = Uri.parse("http://plus.google.com/");
        yN = yM.buildUpon().appendPath("circles").appendPath("find").build();
    }
}
