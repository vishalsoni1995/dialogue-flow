// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.internal.safeparcel;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.zzab;

// Referenced classes of package com.google.android.gms.common.internal.safeparcel:
//            SafeParcelable

public final class zzc
{

    public static byte[] zza(SafeParcelable safeparcelable)
    {
        Parcel parcel = Parcel.obtain();
        safeparcelable.writeToParcel(parcel, 0);
        byte abyte0[] = parcel.marshall();
        parcel.recycle();
        return abyte0;
    }

    public static SafeParcelable zza(byte abyte0[], android.os.Parcelable.Creator creator)
    {
        zzab.zzaa(creator);
        Parcel parcel = Parcel.obtain();
        parcel.unmarshall(abyte0, 0, abyte0.length);
        parcel.setDataPosition(0);
        SafeParcelable safeparcelable = (SafeParcelable)creator.createFromParcel(parcel);
        parcel.recycle();
        return safeparcelable;
    }

    public static void zza(SafeParcelable safeparcelable, Intent intent, String s)
    {
        intent.putExtra(s, zza(safeparcelable));
    }

    public static SafeParcelable zza(Intent intent, String s, android.os.Parcelable.Creator creator)
    {
        byte abyte0[] = intent.getByteArrayExtra(s);
        if(abyte0 == null)
            return null;
        else
            return zza(abyte0, creator);
    }
}
