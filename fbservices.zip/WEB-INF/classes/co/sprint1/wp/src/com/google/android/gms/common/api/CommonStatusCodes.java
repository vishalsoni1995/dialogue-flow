// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.api;


public class CommonStatusCodes
{

    public CommonStatusCodes()
    {
    }

    public static String getStatusCodeString(int i)
    {
        switch(i)
        {
        case -1: 
            return "SUCCESS_CACHE";

        case 0: // '\0'
            return "SUCCESS";

        case 2: // '\002'
            return "SERVICE_VERSION_UPDATE_REQUIRED";

        case 3: // '\003'
            return "SERVICE_DISABLED";

        case 4: // '\004'
            return "SIGN_IN_REQUIRED";

        case 5: // '\005'
            return "INVALID_ACCOUNT";

        case 6: // '\006'
            return "RESOLUTION_REQUIRED";

        case 7: // '\007'
            return "NETWORK_ERROR";

        case 8: // '\b'
            return "INTERNAL_ERROR";

        case 10: // '\n'
            return "DEVELOPER_ERROR";

        case 13: // '\r'
            return "ERROR";

        case 14: // '\016'
            return "INTERRUPTED";

        case 15: // '\017'
            return "TIMEOUT";

        case 16: // '\020'
            return "CANCELED";

        case 17: // '\021'
            return "API_NOT_CONNECTED";

        case 18: // '\022'
            return "DEAD_CLIENT";

        case 1: // '\001'
        case 9: // '\t'
        case 11: // '\013'
        case 12: // '\f'
        default:
            return (new StringBuilder(32)).append("unknown status code: ").append(i).toString();
        }
    }

    public static final int SUCCESS_CACHE = -1;
    public static final int SUCCESS = 0;
    /**
     * @deprecated Field SERVICE_VERSION_UPDATE_REQUIRED is deprecated
     */
    public static final int SERVICE_VERSION_UPDATE_REQUIRED = 2;
    /**
     * @deprecated Field SERVICE_DISABLED is deprecated
     */
    public static final int SERVICE_DISABLED = 3;
    public static final int SIGN_IN_REQUIRED = 4;
    public static final int INVALID_ACCOUNT = 5;
    public static final int RESOLUTION_REQUIRED = 6;
    public static final int NETWORK_ERROR = 7;
    public static final int INTERNAL_ERROR = 8;
    public static final int DEVELOPER_ERROR = 10;
    public static final int ERROR = 13;
    public static final int INTERRUPTED = 14;
    public static final int TIMEOUT = 15;
    public static final int CANCELED = 16;
    public static final int API_NOT_CONNECTED = 17;
    public static final int DEAD_CLIENT = 18;
}
