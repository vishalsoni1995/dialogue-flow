// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.ads.identifier;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.internal.zzab;
import com.google.android.gms.common.stats.zzb;
import com.google.android.gms.common.zza;
import com.google.android.gms.common.zzc;
import com.google.android.gms.internal.zzcc;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class AdvertisingIdClient
{
    public static final class Info
    {

        public String getId()
        {
            return zzajl;
        }

        public boolean isLimitAdTrackingEnabled()
        {
            return zzajm;
        }

        public String toString()
        {
            String s = zzajl;
            boolean flag = zzajm;
            return (new StringBuilder(7 + String.valueOf(s).length())).append("{").append(s).append("}").append(flag).toString();
        }

        private final String zzajl;
        private final boolean zzajm;

        public Info(String s, boolean flag)
        {
            zzajl = s;
            zzajm = flag;
        }
    }

    static class zza extends Thread
    {

        public void cancel()
        {
            zzajj.countDown();
        }

        public boolean zzdk()
        {
            return zzajk;
        }

        private void disconnect()
        {
            AdvertisingIdClient advertisingidclient = (AdvertisingIdClient)zzajh.get();
            if(advertisingidclient != null)
            {
                advertisingidclient.finish();
                zzajk = true;
            }
        }

        public void run()
        {
            try
            {
                if(!zzajj.await(zzaji, TimeUnit.MILLISECONDS))
                    disconnect();
            }
            catch(InterruptedException interruptedexception)
            {
                disconnect();
            }
        }

        private WeakReference zzajh;
        private long zzaji;
        CountDownLatch zzajj;
        boolean zzajk;

        public zza(AdvertisingIdClient advertisingidclient, long l)
        {
            zzajh = new WeakReference(advertisingidclient);
            zzaji = l;
            zzajj = new CountDownLatch(1);
            zzajk = false;
            start();
        }
    }


    public AdvertisingIdClient(Context context)
    {
        AdvertisingIdClient(context, 30000L);
    }

    public AdvertisingIdClient(Context context, long l)
    {
        zzaje = new Object();
        zzab.zzaa(context);
        mContext = context;
        zzajd = false;
        zzajg = l;
    }

    public void start()
        throws IOException, IllegalStateException, GooglePlayServicesNotAvailableException, GooglePlayServicesRepairableException
    {
        zze(true);
    }

    protected void zze(boolean flag)
        throws IOException, IllegalStateException, GooglePlayServicesNotAvailableException, GooglePlayServicesRepairableException
    {
        zzab.zzhk("Calling this from your main thread can lead to deadlock");
        synchronized(this)
        {
            if(zzajd)
                finish();
            zzajb = zzh(mContext);
            zzajc = zza(mContext, zzajb);
            zzajd = true;
            if(flag)
                zzdj();
        }
    }

    public static void setShouldSkipGmsCoreVersionCheck(boolean flag)
    {
    }

    private void zzdj()
    {
        synchronized(zzaje)
        {
            if(zzajf != null)
            {
                zzajf.cancel();
                try
                {
                    zzajf.join();
                }
                catch(InterruptedException interruptedexception) { }
            }
            if(zzajg > 0L)
                zzajf = new zza(this, zzajg);
        }
    }

    public Info getInfo()
        throws IOException
    {
        zzab.zzhk("Calling this from your main thread can lead to deadlock");
        Info info = null;
        synchronized(this)
        {
            if(!zzajd)
            {
                synchronized(zzaje)
                {
                    if(zzajf == null || !zzajf.zzdk())
                        throw new IOException("AdvertisingIdClient is not connected.");
                }
                try
                {
                    zze(false);
                }
                catch(Exception exception)
                {
                    throw new IOException("AdvertisingIdClient cannot reconnect.", exception);
                }
                if(!zzajd)
                    throw new IOException("AdvertisingIdClient cannot reconnect.");
            }
            zzab.zzaa(zzajb);
            zzab.zzaa(zzajc);
            try
            {
                info = new Info(zzajc.getId(), zzajc.zzf(true));
            }
            catch(RemoteException remoteexception)
            {
                Log.i("AdvertisingIdClient", "GMS remote exception ", remoteexception);
                throw new IOException("Remote exception");
            }
        }
        zzdj();
        return info;
    }

    public void finish()
    {
label0:
        {
            zzab.zzhk("Calling this from your main thread can lead to deadlock");
            synchronized(this)
            {
                if(mContext != null && zzajb != null)
                    break label0;
            }
            return;
        }
        try
        {
            if(zzajd)
                zzb.zzaut().zza(mContext, zzajb);
        }
        catch(IllegalArgumentException illegalargumentexception)
        {
            Log.i("AdvertisingIdClient", "AdvertisingIdClient unbindService failed.", illegalargumentexception);
        }
        zzajd = false;
        zzajc = null;
        zzajb = null;
        advertisingidclient;
        JVM INSTR monitorexit ;
          goto _L1
        exception;
        throw exception;
_L1:
    }

    protected void finalize()
        throws Throwable
    {
        finish();
        finalize();
    }

    static com.google.android.gms.common.zza zzh(Context context)
        throws IOException, GooglePlayServicesNotAvailableException, GooglePlayServicesRepairableException
    {
        try
        {
            PackageManager packagemanager = context.getPackageManager();
            packagemanager.getPackageInfo("com.android.vending", 0);
        }
        catch(android.content.pm.PackageManager.NameNotFoundException namenotfoundexception)
        {
            throw new GooglePlayServicesNotAvailableException(9);
        }
        int i = zzc.zzand().isGooglePlayServicesAvailable(context);
        com.google.android.gms.common.zza zza1;
        switch(i)
        {
        default:
            throw new IOException("Google Play services not available");

        case 0: // '\0'
        case 2: // '\002'
            zza1 = new zza();
            break;
        }
        Intent intent = new Intent("com.google.android.gms.ads.identifier.service.START");
        intent.setPackage("com.google.android.gms");
        try
        {
            if(zzb.zzaut().zza(context, intent, zza1, 1))
                return zza1;
        }
        catch(Throwable throwable)
        {
            throw new IOException(throwable);
        }
        throw new IOException("Connection failure");
    }

    public static Info getAdvertisingIdInfo(Context context)
        throws IOException, IllegalStateException, GooglePlayServicesNotAvailableException, GooglePlayServicesRepairableException
    {
        AdvertisingIdClient advertisingidclient = new AdvertisingIdClient(context, -1L);
        Info info;
        advertisingidclient.zze(false);
        info = advertisingidclient.getInfo();
        advertisingidclient.finish();
        return info;
        Exception exception;
        exception;
        advertisingidclient.finish();
        throw exception;
    }

    static zzcc zza(Context context, com.google.android.gms.common.zza zza1)
        throws IOException
    {
        try
        {
            return com.google.android.gms.internal.zzcc.zza.zzf(zza1.zza(10000L, TimeUnit.MILLISECONDS));
        }
        catch(InterruptedException interruptedexception)
        {
            throw new IOException("Interrupted exception");
        }
        catch(Throwable throwable)
        {
            throw new IOException(throwable);
        }
    }

    com.google.android.gms.common.zza zzajb;
    zzcc zzajc;
    boolean zzajd;
    Object zzaje;
    zza zzajf;
    private final Context mContext;
    final long zzajg;
}
