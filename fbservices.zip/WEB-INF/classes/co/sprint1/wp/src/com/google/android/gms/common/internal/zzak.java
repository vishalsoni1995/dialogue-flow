// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.internal;

import android.content.Context;
import android.content.res.Resources;
import android.util.*;

public class zzak
{

    public static String zza(String s, String s1, Context context, AttributeSet attributeset, boolean flag, boolean flag1, String s2)
    {
        String s3 = attributeset != null ? attributeset.getAttributeValue(s, s1) : null;
        if(s3 != null && s3.startsWith("@string/") && flag)
        {
            String s4 = s3.substring("@string/".length());
            String s5 = context.getPackageName();
            TypedValue typedvalue = new TypedValue();
            String s7;
            try
            {
                context.getResources().getValue((new StringBuilder(8 + String.valueOf(s5).length() + String.valueOf(s4).length())).append(s5).append(":string/").append(s4).toString(), typedvalue, true);
            }
            catch(android.content.res.Resources.NotFoundException notfoundexception)
            {
                Log.w(s2, (new StringBuilder(30 + String.valueOf(s1).length() + String.valueOf(s7 = s3).length())).append("Could not find resource for ").append(s1).append(": ").append(s7).toString());
            }
            String s6;
            if(typedvalue.string != null)
                s3 = typedvalue.string.toString();
            else
                Log.w(s2, (new StringBuilder(28 + String.valueOf(s1).length() + String.valueOf(s6 = String.valueOf(typedvalue)).length())).append("Resource ").append(s1).append(" was not a string: ").append(s6).toString());
        }
        if(flag1 && s3 == null)
            Log.w(s2, (new StringBuilder(33 + String.valueOf(s1).length())).append("Required XML attribute \"").append(s1).append("\" missing").toString());
        return s3;
    }
}
