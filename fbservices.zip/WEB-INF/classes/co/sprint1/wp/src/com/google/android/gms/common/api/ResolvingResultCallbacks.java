// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.api;

import android.app.Activity;
import android.content.IntentSender;
import android.util.Log;
import com.google.android.gms.common.internal.zzab;

// Referenced classes of package com.google.android.gms.common.api:
//            ResultCallbacks, Status, Result

public abstract class ResolvingResultCallbacks extends ResultCallbacks
{

    protected ResolvingResultCallbacks(Activity activity, int i)
    {
        mActivity = (Activity)zzab.zzb(activity, "Activity must not be null");
        sd = i;
    }

    public final void onFailure(Status status)
    {
        if(status.hasResolution())
            try
            {
                status.startResolutionForResult(mActivity, sd);
            }
            catch(android.content.IntentSender.SendIntentException sendintentexception)
            {
                Log.e("ResolvingResultCallback", "Failed to start resolution", sendintentexception);
                onUnresolvableFailure(new Status(8));
            }
        else
            onUnresolvableFailure(status);
    }

    public abstract void onSuccess(Result result);

    public abstract void onUnresolvableFailure(Status status);

    private final Activity mActivity;
    private final int sd;
}
