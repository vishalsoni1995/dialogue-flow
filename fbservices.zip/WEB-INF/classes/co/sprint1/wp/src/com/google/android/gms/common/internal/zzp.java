// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.internal;

import android.util.Log;

// Referenced classes of package com.google.android.gms.common.internal:
//            zzab

public final class zzp
{

    public zzp(String s, String s1)
    {
        zzab.zzb(s, "log tag cannot be null");
        zzab.zzb(s.length() <= 23, "tag \"%s\" is longer than the %d character maximum", new Object[] {
            s, Integer.valueOf(23)
        });
        yQ = s;
        if(s1 == null || s1.length() <= 0)
            yR = null;
        else
            yR = s1;
    }

    public zzp(String s)
    {
        zzp(s, null);
    }

    public boolean zzgc(int i)
    {
        return Log.isLoggable(yQ, i);
    }

    public void zzae(String s, String s1)
    {
        if(zzgc(3))
            Log.d(s, zzhq(s1));
    }

    public void zzb(String s, String s1, Throwable throwable)
    {
        if(zzgc(4))
            Log.i(s, zzhq(s1), throwable);
    }

    public void zzaf(String s, String s1)
    {
        if(zzgc(5))
            Log.w(s, zzhq(s1));
    }

    public void zzc(String s, String s1, Throwable throwable)
    {
        if(zzgc(5))
            Log.w(s, zzhq(s1), throwable);
    }

    public void zzag(String s, String s1)
    {
        if(zzgc(6))
            Log.e(s, zzhq(s1));
    }

    public void zzd(String s, String s1, Throwable throwable)
    {
        if(zzgc(6))
            Log.e(s, zzhq(s1), throwable);
    }

    public void zze(String s, String s1, Throwable throwable)
    {
        if(zzgc(7))
        {
            Log.e(s, zzhq(s1), throwable);
            Log.wtf(s, zzhq(s1), throwable);
        }
    }

    private String zzhq(String s)
    {
        if(yR == null)
            return s;
        else
            return yR.concat(s);
    }

    public static final int yO = 23 - " PII_LOG".length();
    private static final String yP = null;
    private final String yQ;
    private final String yR;

}
