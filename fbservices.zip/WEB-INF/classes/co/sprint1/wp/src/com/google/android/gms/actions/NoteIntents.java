// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.actions;


public class NoteIntents
{

    private NoteIntents()
    {
    }

    public static final String ACTION_CREATE_NOTE = "com.google.android.gms.actions.CREATE_NOTE";
    public static final String ACTION_APPEND_NOTE = "com.google.android.gms.actions.APPEND_NOTE";
    public static final String ACTION_DELETE_NOTE = "com.google.android.gms.actions.DELETE_NOTE";
    public static final String EXTRA_NAME = "com.google.android.gms.actions.extra.NAME";
    public static final String EXTRA_TEXT = "com.google.android.gms.actions.extra.TEXT";
    public static final String EXTRA_NOTE_QUERY = "com.google.android.gms.actions.extra.NOTE_QUERY";
}
