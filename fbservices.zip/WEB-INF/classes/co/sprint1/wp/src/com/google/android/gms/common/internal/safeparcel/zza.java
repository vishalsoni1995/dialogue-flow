// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.internal.safeparcel;

import android.os.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

public class com.google.android.gms.common.internal.safeparcel.zza
{
    public static class zza extends RuntimeException
    {

        public zza(String s, Parcel parcel)
        {
            int i;
            int j;
            RuntimeException((new StringBuilder(41 + String.valueOf(s).length())).append(s).append(" Parcel: pos=").append(i = parcel.dataPosition()).append(" size=").append(j = parcel.dataSize()).toString());
        }
    }


    public static int zzck(Parcel parcel)
    {
        return parcel.readInt();
    }

    public static int zzgi(int i)
    {
        return i & 0xffff;
    }

    public static int zza(Parcel parcel, int i)
    {
        if((i & 0xffff0000) != 0xffff0000)
            return i >> 16 & 0xffff;
        else
            return parcel.readInt();
    }

    public static void zzb(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        parcel.setDataPosition(parcel.dataPosition() + j);
    }

    private static void zza(Parcel parcel, int i, int j)
    {
        int k = zza(parcel, i);
        if(k != j)
        {
            String s = String.valueOf(Integer.toHexString(k));
            throw new zza((new StringBuilder(46 + String.valueOf(s).length())).append("Expected size ").append(j).append(" got ").append(k).append(" (0x").append(s).append(")").toString(), parcel);
        } else
        {
            return;
        }
    }

    private static void zza(Parcel parcel, int i, int j, int k)
    {
        if(j != k)
        {
            String s = String.valueOf(Integer.toHexString(j));
            throw new zza((new StringBuilder(46 + String.valueOf(s).length())).append("Expected size ").append(k).append(" got ").append(j).append(" (0x").append(s).append(")").toString(), parcel);
        } else
        {
            return;
        }
    }

    public static int zzcl(Parcel parcel)
    {
        int i;
        int j;
        int k;
        i = zzck(parcel);
        j = zza(parcel, i);
        k = parcel.dataPosition();
        if(zzgi(i) == 20293) goto _L2; else goto _L1
_L1:
        JVM INSTR new #19  <Class zza$zza>;
        JVM INSTR dup ;
        "Expected object header. Got 0x";
        String s = String.valueOf(Integer.toHexString(i));
        s;
        if(s.length() == 0) goto _L4; else goto _L3
_L3:
        concat();
          goto _L5
_L4:
        JVM INSTR pop ;
        JVM INSTR new #27  <Class String>;
        JVM INSTR dup_x1 ;
        JVM INSTR swap ;
        String();
_L5:
        parcel;
        zza();
        throw ;
_L2:
        int l = k + j;
        if(l < k || l > parcel.dataSize())
            throw new zza((new StringBuilder(54)).append("Size read is invalid start=").append(k).append(" end=").append(l).toString(), parcel);
        else
            return l;
    }

    public static boolean zzc(Parcel parcel, int i)
    {
        zza(parcel, i, 4);
        return parcel.readInt() != 0;
    }

    public static Boolean zzd(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        if(j == 0)
        {
            return null;
        } else
        {
            zza(parcel, i, j, 4);
            return Boolean.valueOf(parcel.readInt() != 0);
        }
    }

    public static byte zze(Parcel parcel, int i)
    {
        zza(parcel, i, 4);
        return (byte)parcel.readInt();
    }

    public static short zzf(Parcel parcel, int i)
    {
        zza(parcel, i, 4);
        return (short)parcel.readInt();
    }

    public static int zzg(Parcel parcel, int i)
    {
        zza(parcel, i, 4);
        return parcel.readInt();
    }

    public static Integer zzh(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        if(j == 0)
        {
            return null;
        } else
        {
            zza(parcel, i, j, 4);
            return Integer.valueOf(parcel.readInt());
        }
    }

    public static long zzi(Parcel parcel, int i)
    {
        zza(parcel, i, 8);
        return parcel.readLong();
    }

    public static Long zzj(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        if(j == 0)
        {
            return null;
        } else
        {
            zza(parcel, i, j, 8);
            return Long.valueOf(parcel.readLong());
        }
    }

    public static BigInteger zzk(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        int k = parcel.dataPosition();
        if(j == 0)
        {
            return null;
        } else
        {
            byte abyte0[] = parcel.createByteArray();
            parcel.setDataPosition(k + j);
            return new BigInteger(abyte0);
        }
    }

    public static float zzl(Parcel parcel, int i)
    {
        zza(parcel, i, 4);
        return parcel.readFloat();
    }

    public static Float zzm(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        if(j == 0)
        {
            return null;
        } else
        {
            zza(parcel, i, j, 4);
            return Float.valueOf(parcel.readFloat());
        }
    }

    public static double zzn(Parcel parcel, int i)
    {
        zza(parcel, i, 8);
        return parcel.readDouble();
    }

    public static Double zzo(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        if(j == 0)
        {
            return null;
        } else
        {
            zza(parcel, i, j, 8);
            return Double.valueOf(parcel.readDouble());
        }
    }

    public static BigDecimal zzp(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        int k = parcel.dataPosition();
        if(j == 0)
        {
            return null;
        } else
        {
            byte abyte0[] = parcel.createByteArray();
            int l = parcel.readInt();
            parcel.setDataPosition(k + j);
            return new BigDecimal(new BigInteger(abyte0), l);
        }
    }

    public static String zzq(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        int k = parcel.dataPosition();
        if(j == 0)
        {
            return null;
        } else
        {
            String s = parcel.readString();
            parcel.setDataPosition(k + j);
            return s;
        }
    }

    public static IBinder zzr(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        int k = parcel.dataPosition();
        if(j == 0)
        {
            return null;
        } else
        {
            IBinder ibinder = parcel.readStrongBinder();
            parcel.setDataPosition(k + j);
            return ibinder;
        }
    }

    public static Parcelable zza(Parcel parcel, int i, android.os.Parcelable.Creator creator)
    {
        int j = zza(parcel, i);
        int k = parcel.dataPosition();
        if(j == 0)
        {
            return null;
        } else
        {
            Parcelable parcelable = (Parcelable)creator.createFromParcel(parcel);
            parcel.setDataPosition(k + j);
            return parcelable;
        }
    }

    public static Bundle zzs(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        int k = parcel.dataPosition();
        if(j == 0)
        {
            return null;
        } else
        {
            Bundle bundle = parcel.readBundle();
            parcel.setDataPosition(k + j);
            return bundle;
        }
    }

    public static byte[] zzt(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        int k = parcel.dataPosition();
        if(j == 0)
        {
            return null;
        } else
        {
            byte abyte0[] = parcel.createByteArray();
            parcel.setDataPosition(k + j);
            return abyte0;
        }
    }

    public static byte[][] zzu(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        int k = parcel.dataPosition();
        if(j == 0)
            return null;
        int l = parcel.readInt();
        byte abyte0[][] = new byte[l][];
        for(int i1 = 0; i1 < l; i1++)
            abyte0[i1] = parcel.createByteArray();

        parcel.setDataPosition(k + j);
        return abyte0;
    }

    public static boolean[] zzv(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        int k = parcel.dataPosition();
        if(j == 0)
        {
            return null;
        } else
        {
            boolean aflag[] = parcel.createBooleanArray();
            parcel.setDataPosition(k + j);
            return aflag;
        }
    }

    public static int[] zzw(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        int k = parcel.dataPosition();
        if(j == 0)
        {
            return null;
        } else
        {
            int ai[] = parcel.createIntArray();
            parcel.setDataPosition(k + j);
            return ai;
        }
    }

    public static long[] zzx(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        int k = parcel.dataPosition();
        if(j == 0)
        {
            return null;
        } else
        {
            long al[] = parcel.createLongArray();
            parcel.setDataPosition(k + j);
            return al;
        }
    }

    public static BigInteger[] zzy(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        int k = parcel.dataPosition();
        if(j == 0)
            return null;
        int l = parcel.readInt();
        BigInteger abiginteger[] = new BigInteger[l];
        for(int i1 = 0; i1 < l; i1++)
            abiginteger[i1] = new BigInteger(parcel.createByteArray());

        parcel.setDataPosition(k + j);
        return abiginteger;
    }

    public static float[] zzz(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        int k = parcel.dataPosition();
        if(j == 0)
        {
            return null;
        } else
        {
            float af[] = parcel.createFloatArray();
            parcel.setDataPosition(k + j);
            return af;
        }
    }

    public static double[] zzaa(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        int k = parcel.dataPosition();
        if(j == 0)
        {
            return null;
        } else
        {
            double ad[] = parcel.createDoubleArray();
            parcel.setDataPosition(k + j);
            return ad;
        }
    }

    public static BigDecimal[] zzab(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        int k = parcel.dataPosition();
        if(j == 0)
            return null;
        int l = parcel.readInt();
        BigDecimal abigdecimal[] = new BigDecimal[l];
        for(int i1 = 0; i1 < l; i1++)
        {
            byte abyte0[] = parcel.createByteArray();
            int j1 = parcel.readInt();
            abigdecimal[i1] = new BigDecimal(new BigInteger(abyte0), j1);
        }

        parcel.setDataPosition(k + j);
        return abigdecimal;
    }

    public static String[] zzac(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        int k = parcel.dataPosition();
        if(j == 0)
        {
            return null;
        } else
        {
            String as[] = parcel.createStringArray();
            parcel.setDataPosition(k + j);
            return as;
        }
    }

    public static ArrayList zzad(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        int k = parcel.dataPosition();
        if(j == 0)
            return null;
        ArrayList arraylist = new ArrayList();
        int l = parcel.readInt();
        for(int i1 = 0; i1 < l; i1++)
            arraylist.add(Integer.valueOf(parcel.readInt()));

        parcel.setDataPosition(k + j);
        return arraylist;
    }

    public static ArrayList zzae(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        int k = parcel.dataPosition();
        if(j == 0)
        {
            return null;
        } else
        {
            ArrayList arraylist = parcel.createStringArrayList();
            parcel.setDataPosition(k + j);
            return arraylist;
        }
    }

    public static Object[] zzb(Parcel parcel, int i, android.os.Parcelable.Creator creator)
    {
        int j = zza(parcel, i);
        int k = parcel.dataPosition();
        if(j == 0)
        {
            return null;
        } else
        {
            Object aobj[] = parcel.createTypedArray(creator);
            parcel.setDataPosition(k + j);
            return aobj;
        }
    }

    public static ArrayList zzc(Parcel parcel, int i, android.os.Parcelable.Creator creator)
    {
        int j = zza(parcel, i);
        int k = parcel.dataPosition();
        if(j == 0)
        {
            return null;
        } else
        {
            ArrayList arraylist = parcel.createTypedArrayList(creator);
            parcel.setDataPosition(k + j);
            return arraylist;
        }
    }

    public static Parcel zzaf(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        int k = parcel.dataPosition();
        if(j == 0)
        {
            return null;
        } else
        {
            Parcel parcel1 = Parcel.obtain();
            parcel1.appendFrom(parcel, k, j);
            parcel.setDataPosition(k + j);
            return parcel1;
        }
    }

    public static Parcel[] zzag(Parcel parcel, int i)
    {
        int j = zza(parcel, i);
        int k = parcel.dataPosition();
        if(j == 0)
            return null;
        int l = parcel.readInt();
        Parcel aparcel[] = new Parcel[l];
        for(int i1 = 0; i1 < l; i1++)
        {
            int j1 = parcel.readInt();
            if(j1 != 0)
            {
                int k1 = parcel.dataPosition();
                Parcel parcel1 = Parcel.obtain();
                parcel1.appendFrom(parcel, k1, j1);
                aparcel[i1] = parcel1;
                parcel.setDataPosition(k1 + j1);
            } else
            {
                aparcel[i1] = null;
            }
        }

        parcel.setDataPosition(k + j);
        return aparcel;
    }

    public static void zza(Parcel parcel, int i, List list, ClassLoader classloader)
    {
        int j = zza(parcel, i);
        int k = parcel.dataPosition();
        if(j == 0)
        {
            return;
        } else
        {
            parcel.readList(list, classloader);
            parcel.setDataPosition(k + j);
            return;
        }
    }
}
