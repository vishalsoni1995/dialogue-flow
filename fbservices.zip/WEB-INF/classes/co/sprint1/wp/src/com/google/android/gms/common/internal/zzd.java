// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.app.PendingIntent;
import android.content.*;
import android.os.*;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.zzc;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

// Referenced classes of package com.google.android.gms.common.internal:
//            GetServiceRequest, zzab, zzm, zzq, 
//            zzu, zzt

public abstract class com.google.android.gms.common.internal.zzd
{
    public static final class zzg extends zzt.zza
    {

        public void zzb(int i, Bundle bundle)
        {
            Log.wtf("GmsClient", "received deprecated onAccountValidationComplete callback, ignoring", new Exception());
        }

        public void zza(int i, IBinder ibinder, Bundle bundle)
        {
            zzab.zzb(xx, "onPostInitComplete can be called only once per call to getRemoteService");
            xx.zza(i, ibinder, bundle, xy);
            zzasd();
        }

        private void zzasd()
        {
            xx = null;
        }

        private com.google.android.gms.common.internal.zzd xx;
        private final int xy;

        public zzg(com.google.android.gms.common.internal.zzd zzd1, int i)
        {
            xx = zzd1;
            xy = i;
        }
    }

    private abstract class zza extends zze
    {

        protected abstract boolean zzarz();

        protected abstract void zzl(ConnectionResult connectionresult);

        protected void zzc(Boolean boolean1)
        {
            if(boolean1 == null)
            {
                com.google.android.gms.common.internal.zzd.zza(xv, 1, null);
                return;
            }
            switch(statusCode)
            {
            case 0: // '\0'
                if(!zzarz())
                {
                    com.google.android.gms.common.internal.zzd.zza(xv, 1, null);
                    zzl(new ConnectionResult(8, null));
                }
                break;

            case 10: // '\n'
                com.google.android.gms.common.internal.zzd.zza(xv, 1, null);
                throw new IllegalStateException("A fatal developer error has occurred. Check the logs for further information.");

            default:
                com.google.android.gms.common.internal.zzd.zza(xv, 1, null);
                PendingIntent pendingintent = null;
                if(xu != null)
                    pendingintent = (PendingIntent)xu.getParcelable("pendingIntent");
                zzl(new ConnectionResult(statusCode, pendingintent));
                break;
            }
        }

        protected void zzasa()
        {
        }

        protected void zzx(Object obj)
        {
            zzc((Boolean)obj);
        }

        public final int statusCode;
        public final Bundle xu;
        final com.google.android.gms.common.internal.zzd xv;

        protected zza(int i, Bundle bundle)
        {
            xv = com.google.android.gms.common.internal.zzd.this;
            ((zze)this).zze(Boolean.valueOf(true));
            statusCode = i;
            xu = bundle;
        }
    }

    protected final class zzj extends zza
    {

        protected void zzl(ConnectionResult connectionresult)
        {
            if(com.google.android.gms.common.internal.zzd.zze(xv) != null)
                com.google.android.gms.common.internal.zzd.zze(xv).onConnectionFailed(connectionresult);
            xv.onConnectionFailed(connectionresult);
        }

        protected boolean zzarz()
        {
            String s;
            try
            {
                s = xz.getInterfaceDescriptor();
            }
            catch(RemoteException remoteexception)
            {
                Log.w("GmsClient", "service probably died");
                return false;
            }
            if(!xv.zzrb().equals(s))
            {
                String s1;
                Log.e("GmsClient", (new StringBuilder(34 + String.valueOf(s1 = String.valueOf(xv.zzrb())).length() + String.valueOf(s).length())).append("service descriptor mismatch: ").append(s1).append(" vs. ").append(s).toString());
                return false;
            }
            IInterface iinterface = xv.zzbb(xz);
            if(iinterface != null && com.google.android.gms.common.internal.zzd.zza(xv, 2, 3, iinterface))
            {
                Bundle bundle = xv.zzamc();
                if(com.google.android.gms.common.internal.zzd.zzc(xv) != null)
                    com.google.android.gms.common.internal.zzd.zzc(xv).onConnected(bundle);
                return true;
            } else
            {
                return false;
            }
        }

        public final IBinder xz;
        final com.google.android.gms.common.internal.zzd xv;

        public zzj(int i, IBinder ibinder, Bundle bundle)
        {
            xv = com.google.android.gms.common.internal.zzd.this;
            ((zza)this).zza(i, bundle);
            xz = ibinder;
        }
    }

    protected final class zzk extends zza
    {

        protected void zzl(ConnectionResult connectionresult)
        {
            com.google.android.gms.common.internal.zzd.zzb(xv).zzh(connectionresult);
            xv.onConnectionFailed(connectionresult);
        }

        protected boolean zzarz()
        {
            com.google.android.gms.common.internal.zzd.zzb(xv).zzh(ConnectionResult.qR);
            return true;
        }

        final com.google.android.gms.common.internal.zzd xv;

        public zzk(int i, Bundle bundle)
        {
            xv = com.google.android.gms.common.internal.zzd.this;
            ((zza)this).zza(i, bundle);
        }
    }

    protected class zzi
        implements zzf
    {

        public void zzh(ConnectionResult connectionresult)
        {
            if(connectionresult.isSuccess())
                xv.zza(null, xv.zzary());
            else
            if(com.google.android.gms.common.internal.zzd.zze(xv) != null)
                com.google.android.gms.common.internal.zzd.zze(xv).onConnectionFailed(connectionresult);
        }

        final com.google.android.gms.common.internal.zzd xv;

        public zzi()
        {
            xv = com.google.android.gms.common.internal.zzd.this;
            Object();
        }
    }

    protected abstract class zze
    {

        protected abstract void zzx(Object obj);

        protected abstract void zzasa();

        public void zzasb()
        {
            Object obj;
            synchronized(this)
            {
                obj = mListener;
                String s;
                if(xw)
                    Log.w("GmsClient", (new StringBuilder(47 + String.valueOf(s = String.valueOf(this)).length())).append("Callback proxy ").append(s).append(" being reused. This is not safe.").toString());
            }
            if(obj != null)
                try
                {
                    zzx(obj);
                }
                catch(RuntimeException runtimeexception)
                {
                    zzasa();
                    throw runtimeexception;
                }
            else
                zzasa();
            synchronized(this)
            {
                xw = true;
            }
            unregister();
        }

        public void unregister()
        {
            zzasc();
            synchronized(com.google.android.gms.common.internal.zzd.zzd(xv))
            {
                com.google.android.gms.common.internal.zzd.zzd(xv).remove(this);
            }
        }

        public void zzasc()
        {
            synchronized(this)
            {
                mListener = null;
            }
        }

        private Object mListener;
        private boolean xw;
        final com.google.android.gms.common.internal.zzd xv;

        public zze(Object obj)
        {
            xv = com.google.android.gms.common.internal.zzd.this;
            Object();
            mListener = obj;
            xw = false;
        }
    }

    final class zzd extends Handler
    {

        public void handleMessage(Message message)
        {
            if(xv.xs.get() != message.arg1)
            {
                if(zzb(message))
                    zza(message);
                return;
            }
            if((message.what == 1 || message.what == 5) && !xv.isConnecting())
            {
                zza(message);
                return;
            }
            if(message.what == 3)
            {
                PendingIntent pendingintent = (message.obj instanceof PendingIntent) ? (PendingIntent)message.obj : null;
                ConnectionResult connectionresult = new ConnectionResult(message.arg2, pendingintent);
                com.google.android.gms.common.internal.zzd.zzb(xv).zzh(connectionresult);
                xv.onConnectionFailed(connectionresult);
                return;
            }
            if(message.what == 4)
            {
                com.google.android.gms.common.internal.zzd.zza(xv, 4, null);
                if(com.google.android.gms.common.internal.zzd.zzc(xv) != null)
                    com.google.android.gms.common.internal.zzd.zzc(xv).onConnectionSuspended(message.arg2);
                xv.onConnectionSuspended(message.arg2);
                com.google.android.gms.common.internal.zzd.zza(xv, 4, 1, null);
                return;
            }
            if(message.what == 2 && !xv.isConnected())
            {
                zza(message);
                return;
            }
            if(zzb(message))
            {
                zze zze1 = (zze)message.obj;
                zze1.zzasb();
                return;
            } else
            {
                int i;
                Log.wtf("GmsClient", (new StringBuilder(45)).append("Don't know how to handle message: ").append(i = message.what).toString(), new Exception());
                return;
            }
        }

        private void zza(Message message)
        {
            zze zze1 = (zze)message.obj;
            zze1.zzasa();
            zze1.unregister();
        }

        private boolean zzb(Message message)
        {
            return message.what == 2 || message.what == 1 || message.what == 5;
        }

        final com.google.android.gms.common.internal.zzd xv;

        public zzd(Looper looper)
        {
            xv = com.google.android.gms.common.internal.zzd.this;
            Handler(looper);
        }
    }

    public static interface zzf
    {

        public abstract void zzh(ConnectionResult connectionresult);
    }

    public static interface zzc
    {

        public abstract void onConnectionFailed(ConnectionResult connectionresult);
    }

    public static interface zzb
    {

        public abstract void onConnected(Bundle bundle);

        public abstract void onConnectionSuspended(int i);
    }

    public final class zzh
        implements ServiceConnection
    {

        public void onServiceConnected(ComponentName componentname, IBinder ibinder)
        {
            zzab.zzb(ibinder, "Expecting a valid IBinder");
            synchronized(com.google.android.gms.common.internal.zzd.zza(xv))
            {
                com.google.android.gms.common.internal.zzd.zza(xv, zzu.zza.zzdt(ibinder));
            }
            xv.zza(0, null, xy);
        }

        public void onServiceDisconnected(ComponentName componentname)
        {
            synchronized(com.google.android.gms.common.internal.zzd.zza(xv))
            {
                com.google.android.gms.common.internal.zzd.zza(xv, null);
            }
            xv.mHandler.sendMessage(xv.mHandler.obtainMessage(4, xy, 1));
        }

        private final int xy;
        final com.google.android.gms.common.internal.zzd xv;

        public zzh(int i)
        {
            xv = com.google.android.gms.common.internal.zzd.this;
            Object();
            xy = i;
        }
    }


    protected com.google.android.gms.common.internal.zzd(Context context, Looper looper, int i, zzb zzb1, zzc zzc1, String s)
    {
        zzd(context, looper, zzm.zzce(context), com.google.android.gms.common.zzc.zzand(), i, (zzb)zzab.zzaa(zzb1), (zzc)zzab.zzaa(zzc1), s);
    }

    protected com.google.android.gms.common.internal.zzd(Context context, Looper looper, zzm zzm1, com.google.android.gms.common.zzc zzc1, int i, zzb zzb1, zzc zzc2, 
            String s)
    {
        zzail = new Object();
        xh = new Object();
        xl = new ArrayList();
        xn = 1;
        xs = new AtomicInteger(0);
        mContext = (Context)zzab.zzb(context, "Context must not be null");
        zzahv = (Looper)zzab.zzb(looper, "Looper must not be null");
        xg = (zzm)zzab.zzb(zzm1, "Supervisor must not be null");
        tp = (com.google.android.gms.common.zzc)zzab.zzb(zzc1, "API availability must not be null");
        mHandler = new zzd(looper);
        xq = i;
        xo = zzb1;
        xp = zzc2;
        xr = s;
    }

    protected abstract String zzra();

    protected String zzarp()
    {
        return "com.google.android.gms";
    }

    protected abstract String zzrb();

    protected final String zzarq()
    {
        return xr != null ? xr : mContext.getClass().getName();
    }

    protected abstract IInterface zzbb(IBinder ibinder);

    protected void zza(IInterface iinterface)
    {
        xd = System.currentTimeMillis();
    }

    protected void onConnectionSuspended(int i)
    {
        xb = i;
        xc = System.currentTimeMillis();
    }

    protected void onConnectionFailed(ConnectionResult connectionresult)
    {
        xe = connectionresult.getErrorCode();
        xf = System.currentTimeMillis();
    }

    private void zzb(int i, IInterface iinterface)
    {
        zzab.zzbn((i == 3) == (iinterface != null));
        synchronized(zzail)
        {
            xn = i;
            xk = iinterface;
            zzc(i, iinterface);
            switch(i)
            {
            case 2: // '\002'
                zzarr();
                break;

            case 3: // '\003'
                zza(iinterface);
                break;

            case 1: // '\001'
                zzars();
                break;
            }
        }
    }

    void zzc(int i, IInterface iinterface)
    {
    }

    private void zzarr()
    {
        if(xm != null)
        {
            String s;
            String s1;
            Log.e("GmsClient", (new StringBuilder(70 + String.valueOf(s = String.valueOf(zzra())).length() + String.valueOf(s1 = String.valueOf(zzarp())).length())).append("Calling connect() while still connected, missing disconnect() for ").append(s).append(" on ").append(s1).toString());
            xg.zzb(zzra(), zzarp(), xm, zzarq());
            xs.incrementAndGet();
        }
        xm = new zzh(xs.get());
        boolean flag = xg.zza(zzra(), zzarp(), xm, zzarq());
        if(!flag)
        {
            String s2;
            String s3;
            Log.e("GmsClient", (new StringBuilder(34 + String.valueOf(s2 = String.valueOf(zzra())).length() + String.valueOf(s3 = String.valueOf(zzarp())).length())).append("unable to connect to service: ").append(s2).append(" on ").append(s3).toString());
            zza(16, ((Bundle) (null)), xs.get());
        }
    }

    private void zzars()
    {
        if(xm != null)
        {
            xg.zzb(zzra(), zzarp(), xm, zzarq());
            xm = null;
        }
    }

    private boolean zza(int i, int j, IInterface iinterface)
    {
        Object obj = zzail;
        JVM INSTR monitorenter ;
        if(xn != i)
            return false;
        zzb(j, iinterface);
        true;
        obj;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void zzart()
    {
        int i = tp.isGooglePlayServicesAvailable(mContext);
        if(i != 0)
        {
            zzb(1, null);
            xj = new zzi();
            mHandler.sendMessage(mHandler.obtainMessage(3, xs.get(), i));
            return;
        } else
        {
            zza(new zzi());
            return;
        }
    }

    public void zza(zzf zzf1)
    {
        xj = (zzf)zzab.zzb(zzf1, "Connection progress callbacks cannot be null.");
        zzb(2, null);
    }

    public boolean isConnected()
    {
        Object obj = zzail;
        JVM INSTR monitorenter ;
        return xn == 3;
        Exception exception;
        exception;
        throw exception;
    }

    public boolean isConnecting()
    {
        Object obj = zzail;
        JVM INSTR monitorenter ;
        return xn == 2;
        Exception exception;
        exception;
        throw exception;
    }

    public void disconnect()
    {
        xs.incrementAndGet();
        synchronized(xl)
        {
            int i = xl.size();
            for(int j = 0; j < i; j++)
                ((zze)xl.get(j)).zzasc();

            xl.clear();
        }
        synchronized(xh)
        {
            xi = null;
        }
        zzb(1, null);
    }

    public void zzfy(int i)
    {
        mHandler.sendMessage(mHandler.obtainMessage(4, xs.get(), i));
    }

    public void zza(zzf zzf1, ConnectionResult connectionresult)
    {
        xj = (zzf)zzab.zzb(zzf1, "Connection progress callbacks cannot be null.");
        mHandler.sendMessage(mHandler.obtainMessage(3, xs.get(), connectionresult.getErrorCode(), connectionresult.getResolution()));
    }

    public final Context getContext()
    {
        return mContext;
    }

    public final Looper getLooper()
    {
        return zzahv;
    }

    public Account getAccount()
    {
        return null;
    }

    public final Account zzaru()
    {
        return getAccount() == null ? new Account("<<default account>>", "com.google") : getAccount();
    }

    protected Bundle zzaeu()
    {
        return new Bundle();
    }

    protected void zza(int i, IBinder ibinder, Bundle bundle, int j)
    {
        mHandler.sendMessage(mHandler.obtainMessage(1, j, -1, new zzj(i, ibinder, bundle)));
    }

    protected void zza(int i, Bundle bundle, int j)
    {
        mHandler.sendMessage(mHandler.obtainMessage(5, j, -1, new zzk(i, bundle)));
    }

    protected final void zzarv()
    {
        if(!isConnected())
            throw new IllegalStateException("Not connected. Call connect() and wait for onConnected() to be called.");
        else
            return;
    }

    public Bundle zzamc()
    {
        return null;
    }

    public final IInterface zzarw()
        throws DeadObjectException
    {
        Object obj = zzail;
        JVM INSTR monitorenter ;
        if(xn == 4)
            throw new DeadObjectException();
        zzarv();
        zzab.zza(xk != null, "Client is connected but service is null");
        return xk;
        Exception exception;
        exception;
        throw exception;
    }

    public void zza(zzq zzq1, Set set)
    {
        try
        {
            Bundle bundle = zzaeu();
            GetServiceRequest getservicerequest = (new GetServiceRequest(xq)).zzhm(mContext.getPackageName()).zzn(bundle);
            if(set != null)
                getservicerequest.zzf(set);
            if(zzafk())
                getservicerequest.zzd(zzaru()).zzb(zzq1);
            else
            if(zzarx())
                getservicerequest.zzd(getAccount());
            synchronized(xh)
            {
                if(xi != null)
                    xi.zza(new zzg(this, xs.get()), getservicerequest);
                else
                    Log.w("GmsClient", "mServiceBroker is null, client disconnected");
            }
        }
        catch(DeadObjectException deadobjectexception)
        {
            Log.w("GmsClient", "service died");
            zzfy(1);
        }
        catch(RemoteException remoteexception)
        {
            Log.w("GmsClient", "Remote exception occurred", remoteexception);
        }
    }

    public boolean zzafk()
    {
        return false;
    }

    public boolean zzarx()
    {
        return false;
    }

    public boolean zzanr()
    {
        return true;
    }

    public boolean zzafz()
    {
        return false;
    }

    public Intent zzaga()
    {
        throw new UnsupportedOperationException("Not a sign in API");
    }

    protected Set zzary()
    {
        return Collections.EMPTY_SET;
    }

    public void dump(String s, FileDescriptor filedescriptor, PrintWriter printwriter, String as[])
    {
        int i;
        IInterface iinterface;
        synchronized(zzail)
        {
            i = xn;
            iinterface = xk;
        }
        printwriter.append(s).append("mConnectState=");
        switch(i)
        {
        case 2: // '\002'
            printwriter.print("CONNECTING");
            break;

        case 3: // '\003'
            printwriter.print("CONNECTED");
            break;

        case 4: // '\004'
            printwriter.print("DISCONNECTING");
            break;

        case 1: // '\001'
            printwriter.print("DISCONNECTED");
            break;

        default:
            printwriter.print("UNKNOWN");
            break;
        }
        printwriter.append(" mService=");
        if(iinterface == null)
            printwriter.println("null");
        else
            printwriter.append(zzrb()).append("@").println(Integer.toHexString(System.identityHashCode(iinterface.asBinder())));
        SimpleDateFormat simpledateformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US);
        long l;
        String s1;
        if(xd > 0L)
            printwriter.append(s).append("lastConnectedTime=").println((new StringBuilder(21 + String.valueOf(s1 = String.valueOf(simpledateformat.format(new Date(xd)))).length())).append(l = xd).append(" ").append(s1).toString());
        if(xc > 0L)
        {
            printwriter.append(s).append("lastSuspendedCause=");
            switch(xb)
            {
            case 1: // '\001'
                printwriter.append("CAUSE_SERVICE_DISCONNECTED");
                break;

            case 2: // '\002'
                printwriter.append("CAUSE_NETWORK_LOST");
                break;

            default:
                printwriter.append(String.valueOf(xb));
                break;
            }
            long l1;
            String s2;
            printwriter.append(" lastSuspendedTime=").println((new StringBuilder(21 + String.valueOf(s2 = String.valueOf(simpledateformat.format(new Date(xc)))).length())).append(l1 = xc).append(" ").append(s2).toString());
        }
        if(xf > 0L)
        {
            printwriter.append(s).append("lastFailedStatus=").append(CommonStatusCodes.getStatusCodeString(xe));
            long l2;
            String s3;
            printwriter.append(" lastFailedTime=").println((new StringBuilder(21 + String.valueOf(s3 = String.valueOf(simpledateformat.format(new Date(xf)))).length())).append(l2 = xf).append(" ").append(s3).toString());
        }
    }

    public IBinder zzans()
    {
        Object obj = xh;
        JVM INSTR monitorenter ;
        if(xi == null)
            return null;
        xi.asBinder();
        obj;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    static Object zza(com.google.android.gms.common.internal.zzd zzd1)
    {
        return zzd1.xh;
    }

    static zzu zza(com.google.android.gms.common.internal.zzd zzd1, zzu zzu1)
    {
        return zzd1.xi = zzu1;
    }

    static zzf zzb(com.google.android.gms.common.internal.zzd zzd1)
    {
        return zzd1.xj;
    }

    static void zza(com.google.android.gms.common.internal.zzd zzd1, int i, IInterface iinterface)
    {
        zzd1.zzb(i, iinterface);
    }

    static zzb zzc(com.google.android.gms.common.internal.zzd zzd1)
    {
        return zzd1.xo;
    }

    static boolean zza(com.google.android.gms.common.internal.zzd zzd1, int i, int j, IInterface iinterface)
    {
        return zzd1.zza(i, j, iinterface);
    }

    static ArrayList zzd(com.google.android.gms.common.internal.zzd zzd1)
    {
        return zzd1.xl;
    }

    static zzc zze(com.google.android.gms.common.internal.zzd zzd1)
    {
        return zzd1.xp;
    }

    private int xb;
    private long xc;
    private long xd;
    private int xe;
    private long xf;
    private final Context mContext;
    private final Looper zzahv;
    private final zzm xg;
    private final com.google.android.gms.common.zzc tp;
    final Handler mHandler;
    private final Object zzail;
    private final Object xh;
    private zzu xi;
    private zzf xj;
    private IInterface xk;
    private final ArrayList xl;
    private zzh xm;
    private int xn;
    private final zzb xo;
    private final zzc xp;
    private final int xq;
    private final String xr;
    protected AtomicInteger xs;
    public static final String xt[] = {
        "service_esmobile", "service_googleme"
    };

}
