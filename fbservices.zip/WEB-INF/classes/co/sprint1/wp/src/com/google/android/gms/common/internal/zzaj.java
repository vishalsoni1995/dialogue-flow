// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.internal;

import android.os.*;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

// Referenced classes of package com.google.android.gms.common.internal:
//            ValidateAccountRequest

public class zzaj
    implements android.os.Parcelable.Creator
{

    public zzaj()
    {
    }

    public ValidateAccountRequest zzcj(Parcel parcel)
    {
        int i = com.google.android.gms.common.internal.safeparcel.zza.zzcl(parcel);
        int j = 0;
        int k = 0;
        IBinder ibinder = null;
        Scope ascope[] = null;
        Bundle bundle = null;
        String s = null;
        do
        {
            if(parcel.dataPosition() >= i)
                break;
            int l = com.google.android.gms.common.internal.safeparcel.zza.zzck(parcel);
            switch(com.google.android.gms.common.internal.safeparcel.zza.zzgi(l))
            {
            case 1: // '\001'
                j = com.google.android.gms.common.internal.safeparcel.zza.zzg(parcel, l);
                break;

            case 2: // '\002'
                k = com.google.android.gms.common.internal.safeparcel.zza.zzg(parcel, l);
                break;

            case 3: // '\003'
                ibinder = com.google.android.gms.common.internal.safeparcel.zza.zzr(parcel, l);
                break;

            case 4: // '\004'
                ascope = (Scope[])com.google.android.gms.common.internal.safeparcel.zza.zzb(parcel, l, Scope.CREATOR);
                break;

            case 5: // '\005'
                bundle = com.google.android.gms.common.internal.safeparcel.zza.zzs(parcel, l);
                break;

            case 6: // '\006'
                s = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, l);
                break;

            default:
                com.google.android.gms.common.internal.safeparcel.zza.zzb(parcel, l);
                break;
            }
        } while(true);
        if(parcel.dataPosition() != i)
        {
            throw new zza((new StringBuilder(37)).append("Overread allowed size end=").append(i).toString(), parcel);
        } else
        {
            ValidateAccountRequest validateaccountrequest = new ValidateAccountRequest(j, k, ibinder, ascope, bundle, s);
            return validateaccountrequest;
        }
    }

    public ValidateAccountRequest[] zzgh(int i)
    {
        return new ValidateAccountRequest[i];
    }

    static void zza(ValidateAccountRequest validateaccountrequest, Parcel parcel, int i)
    {
        int j = zzb.zzcm(parcel);
        zzb.zzc(parcel, 1, validateaccountrequest.mVersionCode);
        zzb.zzc(parcel, 2, validateaccountrequest.zzatk());
        zzb.zza(parcel, 3, validateaccountrequest.wY, false);
        zzb.zza(parcel, 4, validateaccountrequest.zzati(), i, false);
        zzb.zza(parcel, 5, validateaccountrequest.zzatl(), false);
        zzb.zza(parcel, 6, validateaccountrequest.getCallingPackage(), false);
        zzb.zzaj(parcel, j);
    }

    public Object[] newArray(int i)
    {
        return zzgh(i);
    }

    public Object createFromParcel(Parcel parcel)
    {
        return zzcj(parcel);
    }
}
