// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.*;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.zzc;
import java.util.Collection;

// Referenced classes of package com.google.android.gms.common.internal:
//            zza, zzj, zzq

public class GetServiceRequest extends AbstractSafeParcelable
{

    public GetServiceRequest(int i)
    {
        version = 3;
        yj = zzc.GOOGLE_PLAY_SERVICES_VERSION_CODE;
        yi = i;
    }

    GetServiceRequest(int i, int j, int k, String s, IBinder ibinder, Scope ascope[], Bundle bundle, 
            Account account, long l)
    {
        version = i;
        yi = j;
        yj = k;
        yk = s;
        if(i < 2)
        {
            yo = zzdo(ibinder);
        } else
        {
            yl = ibinder;
            yo = account;
        }
        ym = ascope;
        yn = bundle;
        yp = l;
    }

    public GetServiceRequest zzhm(String s)
    {
        yk = s;
        return this;
    }

    public GetServiceRequest zzd(Account account)
    {
        yo = account;
        return this;
    }

    public GetServiceRequest zzb(zzq zzq1)
    {
        if(zzq1 != null)
            yl = zzq1.asBinder();
        return this;
    }

    public GetServiceRequest zzf(Collection collection)
    {
        ym = (Scope[])collection.toArray(new Scope[collection.size()]);
        return this;
    }

    public GetServiceRequest zzn(Bundle bundle)
    {
        yn = bundle;
        return this;
    }

    public void writeToParcel(Parcel parcel, int i)
    {
        zzj.zza(this, parcel, i);
    }

    private Account zzdo(IBinder ibinder)
    {
        Account account = null;
        if(ibinder != null)
            account = com.google.android.gms.common.internal.zza.zza(zzq.zza.zzdp(ibinder));
        return account;
    }

    public static final android.os.Parcelable.Creator CREATOR = new zzj();
    final int version;
    final int yi;
    int yj;
    String yk;
    IBinder yl;
    Scope ym[];
    Bundle yn;
    Account yo;
    long yp;

}
