// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.internal;

import android.os.Looper;
import android.util.Log;

public final class zzb
{

    public static void zzw(Object obj)
    {
        if(obj == null)
            throw new IllegalArgumentException("null reference");
        else
            return;
    }

    public static void zzbm(boolean flag)
    {
        if(!flag)
            throw new IllegalStateException();
        else
            return;
    }

    public static void zza(boolean flag, Object obj)
    {
        if(!flag)
            throw new IllegalStateException(String.valueOf(obj));
        else
            return;
    }

    public static void zzhj(String s)
    {
        if(Looper.getMainLooper().getThread() != Thread.currentThread())
        {
            String s1;
            String s2;
            Log.e("Asserts", (new StringBuilder(57 + String.valueOf(s1 = String.valueOf(Thread.currentThread())).length() + String.valueOf(s2 = String.valueOf(Looper.getMainLooper().getThread())).length())).append("checkMainThread: current thread ").append(s1).append(" IS NOT the main thread ").append(s2).append("!").toString());
            throw new IllegalStateException(s);
        } else
        {
            return;
        }
    }

    public static void zzhk(String s)
    {
        if(Looper.getMainLooper().getThread() == Thread.currentThread())
        {
            String s1;
            String s2;
            Log.e("Asserts", (new StringBuilder(56 + String.valueOf(s1 = String.valueOf(Thread.currentThread())).length() + String.valueOf(s2 = String.valueOf(Looper.getMainLooper().getThread())).length())).append("checkNotMainThread: current thread ").append(s1).append(" IS the main thread ").append(s2).append("!").toString());
            throw new IllegalStateException(s);
        } else
        {
            return;
        }
    }
}
