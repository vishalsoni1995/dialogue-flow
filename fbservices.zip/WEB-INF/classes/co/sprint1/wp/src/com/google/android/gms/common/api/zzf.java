// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.api;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzb;

// Referenced classes of package com.google.android.gms.common.api:
//            Status

public class zzf
    implements android.os.Parcelable.Creator
{

    public zzf()
    {
    }

    public Status zzbz(Parcel parcel)
    {
        int i = com.google.android.gms.common.internal.safeparcel.zza.zzcl(parcel);
        int j = 0;
        int k = 0;
        String s = null;
        PendingIntent pendingintent = null;
        do
        {
            if(parcel.dataPosition() >= i)
                break;
            int l = com.google.android.gms.common.internal.safeparcel.zza.zzck(parcel);
            switch(com.google.android.gms.common.internal.safeparcel.zza.zzgi(l))
            {
            case 1: // '\001'
                k = com.google.android.gms.common.internal.safeparcel.zza.zzg(parcel, l);
                break;

            case 2: // '\002'
                s = com.google.android.gms.common.internal.safeparcel.zza.zzq(parcel, l);
                break;

            case 3: // '\003'
                pendingintent = (PendingIntent)com.google.android.gms.common.internal.safeparcel.zza.zza(parcel, l, PendingIntent.CREATOR);
                break;

            case 1000: 
                j = com.google.android.gms.common.internal.safeparcel.zza.zzg(parcel, l);
                break;

            default:
                com.google.android.gms.common.internal.safeparcel.zza.zzb(parcel, l);
                break;
            }
        } while(true);
        if(parcel.dataPosition() != i)
        {
            throw new zza((new StringBuilder(37)).append("Overread allowed size end=").append(i).toString(), parcel);
        } else
        {
            Status status = new Status(j, k, s, pendingintent);
            return status;
        }
    }

    public Status[] zzfe(int i)
    {
        return new Status[i];
    }

    static void zza(Status status, Parcel parcel, int i)
    {
        int j = zzb.zzcm(parcel);
        zzb.zzc(parcel, 1, status.getStatusCode());
        zzb.zza(parcel, 2, status.getStatusMessage(), false);
        zzb.zza(parcel, 3, status.zzaoi(), i, false);
        zzb.zzc(parcel, 1000, status.getVersionCode());
        zzb.zzaj(parcel, j);
    }

    public Object[] newArray(int i)
    {
        return zzfe(i);
    }

    public Object createFromParcel(Parcel parcel)
    {
        return zzbz(parcel);
    }
}
