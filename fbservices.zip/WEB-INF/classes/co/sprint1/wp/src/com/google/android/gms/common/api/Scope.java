// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.api;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.zzab;

// Referenced classes of package com.google.android.gms.common.api:
//            zze

public final class Scope extends AbstractSafeParcelable
{

    Scope(int i, String s)
    {
        zzab.zzh(s, "scopeUri must not be null or empty");
        mVersionCode = i;
        sf = s;
    }

    public Scope(String s)
    {
        Scope(1, s);
    }

    public String zzaoh()
    {
        return sf;
    }

    public boolean equals(Object obj)
    {
        if(this == obj)
            return true;
        if(!(obj instanceof Scope))
            return false;
        else
            return sf.equals(((Scope)obj).sf);
    }

    public int hashCode()
    {
        return sf.hashCode();
    }

    public String toString()
    {
        return sf;
    }

    public void writeToParcel(Parcel parcel, int i)
    {
        zze.zza(this, parcel, i);
    }

    public static final android.os.Parcelable.Creator CREATOR = new zze();
    final int mVersionCode;
    private final String sf;

}
