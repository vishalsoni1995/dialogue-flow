// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.api;

import android.util.Log;

// Referenced classes of package com.google.android.gms.common.api:
//            Releasable, Result, ResultCallback, Status

public abstract class ResultCallbacks
    implements ResultCallback
{

    public ResultCallbacks()
    {
    }

    public final void onResult(Result result)
    {
        Status status = result.getStatus();
        if(status.isSuccess())
        {
            onSuccess(result);
        } else
        {
            onFailure(status);
            String s;
            if(result instanceof Releasable)
                try
                {
                    ((Releasable)result).release();
                }
                catch(RuntimeException runtimeexception)
                {
                    Log.w("ResultCallbacks", (new StringBuilder(18 + String.valueOf(s = String.valueOf(result)).length())).append("Unable to release ").append(s).toString(), runtimeexception);
                }
        }
    }

    public abstract void onSuccess(Result result);

    public abstract void onFailure(Status status);
}
