// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.internal;

import android.os.*;

public final class BinderWrapper
    implements Parcelable
{

    public BinderWrapper()
    {
        xA = null;
    }

    public BinderWrapper(IBinder ibinder)
    {
        xA = null;
        xA = ibinder;
    }

    private BinderWrapper(Parcel parcel)
    {
        xA = null;
        xA = parcel.readStrongBinder();
    }

    public int describeContents()
    {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i)
    {
        parcel.writeStrongBinder(xA);
    }


    private IBinder xA;
    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {

        public BinderWrapper zzce(Parcel parcel)
        {
            return new BinderWrapper(parcel);
        }

        public BinderWrapper[] zzfz(int i)
        {
            return new BinderWrapper[i];
        }

        public Object[] newArray(int i)
        {
            return zzfz(i);
        }

        public Object createFromParcel(Parcel parcel)
        {
            return zzce(parcel);
        }

    }
;

}
