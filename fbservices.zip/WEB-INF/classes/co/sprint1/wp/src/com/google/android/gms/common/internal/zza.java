// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Binder;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.zze;

// Referenced classes of package com.google.android.gms.common.internal:
//            zzq

public class zza extends zzq.zza
{

    public static Account zza(zzq zzq1)
    {
        Account account;
        long l;
        account = null;
        if(zzq1 == null)
            break MISSING_BLOCK_LABEL_50;
        l = Binder.clearCallingIdentity();
        account = zzq1.getAccount();
        Binder.restoreCallingIdentity(l);
        break MISSING_BLOCK_LABEL_50;
        RemoteException remoteexception;
        remoteexception;
        Log.w("AccountAccessor", "Remote account accessor probably died");
        Binder.restoreCallingIdentity(l);
        break MISSING_BLOCK_LABEL_50;
        Exception exception;
        exception;
        Binder.restoreCallingIdentity(l);
        throw exception;
        return account;
    }

    public Account getAccount()
    {
        int i = Binder.getCallingUid();
        if(i == wX)
        {
            zza _tmp = this;
            return null;
        }
        zza _tmp1 = this;
        if(zze.zze(null, i))
        {
            wX = i;
            zza _tmp2 = this;
            return null;
        } else
        {
            throw new SecurityException("Caller is not GooglePlayServices");
        }
    }

    public boolean equals(Object obj)
    {
        if(this == obj)
            return true;
        if(!(obj instanceof zza))
        {
            return false;
        } else
        {
            zza _tmp = this;
            return null.equals(null);
        }
    }

    int wX;
}
