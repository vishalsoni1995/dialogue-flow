// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.api;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.IntentSender;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.internal.zzaa;

// Referenced classes of package com.google.android.gms.common.api:
//            CommonStatusCodes, Result, zzf

public final class Status extends AbstractSafeParcelable
    implements Result
{

    Status(int i, int j, String s, PendingIntent pendingintent)
    {
        mVersionCode = i;
        ob = j;
        qS = s;
        mPendingIntent = pendingintent;
    }

    public Status(int i)
    {
        Status(i, null);
    }

    public Status(int i, String s)
    {
        Status(1, i, s, null);
    }

    public Status(int i, String s, PendingIntent pendingintent)
    {
        Status(1, i, s, pendingintent);
    }

    public void startResolutionForResult(Activity activity, int i)
        throws android.content.IntentSender.SendIntentException
    {
        if(!hasResolution())
        {
            return;
        } else
        {
            activity.startIntentSenderForResult(mPendingIntent.getIntentSender(), i, null, 0, 0, 0);
            return;
        }
    }

    PendingIntent zzaoi()
    {
        return mPendingIntent;
    }

    public String getStatusMessage()
    {
        return qS;
    }

    int getVersionCode()
    {
        return mVersionCode;
    }

    public boolean hasResolution()
    {
        return mPendingIntent != null;
    }

    public boolean isSuccess()
    {
        return ob <= 0;
    }

    public boolean isCanceled()
    {
        return ob == 16;
    }

    public boolean isInterrupted()
    {
        return ob == 14;
    }

    public int getStatusCode()
    {
        return ob;
    }

    public PendingIntent getResolution()
    {
        return mPendingIntent;
    }

    public int hashCode()
    {
        return zzaa.hashCode(new Object[] {
            Integer.valueOf(mVersionCode), Integer.valueOf(ob), qS, mPendingIntent
        });
    }

    public boolean equals(Object obj)
    {
        if(!(obj instanceof Status))
        {
            return false;
        } else
        {
            Status status = (Status)obj;
            return mVersionCode == status.mVersionCode && ob == status.ob && zzaa.equal(qS, status.qS) && zzaa.equal(mPendingIntent, status.mPendingIntent);
        }
    }

    private String zzaoj()
    {
        if(qS != null)
            return qS;
        else
            return CommonStatusCodes.getStatusCodeString(ob);
    }

    public String toString()
    {
        return zzaa.zzz(this).zzg("statusCode", zzaoj()).zzg("resolution", mPendingIntent).toString();
    }

    public void writeToParcel(Parcel parcel, int i)
    {
        zzf.zza(this, parcel, i);
    }

    public Status getStatus()
    {
        return this;
    }

    public static final Status sg = new Status(0);
    public static final Status sh = new Status(14);
    public static final Status si = new Status(8);
    public static final Status sj = new Status(15);
    public static final Status sk = new Status(16);
    public static final Status sl = new Status(17);
    public static final Status sm = new Status(18);
    public static final android.os.Parcelable.Creator CREATOR = new zzf();
    private final int mVersionCode;
    private final int ob;
    private final String qS;
    private final PendingIntent mPendingIntent;

}
