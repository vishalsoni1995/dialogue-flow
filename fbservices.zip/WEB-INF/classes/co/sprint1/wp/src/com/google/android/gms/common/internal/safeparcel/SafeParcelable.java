// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.internal.safeparcel;

import android.os.Parcelable;

public interface SafeParcelable
    extends Parcelable
{

    public static final String NULL = "SAFE_PARCELABLE_NULL_STRING";
}
