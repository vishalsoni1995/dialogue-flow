// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.internal;

import java.util.*;

// Referenced classes of package com.google.android.gms.common.internal:
//            zzab

public abstract class zzf
{
    private static class zza extends zzf
    {

        public boolean zzd(char c)
        {
            for(Iterator iterator = xX.iterator(); iterator.hasNext();)
            {
                zzf zzf1 = (zzf)iterator.next();
                if(zzf1.zzd(c))
                    return true;
            }

            return false;
        }

        public zzf zza(zzf zzf1)
        {
            ArrayList arraylist = new ArrayList(xX);
            arraylist.add((zzf)zzab.zzaa(zzf1));
            return new zza(arraylist);
        }

        List xX;

        zza(List list)
        {
            xX = list;
        }
    }


    public zzf()
    {
    }

    public static zzf zzc(char c)
    {
        return new zzf(c) {

            public boolean zzd(char c1)
            {
                return c1 == xW;
            }

            public zzf zza(zzf zzf1)
            {
                return zzf1.zzd(xW) ? zzf1 : zza(zzf1);
            }

            final char xW;

            
            {
                xW = c;
                zzf();
            }
        }
;
    }

    public static zzf zza(CharSequence charsequence)
    {
        switch(charsequence.length())
        {
        case 0: // '\0'
            return xQ;

        case 1: // '\001'
            return zzc(charsequence.charAt(0));

        case 2: // '\002'
            char c = charsequence.charAt(0);
            char c1 = charsequence.charAt(1);
            return new zzf(c, c1) {

                public boolean zzd(char c2)
                {
                    return c2 == xR || c2 == xS;
                }

                final char xR;
                final char xS;

            
            {
                xR = c;
                xS = c1;
                zzf();
            }
            }
;
        }
        char ac[] = charsequence.toString().toCharArray();
        Arrays.sort(ac);
        return new zzf(ac) {

            public boolean zzd(char c2)
            {
                return Arrays.binarySearch(xT, c2) >= 0;
            }

            final char xT[];

            
            {
                xT = ac;
                zzf();
            }
        }
;
    }

    public static zzf zza(char c, char c1)
    {
        zzab.zzbn(c1 >= c);
        return new zzf(c, c1) {

            public boolean zzd(char c2)
            {
                return xU <= c2 && c2 <= xV;
            }

            final char xU;
            final char xV;

            
            {
                xU = c;
                xV = c1;
                zzf();
            }
        }
;
    }

    public abstract boolean zzd(char c);

    public zzf zza(zzf zzf1)
    {
        return new zza(Arrays.asList(new zzf[] {
            this, (zzf)zzab.zzaa(zzf1)
        }));
    }

    public boolean zzb(CharSequence charsequence)
    {
        for(int i = charsequence.length() - 1; i >= 0; i--)
            if(!zzd(charsequence.charAt(i)))
                return false;

        return true;
    }

    public static final zzf xC = zza("\t\n\013\f\r \205\u1680\u2028\u2029\u205F\u3000\240\u180E\u202F").zza(zza('\u2000', '\u200A'));
    public static final zzf xD = zza("\t\n\013\f\r \205\u1680\u2028\u2029\u205F\u3000").zza(zza('\u2000', '\u2006')).zza(zza('\u2008', '\u200A'));
    public static final zzf xE = zza('\0', '\177');
    public static final zzf xF;
    public static final zzf xG = zza('\t', '\r').zza(zza('\034', ' ')).zza(zzc('\u1680')).zza(zzc('\u180E')).zza(zza('\u2000', '\u2006')).zza(zza('\u2008', '\u200B')).zza(zza('\u2028', '\u2029')).zza(zzc('\u205F')).zza(zzc('\u3000'));
    public static final zzf xH = new zzf() {

        public boolean zzd(char c1)
        {
            return Character.isDigit(c1);
        }

    }
;
    public static final zzf xI = new zzf() {

        public boolean zzd(char c1)
        {
            return Character.isLetter(c1);
        }

    }
;
    public static final zzf xJ = new zzf() {

        public boolean zzd(char c1)
        {
            return Character.isLetterOrDigit(c1);
        }

    }
;
    public static final zzf xK = new zzf() {

        public boolean zzd(char c1)
        {
            return Character.isUpperCase(c1);
        }

    }
;
    public static final zzf xL = new zzf() {

        public boolean zzd(char c1)
        {
            return Character.isLowerCase(c1);
        }

    }
;
    public static final zzf xM = zza('\0', '\037').zza(zza('\177', '\237'));
    public static final zzf xN = zza('\0', ' ').zza(zza('\177', '\240')).zza(zzc('\255')).zza(zza('\u0600', '\u0603')).zza(zza("\u06DD\u070F\u1680\u17B4\u17B5\u180E")).zza(zza('\u2000', '\u200F')).zza(zza('\u2028', '\u202F')).zza(zza('\u205F', '\u2064')).zza(zza('\u206A', '\u206F')).zza(zzc('\u3000')).zza(zza('\uD800', '\uF8FF')).zza(zza("\uFEFF\uFFF9\uFFFA\uFFFB"));
    public static final zzf xO = zza('\0', '\u04F9').zza(zzc('\u05BE')).zza(zza('\u05D0', '\u05EA')).zza(zzc('\u05F3')).zza(zzc('\u05F4')).zza(zza('\u0600', '\u06FF')).zza(zza('\u0750', '\u077F')).zza(zza('\u0E00', '\u0E7F')).zza(zza('\u1E00', '\u20AF')).zza(zza('\u2100', '\u213A')).zza(zza('\uFB50', '\uFDFF')).zza(zza('\uFE70', '\uFEFF')).zza(zza('\uFF61', '\uFFDC'));
    public static final zzf xP = new zzf() {

        public boolean zzd(char c1)
        {
            return true;
        }

        public boolean zzb(CharSequence charsequence)
        {
            zzab.zzaa(charsequence);
            return true;
        }

        public zzf zza(zzf zzf2)
        {
            zzab.zzaa(zzf2);
            return this;
        }

    }
;
    public static final zzf xQ = new zzf() {

        public boolean zzd(char c1)
        {
            return false;
        }

        public boolean zzb(CharSequence charsequence)
        {
            return charsequence.length() == 0;
        }

        public zzf zza(zzf zzf2)
        {
            return (zzf)zzab.zzaa(zzf2);
        }

    }
;

    static 
    {
        zzf zzf1 = zza('0', '9');
        String s = "\u0660\u06F0\u07C0\u0966\u09E6\u0A66\u0AE6\u0B66\u0BE6\u0C66\u0CE6\u0D66\u0E50\u0ED0\u0F20\u1040\u1090\u17E0\u1810\u1946\u19D0\u1B50\u1BB0\u1C40\u1C50\uA620\uA8D0\uA900\uAA50\uFF10";
        char ac[] = s.toCharArray();
        int i = ac.length;
        for(int j = 0; j < i; j++)
        {
            char c = ac[j];
            zzf1 = zzf1.zza(zza(c, (char)(c + 9)));
        }

        xF = zzf1;
    }
}
