// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.internal;

import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.lang.reflect.Field;

public abstract class DowngradeableSafeParcel extends AbstractSafeParcelable
{

    public DowngradeableSafeParcel()
    {
        yh = false;
    }

    protected static ClassLoader zzaso()
    {
        Object obj = ye;
        JVM INSTR monitorenter ;
        return null;
        Exception exception;
        exception;
        throw exception;
    }

    protected static Integer zzasp()
    {
        Object obj = ye;
        JVM INSTR monitorenter ;
        return null;
        Exception exception;
        exception;
        throw exception;
    }

    protected boolean zzasq()
    {
        DowngradeableSafeParcel _tmp = this;
        return false;
    }

    protected static boolean zzhl(String s)
    {
        ClassLoader classloader = zzaso();
        if(classloader == null)
            return true;
        try
        {
            Class class1 = classloader.loadClass(s);
            return zzd(class1);
        }
        catch(Exception exception)
        {
            return false;
        }
    }

    private static boolean zzd(Class class1)
    {
        try
        {
            Field field = class1.getField("NULL");
            return "SAFE_PARCELABLE_NULL_STRING".equals(field.get(null));
        }
        catch(NoSuchFieldException nosuchfieldexception)
        {
            return false;
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            return false;
        }
    }

    private static final Object ye = new Object();
    private static ClassLoader yf = null;
    private static Integer yg = null;
    private boolean yh;

}
