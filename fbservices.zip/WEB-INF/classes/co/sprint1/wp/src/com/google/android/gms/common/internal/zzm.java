// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.google.android.gms.common.internal;

import android.content.*;

// Referenced classes of package com.google.android.gms.common.internal:
//            zzn

public abstract class zzm
{

    public zzm()
    {
    }

    public static zzm zzce(Context context)
    {
        synchronized(yz)
        {
            if(yA == null)
                yA = new zzn(context.getApplicationContext());
        }
        return yA;
    }

    public abstract boolean zza(String s, String s1, ServiceConnection serviceconnection, String s2);

    public abstract boolean zza(ComponentName componentname, ServiceConnection serviceconnection, String s);

    public abstract void zzb(String s, String s1, ServiceConnection serviceconnection, String s2);

    public abstract void zzb(ComponentName componentname, ServiceConnection serviceconnection, String s);

    private static final Object yz = new Object();
    private static zzm yA;

}
