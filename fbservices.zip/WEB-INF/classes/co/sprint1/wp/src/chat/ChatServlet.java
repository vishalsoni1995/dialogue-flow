// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ChatServlet.java

package chat;

import java.io.*;
import java.util.ArrayList;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import org.apache.catalina.comet.CometEvent;
import org.apache.catalina.comet.CometProcessor;

public class ChatServlet extends HttpServlet
    implements CometProcessor
{
    public class MessageSender
        implements Runnable
    {

        public void stop()
        {
            running = false;
            synchronized(messages)
            {
                messages.notify();
            }
        }

        public void send(String user, String message)
        {
            synchronized(messages)
            {
                messages.add((new StringBuilder()).append("[").append(user).append("]: ").append(message).toString());
                messages.notify();
            }
        }

        public void run()
        {
            do
            {
                if(!running)
                    break;
                String pendingMessages[];
                synchronized(messages)
                {
                    try
                    {
                        if(messages.size() == 0)
                            messages.wait();
                    }
                    catch(InterruptedException e) { }
                    pendingMessages = (String[])messages.toArray(new String[0]);
                    messages.clear();
                }
                synchronized(connections)
                {
                    for(int i = 0; i < connections.size(); i++)
                        try
                        {
                            PrintWriter writer = ((HttpServletResponse)connections.get(i)).getWriter();
                            for(int j = 0; j < pendingMessages.length; j++)
                                writer.println((new StringBuilder()).append("<div>").append(ChatServlet.filter(pendingMessages[j])).append("</div>").toString());

                            writer.flush();
                        }
                        catch(IOException e)
                        {
                            log("IOException sending message", e);
                        }

                }
            } while(true);
        }

        protected boolean running;
        protected ArrayList messages;
        final ChatServlet this$0;

        public MessageSender()
        {
            this$0 = ChatServlet.this;
            super();
            running = true;
            messages = new ArrayList();
        }
    }


    public ChatServlet()
    {
        connections = new ArrayList();
        messageSender = null;
    }

    public void init()
        throws ServletException
    {
        messageSender = new MessageSender();
        Thread messageSenderThread = new Thread(messageSender, (new StringBuilder()).append("MessageSender[").append(getServletContext().getContextPath()).append("]").toString());
        messageSenderThread.setDaemon(true);
        messageSenderThread.start();
    }

    public void destroy()
    {
        connections.clear();
        messageSender.stop();
        messageSender = null;
    }

    public void event(CometEvent event)
        throws IOException, ServletException
    {
        HttpServletRequest request = event.getHttpServletRequest();
        HttpServletResponse response = event.getHttpServletResponse();
        if(event.getEventType() == org.apache.catalina.comet.CometEvent.EventType.BEGIN)
        {
            String action = request.getParameter("action");
            if(action != null)
                if("login".equals(action))
                {
                    String nickname = request.getParameter("nickname");
                    request.getSession(true).setAttribute("nickname", nickname);
                    response.sendRedirect("index.jsp");
                    event.close();
                    return;
                } else
                {
                    String nickname = (String)request.getSession(true).getAttribute("nickname");
                    String message = request.getParameter("message");
                    messageSender.send(nickname, message);
                    response.sendRedirect("post.jsp");
                    event.close();
                    return;
                }
            if(request.getSession(true).getAttribute("nickname") == null)
            {
                log((new StringBuilder()).append("Redirect to login for session: ").append(request.getSession(true).getId()).toString());
                response.sendRedirect("login.jsp");
                event.close();
                return;
            }
            begin(event, request, response);
        } else
        if(event.getEventType() == org.apache.catalina.comet.CometEvent.EventType.ERROR)
            error(event, request, response);
        else
        if(event.getEventType() == org.apache.catalina.comet.CometEvent.EventType.END)
            end(event, request, response);
        else
        if(event.getEventType() == org.apache.catalina.comet.CometEvent.EventType.READ)
            read(event, request, response);
    }

    protected void begin(CometEvent event, HttpServletRequest request, HttpServletResponse response)
        throws IOException
    {
        log((new StringBuilder()).append("Begin for session: ").append(request.getSession(true).getId()).toString());
        response.setContentType("text/html; charset=UTF-8");
        PrintWriter writer = response.getWriter();
        writer.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
        writer.println("<html><head><title>JSP Chat</title></head><body bgcolor=\"#FFFFFF\">");
        writer.println("<div>Welcome to the chat. <a href='chat'>Click here to reload this window</a></div>");
        writer.flush();
        synchronized(connections)
        {
            connections.add(response);
        }
        messageSender.send("Tomcat", (new StringBuilder()).append(request.getSession(true).getAttribute("nickname")).append(" joined the chat.").toString());
    }

    protected void end(CometEvent event, HttpServletRequest request, HttpServletResponse response)
        throws IOException
    {
        log((new StringBuilder()).append("End for session: ").append(request.getSession(true).getId()).toString());
        synchronized(connections)
        {
            connections.remove(response);
        }
        PrintWriter writer = response.getWriter();
        writer.println("</body></html>");
        event.close();
    }

    protected void error(CometEvent event, HttpServletRequest request, HttpServletResponse response)
        throws IOException
    {
        log((new StringBuilder()).append("Error for session: ").append(request.getSession(true).getId()).toString());
        synchronized(connections)
        {
            connections.remove(response);
        }
        event.close();
    }

    protected void read(CometEvent event, HttpServletRequest request, HttpServletResponse response)
        throws IOException
    {
label0:
        {
            InputStream is = request.getInputStream();
            byte buf[] = new byte[512];
            int n;
label1:
            do
            {
                for(; is.available() > 0; log((new StringBuilder()).append("Read ").append(n).append(" bytes: ").append(new String(buf, 0, n)).append(" for session: ").append(request.getSession(true).getId()).toString()))
                {
                    log((new StringBuilder()).append("Available: ").append(is.available()).toString());
                    n = is.read(buf);
                    if(n <= 0)
                        continue label1;
                }

                break label0;
            } while(n >= 0);
            log((new StringBuilder()).append("End of file: ").append(n).toString());
            end(event, request, response);
            return;
        }
    }

    protected void service(HttpServletRequest request, HttpServletResponse response)
        throws IOException, ServletException
    {
        response.setContentType("text/html; charset=UTF-8");
        PrintWriter writer = response.getWriter();
        writer.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
        writer.println("<html><head><title>JSP Chat</title></head><body bgcolor=\"#FFFFFF\">");
        writer.println("Chat example only supports Comet processing. ");
        writer.println("Configure a connector that supports Comet and try again.");
        writer.println("</body></html>");
    }

    protected static String filter(String message)
    {
        if(message == null)
            return null;
        char content[] = new char[message.length()];
        message.getChars(0, message.length(), content, 0);
        StringBuilder result = new StringBuilder(content.length + 50);
        for(int i = 0; i < content.length; i++)
            switch(content[i])
            {
            case 60: // '<'
                result.append("&lt;");
                break;

            case 62: // '>'
                result.append("&gt;");
                break;

            case 38: // '&'
                result.append("&amp;");
                break;

            case 34: // '"'
                result.append("&quot;");
                break;

            default:
                result.append(content[i]);
                break;
            }

        return result.toString();
    }

    private static final long serialVersionUID = 1L;
    private static final String CHARSET = "UTF-8";
    protected ArrayList connections;
    protected transient MessageSender messageSender;
}
