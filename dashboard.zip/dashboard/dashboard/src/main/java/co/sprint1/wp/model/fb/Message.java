// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Message.java

package co.sprint1.wp.model.fb;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public final class Message
{

	private String mid;
    private String text;
    private QuickReply quickReply;
    private Double seq;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 6875953780975627736L;

    public String getMid() {
        return mid;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }

    public String getText() {
        return text;
    }

	public void setText(String text) {
        this.text = text;
    }

    public QuickReply getQuickReply() {
        return quickReply;
    }

    public void setQuickReply(QuickReply quickReply) {
        this.quickReply = quickReply;
    }

    public Double getSeq() {
        return seq;
    }

    public void setSeq(Double seq) {
        this.seq = seq;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }
}
