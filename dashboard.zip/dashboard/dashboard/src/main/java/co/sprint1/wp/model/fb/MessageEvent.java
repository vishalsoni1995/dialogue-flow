// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   MessageEvent.java

package co.sprint1.wp.model.fb;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.util.Objects;

// Referenced classes of package co.sprint1.wp.model.fb:
//            Postback, Message2, QuickReply

public class MessageEvent
{
    public static class Attachment
    {

        public String getTitle()
        {
            return title;
        }

        public void setTitle(String title)
        {
            this.title = title;
        }

        public String getUrl()
        {
            return url;
        }

        public void setUrl(String url)
        {
            this.url = url;
        }

        public String getType()
        {
            return type;
        }

        public void setType(String type)
        {
            this.type = type;
        }

        public String getPayload()
        {
            return payload;
        }

        public void setPayload(String payload)
        {
            this.payload = payload;
        }

        private String title;
        private String url;
        private String type;
        private String payload;

        public Attachment()
        {
        }

        public Attachment(String title, String url, String type, String payload)
        {
            this.title = title;
            this.url = url;
            this.type = type;
            this.payload = payload;
        }
    }

    public static class Entity
    {

        public String getId()
        {
            return id;
        }

        public boolean equals(Object o)
        {
            if(this == o)
                return true;
            if(o == null || getClass() != o.getClass())
            {
                return false;
            } else
            {
                Entity entity = (Entity)o;
                return Objects.equals(id, entity.id);
            }
        }

        public int hashCode()
        {
            return Objects.hash(new Object[] {
                id
            });
        }

        public String toString()
        {
            return (new StringBuilder()).append("Entity{id='").append(id).append('\'').append('}').toString();
        }

        private String id;

        public Entity()
        {
        }

        public Entity(String id)
        {
            this.id = id;
        }
    }


    public static Gson getGson()
    {
        return gson;
    }

    public static void setGson(Gson gson)
    {
        gson = gson;
    }

    public void setMid(String mid)
    {
        this.mid = mid;
    }

    public void setText(String text)
    {
        this.text = text;
    }

    public void setTimestamp(long timestamp)
    {
        this.timestamp = timestamp;
    }

    public void setSender(Entity sender)
    {
        this.sender = sender;
    }

    public void setRecipient(Entity recipient)
    {
        this.recipient = recipient;
    }

    public String getMid()
    {
        return mid;
    }

    public String getText()
    {
        return text;
    }

    public long getTimestamp()
    {
        return timestamp;
    }

    public Entity getSender()
    {
        return sender;
    }

    public Entity getRecipient()
    {
        return recipient;
    }

    public MessageEvent()
    {
        timestamp = 0L;
    }

  

    public MessageEvent(String senderId, String recipientId, long timestamp, String mid, String text, Boolean isEcho, 
            String title, String url, QuickReply quickR)
    {
        this.timestamp = 0L;
        this.mid = mid;
        this.text = text;
        this.timestamp = timestamp;
        sender = new Entity(senderId);
        recipient = new Entity(recipientId);
    }

    public Message2 getMessage()
    {
        return message;
    }

    public void setMessage(Message2 message)
    {
        this.message = message;
    }

    public Postback getPostback()
    {
        return postback;
    }

    public void setPostback(Postback postback)
    {
        this.postback = postback;
    }

    private String mid;
    private String text;
    private long timestamp;
    private Entity sender;
    private Entity recipient;
    private Postback postback;
    private Message2 message;
    static Gson gson = new Gson();

}
