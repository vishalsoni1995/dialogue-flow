// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AIFulfilmentRequest.java

package co.sprint1.wp.model.dialogflow;

import java.io.Serializable;

// Referenced classes of package co.sprint1.wp.model.dialogflow:
//            QueryResult, OriginalRequest

public class AIFulfilmentRequest implements Serializable
{
	 private static final long serialVersionUID = 1L;
	    private String responseId;
	    private String session;
	    private QueryResult queryResult;
	    private OriginalRequest originalDetectIntentRequest;

    public AIFulfilmentRequest()
    {
    }

    public String getResponseId()
    {
        return responseId;
    }

    public void setResponseId(String responseId)
    {
        this.responseId = responseId;
    }

    public String getSession()
    {
        return session;
    }

    public void setSession(String session)
    {
        this.session = session;
    }

    public QueryResult getQueryResult()
    {
        return queryResult;
    }

    public void setQueryResult(QueryResult queryResult)
    {
        this.queryResult = queryResult;
    }

    public OriginalRequest getOriginalDetectIntentRequest()
    {
        return originalDetectIntentRequest;
    }

    public void setOriginalDetectIntentRequest(OriginalRequest originalDetectIntentRequest)
    {
        this.originalDetectIntentRequest = originalDetectIntentRequest;
    }

   
}
