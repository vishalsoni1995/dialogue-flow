// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Changes.java

package co.sprint1.wp.model.fb;

import java.io.Serializable;
import java.util.HashMap;

public class Changes
    implements Serializable
{

    public Changes()
    {
    }

    public String getField()
    {
        return field;
    }

    public void setField(String field)
    {
        this.field = field;
    }

    public HashMap getValue()
    {
        return value;
    }

    public void setValue(HashMap value)
    {
        this.value = value;
    }

    private static final long serialVersionUID = 1L;
    private String field;
    private HashMap value;
}
