// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   OutputContext.java

package co.sprint1.wp.model.dialogflow;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import co.sprint1.wp.model.fb.OutputContextParameters;

public class OutputContext
    implements Serializable
{

	private String name;
    private Integer lifespanCount;
    private OutputContextParameters parameters;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 8672370041211724777L;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getLifespanCount() {
        return lifespanCount;
    }

    public void setLifespanCount(Integer lifespanCount) {
        this.lifespanCount = lifespanCount;
    }

    public OutputContextParameters getParameters() {
        return parameters;
    }

    public void setParameters(OutputContextParameters parameters) {
        this.parameters = parameters;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }
    
}
