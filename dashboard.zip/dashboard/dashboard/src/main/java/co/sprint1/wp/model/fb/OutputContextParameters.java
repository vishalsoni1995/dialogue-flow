
package co.sprint1.wp.model.fb;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class OutputContextParameters implements Serializable
{

    private String computerName;
    private String acf2;
    private String computerNameOriginal;
    private String softwareNameOriginal;
    private String usernameOriginal;
    private String softwareName;
    private String username;
    private String acf2Original;
    private String facebookSenderId;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = 7702790439243689263L;

    public String getComputerName() {
        return computerName;
    }

    public void setComputerName(String computerName) {
        this.computerName = computerName;
    }

    public String getAcf2() {
        return acf2;
    }

    public void setAcf2(String acf2) {
        this.acf2 = acf2;
    }

    public String getComputerNameOriginal() {
        return computerNameOriginal;
    }

    public void setComputerNameOriginal(String computerNameOriginal) {
        this.computerNameOriginal = computerNameOriginal;
    }

    public String getSoftwareNameOriginal() {
        return softwareNameOriginal;
    }

    public void setSoftwareNameOriginal(String softwareNameOriginal) {
        this.softwareNameOriginal = softwareNameOriginal;
    }

    public String getUsernameOriginal() {
        return usernameOriginal;
    }

    public void setUsernameOriginal(String usernameOriginal) {
        this.usernameOriginal = usernameOriginal;
    }

    public String getSoftwareName() {
        return softwareName;
    }

    public void setSoftwareName(String softwareName) {
        this.softwareName = softwareName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getAcf2Original() {
        return acf2Original;
    }

    public void setAcf2Original(String acf2Original) {
        this.acf2Original = acf2Original;
    }

    public String getFacebookSenderId() {
        return facebookSenderId;
    }

    public void setFacebookSenderId(String facebookSenderId) {
        this.facebookSenderId = facebookSenderId;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
