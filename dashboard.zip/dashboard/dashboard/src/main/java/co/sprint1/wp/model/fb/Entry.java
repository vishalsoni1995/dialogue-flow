// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Entry.java

package co.sprint1.wp.model.fb;

import java.io.Serializable;
import java.util.List;

public class Entry
    implements Serializable
{

    public Entry()
    {
    }

    public Long getTime()
    {
        return time;
    }

    public void setTime(Long time)
    {
        this.time = time;
    }

    public List getChanges()
    {
        return changes;
    }

    public void setChanges(List changes)
    {
        this.changes = changes;
    }

    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public Long getUid()
    {
        return uid;
    }

    public void setUid(Long uid)
    {
        this.uid = uid;
    }

    public List getMessaging()
    {
        return messaging;
    }

    public void setMessaging(List messaging)
    {
        this.messaging = messaging;
    }

    private static final long serialVersionUID = 1L;
    private Long time;
    private List changes;
    private Long id;
    private Long uid;
    private List messaging;
}
