// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CreateBroadcastMessageRequest.java

package co.sprint1.wp.model.fb.ro;

import java.util.List;

public class CreateBroadcastMessageRequest
{

    public CreateBroadcastMessageRequest()
    {
    }

    public List getMessages()
    {
        return messages;
    }

    public void setMessages(List messages)
    {
        this.messages = messages;
    }

    private List messages;
}
