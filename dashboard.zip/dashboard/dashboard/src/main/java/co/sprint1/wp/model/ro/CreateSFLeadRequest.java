// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CreateSFLeadRequest.java

package co.sprint1.wp.model.ro;

import java.io.Serializable;

public class CreateSFLeadRequest
    implements Serializable
{

    public CreateSFLeadRequest()
    {
    }

    public String getLastName()
    {
        return lastName;
    }

    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    public String getCompany()
    {
        return company;
    }

    public void setCompany(String company)
    {
        this.company = company;
    }

    public String getOwnerId()
    {
        return ownerId;
    }

    public void setOwnerId(String ownerId)
    {
        this.ownerId = ownerId;
    }

    public String getMobile()
    {
        return mobile;
    }

    public void setMobile(String mobile)
    {
        this.mobile = mobile;
    }

    public String getEmail()
    {
        return email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getProductInterest()
    {
        return productInterest;
    }

    public void setProductInterest(String productInterest)
    {
        this.productInterest = productInterest;
    }

    private static final long serialVersionUID = 1L;
    private String lastName;
    private String firstName;
    private String company;
    private String ownerId;
    private String mobile;
    private String email;
    private String productInterest;
}
