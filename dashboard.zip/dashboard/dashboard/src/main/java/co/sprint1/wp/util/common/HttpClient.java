// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   HttpClient.java

package co.sprint1.wp.util.common;

import java.io.IOException;
import java.util.*;
import okhttp3.*;

public final class HttpClient
{
    public static final class HttpResponse
    {

        public int getStatusCode()
        {
            return statusCode;
        }

        public String getBody()
        {
            return body;
        }

        private final int statusCode;
        private final String body;

        public HttpResponse(int statusCode, String body)
        {
            this.statusCode = statusCode;
            this.body = body;
        }
    }

    public enum HttpMethod
    {
    	
    	GET, POST, DELETE
    }


    public HttpClient()
    {
    }

    public static HttpResponse execute(HttpMethod httpMethod, String url, Map headers, String jsonBody)
        throws IOException
    {
        Response response;
        Throwable throwable;
        okhttp3.Request.Builder requestBuilder = (new okhttp3.Request.Builder()).url(url);
        java.util.Map.Entry header;
        for(Iterator iterator = headers.entrySet().iterator(); iterator.hasNext(); requestBuilder.header((String)header.getKey(), (String)header.getValue()))
            header = (java.util.Map.Entry)iterator.next();

        if(httpMethod != HttpMethod.GET)
        {
            MediaType jsonMediaType = MediaType.parse("application/json; charset=utf-8");
            RequestBody requestBody = RequestBody.create(jsonMediaType, jsonBody);
            requestBuilder.method(httpMethod.name(), requestBody);
        }
        Request request = requestBuilder.build();
        response = okHttp.newCall(request).execute();
        throwable = null;
        HttpResponse httpresponse;
        try
        {
            httpresponse = new HttpResponse(response.code(), response.body().string());
        }
        catch(Throwable throwable1)
        {
            throwable = throwable1;
            throw throwable1;
        }
        response.close();
        return httpresponse;
       
    }

    public static HttpResponse executeFormPost(HttpMethod httpMethod, String url, Map headers, Map requestBody)
        throws IOException
    {
        Response response;
        Throwable throwable;
        okhttp3.Request.Builder requestBuilder = new okhttp3.Request.Builder();
        okhttp3.FormBody.Builder formBuilder = new okhttp3.FormBody.Builder();
        RequestBody formBody = null;
        java.util.Map.Entry header;
        for(Iterator iterator = headers.entrySet().iterator(); iterator.hasNext(); requestBuilder.header((String)header.getKey(), (String)header.getValue()))
            header = (java.util.Map.Entry)iterator.next();

        requestBuilder.addHeader("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
        java.util.Map.Entry body;
        for(Iterator iterator1 = requestBody.entrySet().iterator(); iterator1.hasNext(); formBuilder.add((String)body.getKey(), (String)body.getValue()))
            body = (java.util.Map.Entry)iterator1.next();

        formBody = formBuilder.build();
        Request request = requestBuilder.url(url).post(formBody).build();
        response = okHttp.newCall(request).execute();
        throwable = null;
        HttpResponse httpresponse;
        try
        {
            httpresponse = new HttpResponse(response.code(), response.body().string());
        }
        catch(Throwable throwable1)
        {
            throwable = throwable1;
            throw throwable1;
        }
       
        response.close();
        return httpresponse;
       
    }

    public static HttpResponse execute(HttpMethod httpMethod, String url, String jsonBody)
        throws IOException
    {
        return execute(httpMethod, url, ((Map) (new HashMap())), jsonBody);
    }

    private static final String APPLICATION_JSON_CHARSET_UTF_8 = "application/json; charset=utf-8";
    private static final String APPLICATION_FORM_URL_ENCODE = "application/x-www-form-urlencoded; charset=utf-8";
    private static final OkHttpClient okHttp = new OkHttpClient();

}
