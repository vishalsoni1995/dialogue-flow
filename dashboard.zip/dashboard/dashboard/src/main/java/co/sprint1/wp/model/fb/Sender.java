
package co.sprint1.wp.model.fb;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class Sender implements Serializable
{

    private String id;
    private Community community;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -9038971608337769655L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Community getCommunity() {
        return community;
    }

    public void setCommunity(Community community) {
        this.community = community;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
