// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   MessagingResponse.java

package co.sprint1.wp.model.fb;

import java.util.Objects;

// Referenced classes of package co.sprint1.wp.model.fb:
//            Recipient, NotificationType, Message, SenderAction

public final class MessagingResponse
{

    public MessagingResponse(Recipient recipient, NotificationType notificationType, Message message, SenderAction senderAction)
    {
        this.recipient = recipient;
        this.notificationType = notificationType;
        this.message = message;
        this.senderAction = senderAction;
    }

    public Recipient getRecipient()
    {
        return recipient;
    }

    public NotificationType getNotificationType()
    {
        return notificationType;
    }

    public Message getMessage()
    {
        return message;
    }

    public SenderAction getSenderAction()
    {
        return senderAction;
    }

    public boolean equals(Object o)
    {
        if(this == o)
            return true;
        if(o == null || getClass() != o.getClass())
        {
            return false;
        } else
        {
            MessagingResponse that = (MessagingResponse)o;
            return Objects.equals(recipient, that.recipient) && notificationType == that.notificationType && Objects.equals(message, that.message) && senderAction == that.senderAction;
        }
    }

    public int hashCode()
    {
        return Objects.hash(new Object[] {
            recipient, notificationType, message, senderAction
        });
    }

    public String toString()
    {
        return (new StringBuilder()).append("MessagingPayload{recipient=").append(recipient).append(", notificationType=").append(notificationType).append(", message=").append(message).append(", senderAction=").append(senderAction).append('}').toString();
    }

    private final Recipient recipient;
    private final NotificationType notificationType;
    private final Message message;
    private final SenderAction senderAction;
}
