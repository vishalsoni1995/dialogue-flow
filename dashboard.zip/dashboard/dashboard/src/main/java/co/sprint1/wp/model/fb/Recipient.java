
package co.sprint1.wp.model.fb;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class Recipient implements Serializable
{
	private String id;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();
    private final static long serialVersionUID = -3327332303847745098L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
