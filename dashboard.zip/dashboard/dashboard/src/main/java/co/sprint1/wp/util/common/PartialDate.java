// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PartialDate.java

package co.sprint1.wp.util.common;

import java.util.*;

public class PartialDate
{

    public PartialDate()
    {
        unspecifiedFields = new HashSet();
        c = Calendar.getInstance();
    }

    public PartialDate(Calendar calendar)
    {
        unspecifiedFields = new HashSet();
        c = calendar;
    }

    public PartialDate(Date date)
    {
        this();
        c.setTime(date);
    }

    public void set(int field, Integer value)
    {
        if(value == UNSPECIFIED_VALUE)
        {
            if(field == 1)
                unspecifiedFields.add(Integer.valueOf(1));
            else
            if(field == 2)
                unspecifiedFields.add(Integer.valueOf(2));
            else
            if(field >= 3 && field <= 8)
                unspecifiedFields.add(Integer.valueOf(5));
            else
            if(field >= 10 && field <= 11)
                unspecifiedFields.add(Integer.valueOf(11));
            else
            if(field == 12)
                unspecifiedFields.add(Integer.valueOf(12));
        } else
        {
            unspecifiedFields.remove(Integer.valueOf(field));
            c.set(field, value.intValue());
        }
    }

    public Integer get(int field)
    {
        if(field == 1)
            if(!unspecifiedFields.contains(Integer.valueOf(1)))
                return Integer.valueOf(c.get(field));
            else
                return UNSPECIFIED_VALUE;
        if(field == 2)
            if(!unspecifiedFields.contains(Integer.valueOf(2)))
                return Integer.valueOf(c.get(field));
            else
                return UNSPECIFIED_VALUE;
        if(field >= 3 && field <= 8)
            if(!unspecifiedFields.contains(Integer.valueOf(5)))
                return Integer.valueOf(c.get(field));
            else
                return UNSPECIFIED_VALUE;
        if(field >= 10 && field <= 11)
            if(!unspecifiedFields.contains(Integer.valueOf(11)))
                return Integer.valueOf(c.get(field));
            else
                return UNSPECIFIED_VALUE;
        if(field == 12)
        {
            if(!unspecifiedFields.contains(Integer.valueOf(12)))
                return Integer.valueOf(c.get(12));
            else
                return UNSPECIFIED_VALUE;
        } else
        {
            return Integer.valueOf(c.get(field));
        }
    }

    private String getFieldAsString(int field)
    {
        if(field == 1)
            if(unspecifiedFields.contains(Integer.valueOf(1)))
                return "uuuu";
            else
                return String.format("%4d", new Object[] {
                    Integer.valueOf(c.get(field))
                });
        if(field == 2)
            if(unspecifiedFields.contains(Integer.valueOf(2)))
                return "uu";
            else
                return String.format("%02d", new Object[] {
                    Integer.valueOf(c.get(field))
                });
        if(field >= 3 && field <= 8)
            if(unspecifiedFields.contains(Integer.valueOf(5)))
                return "uu";
            else
                return String.format("%02d", new Object[] {
                    Integer.valueOf(c.get(field))
                });
        if(field >= 10 && field <= 11)
            if(unspecifiedFields.contains(Integer.valueOf(11)))
                return "uu";
            else
                return String.format("%02d", new Object[] {
                    Integer.valueOf(c.get(field))
                });
        if(field == 12)
        {
            if(unspecifiedFields.contains(Integer.valueOf(12)))
                return "uu";
            else
                return String.format("%02d", new Object[] {
                    Integer.valueOf(c.get(field))
                });
        } else
        {
            return String.format("%s", new Object[] {
                Integer.valueOf(c.get(field))
            });
        }
    }

    public String toString()
    {
        return String.format("%s-%s-%s", new Object[] {
            getFieldAsString(1), getFieldAsString(2), getFieldAsString(5)
        });
    }

    public static final Integer UNSPECIFIED_VALUE = null;
    private static final String UNSPECIFIED_YEAR = "uuuu";
    private static final String UNSPECIFIED_MONTH = "uu";
    private static final String UNSPECIFIED_DATE = "uu";
    private static final String UNSPECIFIED_HOUR = "uu";
    private static final String UNSPECIFIED_MINUTE = "uu";
    private final Calendar c;
    private final Set unspecifiedFields;

}
