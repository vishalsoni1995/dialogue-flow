// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   WebHookRequest.java

package co.sprint1.wp.model.ro;

import java.io.Serializable;
import java.util.List;

public class WebHookRequest
    implements Serializable
{

    public WebHookRequest()
    {
    }

    public List getEntry()
    {
        return entry;
    }

    public void setEntry(List entry)
    {
        this.entry = entry;
    }

    public String getObject()
    {
        return object;
    }

    public void setObject(String object)
    {
        this.object = object;
    }

    private static final long serialVersionUID = 1L;
    private List entry;
    private String object;
}
