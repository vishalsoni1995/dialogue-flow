// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   IOUtils.java

package co.sprint1.wp.util.common;

import java.io.*;
import java.nio.charset.Charset;

public class IOUtils
{

    public IOUtils()
    {
    }

    public static void writeAll(String data, OutputStream outputStream, Charset charset)
        throws IOException
    {
        writeAll(data, outputStream, charset.name());
    }

    public static void writeAll(String data, OutputStream outputStream, String charset)
        throws IOException
    {
        if(data != null && data.length() > 0)
            outputStream.write(data.getBytes(charset));
    }

    public static void writeAll(String data, OutputStream outputStream)
        throws IOException
    {
        writeAll(data, outputStream, "UTF-8");
    }

    public static String readAll(InputStream inputStream, Charset charset)
        throws IOException
    {
        return readAll(inputStream, charset.name());
    }

    public static String readAll(InputStream inputStream, String charset)
        throws IOException
        {
        InputStreamReader streamReader;
        Throwable throwable;
        streamReader = new InputStreamReader(inputStream, charset);
        throwable = null;
        String s;
        try
        {
            s = readAll(streamReader);
        }
        catch(Throwable throwable1)
        {
            throwable = throwable1;
            throw throwable1;
        }
        if(streamReader != null)

                streamReader.close();
        return s;
      
    }

    public static String readAll(InputStream inputStream)
        throws IOException
    {
        return readAll(inputStream, "UTF-8");
    }

    public static String readAll(InputStreamReader streamReader)
        throws IOException
    {
        StringWriter result = new StringWriter();
        copy(streamReader, result);
        return result.toString();
    }

    private static long copy(Reader reader, Writer writer)
        throws IOException
    {
        return copy(reader, writer, new char[4096]);
    }

    private static long copy(Reader reader, Writer writer, char buffer[])
        throws IOException
    {
//        if(!$assertionsDisabled && buffer == null)
//            throw new AssertionError();
//        if(!$assertionsDisabled && buffer.length <= 0)
//            throw new AssertionError();
        long result = 0L;
        for(int read = reader.read(buffer); read > 0; read = reader.read(buffer))
        {
            writer.write(buffer, 0, read);
            result += read;
        }

        return result;
    }

    private static final int DEFAULT_BUFFER_SIZE = 4096;
    private static final String DEFAULT_CHARSET = "UTF-8";
  //  static final boolean $assertionsDisabled = !co/sprint1/wp/util/common/IOUtils.desiredAssertionStatus();

}
