// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Message2.java

package co.sprint1.wp.model.fb;

import java.util.List;
import java.util.Objects;

// Referenced classes of package co.sprint1.wp.model.fb:
//            QuickReply

public class Message2
{

    public Message2()
    {
    }

    public void setText(String text)
    {
        this.text = text;
    }

    public void setMetadata(String metadata)
    {
        this.metadata = metadata;
    }

    public boolean isIs_echo()
    {
        return is_echo;
    }

    public void setIs_echo(boolean is_echo)
    {
        this.is_echo = is_echo;
    }

    public String getMid()
    {
        return mid;
    }

    public void setMid(String mid)
    {
        this.mid = mid;
    }

    public String getText()
    {
        return text;
    }

    public String getMetadata()
    {
        return metadata;
    }

    public boolean equals(Object o)
    {
        if(this == o)
            return true;
        if(o == null || getClass() != o.getClass())
        {
            return false;
        } else
        {
            Message2 message = (Message2)o;
            return Objects.equals(text, message.text) && Objects.equals(quick_reply, message.quick_reply) && Objects.equals(metadata, message.metadata);
        }
    }

    public int hashCode()
    {
        return Objects.hash(new Object[] {
            text, quick_reply, metadata
        });
    }

    public String toString()
    {
        return (new StringBuilder()).append("Message{text='").append(text).append('\'').append(", quickreply=").append(quick_reply).append(", metadata='").append(metadata).append('\'').append('}').toString();
    }

    public QuickReply getQuick_reply()
    {
        return quick_reply;
    }

    public void setQuick_reply(QuickReply quick_reply)
    {
        this.quick_reply = quick_reply;
    }

    public List getAttachments()
    {
        return attachments;
    }

    public void setAttachments(List attachments)
    {
        this.attachments = attachments;
    }

    private boolean is_echo;
    private String mid;
    private String text;
    private List attachments;
    private QuickReply quick_reply;
    private String metadata;
}
