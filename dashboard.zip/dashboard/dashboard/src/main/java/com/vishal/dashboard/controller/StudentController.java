package com.vishal.dashboard.controller;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.google.gson.Gson;
import com.vishal.dashboard.model.Course;
import com.vishal.dashboard.model.Employee;
import com.vishal.dashboard.service.StudentService;

import co.sprint1.wp.model.dialogflow.AIFulfilmentRequest;
import co.sprint1.wp.model.dialogflow.OutputContext;
import co.sprint1.wp.model.dialogflow.QueryResult;
import co.sprint1.wp.model.fb.Message;
import co.sprint1.wp.model.fb.MessageEvent;
import co.sprint1.wp.model.fb.MessagingResponse;
import co.sprint1.wp.model.fb.NotificationType;
import co.sprint1.wp.model.fb.OutputContextParameters;
import co.sprint1.wp.model.fb.Payload;
import co.sprint1.wp.model.fb.Recipient;
import co.sprint1.wp.model.fb.RequestPayload;
import co.sprint1.wp.util.common.HttpClient;
import co.sprint1.wp.util.common.LogUtil;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@RestController
public class StudentController {
	
	
	Logger logger;
	Gson gson = new Gson();;
	String requestUrl;
	private static final String FB_GRAPH_API_URL = "https://graph.facebook.com/v2.11/me/messages?access_token=DQVJzeDYzWXpuYnkwaVhIUy1aWml3YU5ueEUzTVBHN2VzdkNkOXZAuN3hzVVpoeUxxRE14ZA3ltUzIzZA3d0aGVvZA0RQRXlRb0VmNEhic2F6VDlBUURXZA1ZAqRWxIV0dEOUdNejUyZA1FUd0RXdXNtVGVuVy13MjBQekpaVEJTd1FZAbEQtQUR3cGp2ZAVVXU2Q1YVVjT3VhcGxfdDRVN0pfc3hKdHF6ajNVRVBFV2xPbGs0aXMwWkhucDR6U2tuMEE5OElGdGJHTGM5a24yeHdJYW5FaAZDZD";
	
	@Autowired
	private StudentService studentService;

	@GetMapping("/students/{studentId}/courses")
	public List<Course> retrieveCoursesForStudent(@PathVariable String studentId) {
		return studentService.retrieveCourses(studentId);
	}
	
	@GetMapping("/students/{studentId}/courses/{courseId}")
	public Course retrieveDetailsForCourse(@PathVariable String studentId,
			@PathVariable String courseId) {
		return studentService.retrieveCourse(studentId, courseId);
	}
	
	@GetMapping("/students/getEmployees")
	public ArrayList<Employee> getAllEmployees() {
		return studentService.getAllEmployees();
	}
	
	@GetMapping("/students/getEmployee")
	public Employee getEmployee() {
		return studentService.getEmployee();
	}
	
	
	@GetMapping("/devices")
	public String getDeviceList() {
		return "Device";
	}
	
	@PostMapping("/students/{studentId}/courses")
	public ResponseEntity<Void> registerStudentForCourse(
			@PathVariable String studentId, @RequestBody Course newCourse) {

		Course course = studentService.addCourse(studentId, newCourse);

		if (course == null)
			return ResponseEntity.noContent().build();

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path(
				"/{id}").buildAndExpand(course.getId()).toUri();

		return ResponseEntity.created(location).build();
	}
	
	

	@PostMapping("/checkwebhook")
    public String broadcastMessage(@RequestBody AIFulfilmentRequest request)
        throws IOException
    {
		int a= 1;
		
		RequestPayload payload = request.getOriginalDetectIntentRequest().getPayload();
		
		String senderid = payload.getData().getSender().getId();
		String username = request.getQueryResult().getOutputContexts().get(0).getParameters().getUsername();
		System.out.println(senderid);
sendTextMessage(senderid, "hello from eclipse", null);
		return "success";
       
    }
	
	 public void sendTextMessage(String recipientId, String text, List quickList)
		        throws IOException
		    {
		        if(recipientId != null && !recipientId.equals(""))
		        {
		          //  logger.debug(recipientId);
		            Recipient recipient = new Recipient();
		            recipient.setId(recipientId);
		            Message message = new Message();
		            message.setText(text);
		            MessagingResponse response = new MessagingResponse(recipient, NotificationType.REGULAR, message, null);
		            doRequest(co.sprint1.wp.util.common.HttpClient.HttpMethod.POST, response);
		        }
		    }

		    private void doRequest(co.sprint1.wp.util.common.HttpClient.HttpMethod method, MessagingResponse response)
		        throws IOException
		    {
		        String jsonBody = response != null ? gson.toJson(response) : null;
		     //   logger.debug((new StringBuilder()).append("FB Send Message URL ::").append(requestUrl).append("Body :: ").append(jsonBody).toString());
		        co.sprint1.wp.util.common.HttpClient.HttpResponse httpResponse = HttpClient.execute(method, FB_GRAPH_API_URL, jsonBody);
		    //    logger.debug((new StringBuilder()).append("Message Post Response :").append(httpResponse.getStatusCode()).append(" , ").append(httpResponse.getBody()).toString());
		    }

    public String verifyFBToken(String mode, String verifyToken, String challenge)
    {
        logger.debug("Received Verification Request");
        if("subscribe".equalsIgnoreCase(mode) && "hitch-bot-token".equalsIgnoreCase(verifyToken))
            return challenge;
        else
            return "";
    }
    
 

}
