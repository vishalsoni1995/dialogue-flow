import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Health } from '@ionic-native/health';
import { UtilService } from '../../providers/utils/utils.service';
import { SunactivPage } from '../sunactiv/sunactiv';

declare var samsunghealth;

/**
 * Generated class for the SunactivDashboardPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-sunactiv-dashboard',
  templateUrl: 'sunactiv-dashboard.html',
})
export class SunactivDashboardPage {

  stepsToday: number = 0;
  stepsThisMonth: number = 0;
  avgStepsThisMonth: number = 0;
  currentDate: String; 
  status: String = "None";
  source: String;

  constructor(public navCtrl: NavController, public navParams: NavParams, private health: Health, public utils: UtilService) {

    var todaydate: Date = new Date();  
    this.currentDate = this.formatDate(todaydate.getMonth(), todaydate.getFullYear());
    this.source = localStorage.getItem("selectedDataSource");

    if(localStorage.getItem("selectedDataSource") == "Google Health"){
      this.authorizeGoogleFit();
    } else if(localStorage.getItem("selectedDataSource") == "Apple Health") {
      this.authorizeApple();
    } else {
      this.authorizeSamsung();
    }

  }

  authorizeSamsung(){
    this.utils.showProgressLoader();  
    samsunghealth.connect((success)=>{
      console.log('Connection success');
      var currentDate = new Date();
      currentDate.setDate(1);
      currentDate.setHours(0);
      currentDate.setMinutes(0);
      currentDate.setMilliseconds(0);
      currentDate.setSeconds(0);
      var fromDateTime = currentDate.getTime(); 
      var tillDateTime = new Date().getTime();
      // alert("From date is " + currentDate + " and mili second is " + fromDateTime);
      // alert("To date is " + new Date() + " and mili second is " + tillDateTime);
      samsunghealth.getData(fromDateTime,tillDateTime,(success)=>{
      // alert(JSON.stringify(success))
      console.log('Get data success');
      this.utils.dissmisProgressLoader();
      this.calculateStepsFromSamsungHealth((success));
      
    },(err)=>{
      this.utils.showAlert("",JSON.stringify(err));
      console.log(JSON.stringify(err));
      this.utils.dissmisProgressLoader();
    });
    },(err)=>{
      this.utils.showAlert("",JSON.stringify(err)); 
      console.log(JSON.stringify(err));
      this.utils.dissmisProgressLoader();
    });

  }

  authorizeApple(){
    this.authorizeGoogleFit();
  }

  calculateStepsFromSamsungHealth(success){

    var i:number;
    for(i=0;i<success.length;i++){
        this.stepsThisMonth = this.stepsThisMonth + success[i]["stepCount"]
    }
    var currentDate = new Date().getDate();
    this.stepsToday = success[0]["stepCount"]
    this.avgStepsThisMonth = Math.round(this.stepsThisMonth/currentDate);
    
  }

  authorizeGoogleFit(){
    this.utils.showProgressLoader();
      this.health.isAvailable()
      .then((available:boolean) => {
        console.log(available);
        console.log("Health available")
        this.health.requestAuthorization([
          {
            read: ['steps'],     
          }
        ])
        .then(res => 
          {
            console.log(res)
            console.log("Authprization success")
            this.loadStepsFromGoogleFit();
          })
        .catch(e => 
          {
            console.log(e);
            console.log("Authorization failed");
            this.utils.showAlert("", "Authorization failed");
            this.utils.dissmisProgressLoader();
          }
          );

      })
      .catch(e => 
        {
          console.log(e);
          console.log("Health not available");
          this.utils.showAlert("", "Health not available");
          this.utils.dissmisProgressLoader();
        }
        );
    
  }

  formatDate(month, year) {
    var monthNames = [
      "January", "February", "March",
      "April", "May", "June", "July",
      "August", "September", "October",
      "November", "December"
    ];

    var monthIndex = month;
    var year = year;

    return  monthNames[monthIndex] + ', ' + year;
  }

  loadStepsFromGoogleFit(){
    
     
      var currentDate = new Date();       
      var startDate = new Date(currentDate.setDate(1));
      var endDate = new Date(); 
      var bucket = 'day'; 
    
    
    this.health.queryAggregated({
      startDate: startDate, 
      endDate: endDate, 
      dataType: 'steps',
      bucket: bucket,
      filtered: true
      })  .then(res => 
      {
        console.log(res);
        this.calculateAverageSteps(res);
      }
      ) 
      .catch(e => 
        {
          console.log(e);
          this.utils.showAlert("", e);
          this.utils.dissmisProgressLoader();
        }
        );         

  }

  calculateAverageSteps(res){
    var currentDay = new Date().getDate();
    console.log("Current day no " + currentDay)
    for(var i=0; i<res.length;i++){
      this.stepsThisMonth = this.stepsThisMonth + res[i]['value'];
    } 
    this.stepsToday = res[res.length-1]['value'];  
    this.avgStepsThisMonth = Math.round(this.stepsThisMonth/currentDay); 
   
    console.log("Steps this month " + this.stepsThisMonth); 
    console.log("Avg steps this  months " +  this.avgStepsThisMonth);
    
    this.utils.dissmisProgressLoader();

  }

  
  unsync(){
    if(localStorage.getItem("selectedDataSource") == "Google Health"){
      this.unsyncFromDashboard("google");
    } else if(localStorage.getItem("selectedDataSource") == "Apple Health") {
      this.unsyncFromDashboard("apple");
    } else {
      this.unsyncFromDashboard("samsung");
    }
  }





  unsyncFromDashboard(sourceName){
    if (sourceName=="google"){
       this.utils.showProgressLoader();
      navigator["health"].disconnect((success)=>{
      localStorage.setItem('selectedDataSource', 'notSynced');
      this.utils.dissmisProgressLoader();
      this.navCtrl.push(SunactivPage);
      },
    (err)=>{      
      this.utils.dissmisProgressLoader();
      this.utils.showAlert("", err);
    });
    }
    else{
      this.utils.showProgressLoader();
    localStorage.setItem('selectedDataSource', 'notSynced');
    this.utils.dissmisProgressLoader();
     this.navCtrl.push(SunactivPage);
    }
   
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SunactivDashboardPage');
  }

}
