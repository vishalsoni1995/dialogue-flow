import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Health } from '@ionic-native/health';
import { UtilService } from '../../providers/utils/utils.service';
import { AppAvailability } from '@ionic-native/app-availability';
import { InAppBrowser } from '@ionic-native/in-app-browser';
import {SunactivDashboardPage} from '../sunactiv-dashboard/sunactiv-dashboard'
import { AlertController } from 'ionic-angular';

declare var samsunghealth:any;

/**
 * Generated class for the SunactivPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-sunactiv',
  templateUrl: 'sunactiv.html',
})
export class SunactivPage {

  PlatformiOS:boolean=false;

  constructor(public navCtrl: NavController, public navParams: NavParams,  private health: Health, public utils: UtilService, private appAvailability: AppAvailability, private iab: InAppBrowser, public alertCtrl: AlertController) {
    if (this.utils.getPlatform() == 'ios'){
      this.PlatformiOS=true;
    }
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SunactivPage');
  }

  syncGoogleFit(){
    let androidApp = 'com.google.android.apps.fitness';
    let iosApp = "com.google.fit";
    let app;
    if (this.PlatformiOS) {
        app = iosApp;
    } else {
        app = androidApp;
    }
    this.appAvailability.check(app)
    .then(
      (yes: boolean) => {
        console.log("Google fit is available");
        this.authorizeGoogleFit();
      },
      (no: boolean) => {
        console.log("Google fit is NOT available");
        this.promptInstallSamsungHealth("Do you want to install Google Fit?", "In order to sync data with Google Fit, Google Fit App must be installed.", "googleHealth");
      }      
    );
  }

  syncSamsungHealth(){
    let androidApp = 'com.sec.android.app.shealth';
    let iosApp = "com.samsung.health";
    let app;
    if (this.PlatformiOS) {
        app = iosApp;
    } else  {
        app = androidApp;
    }
    this.appAvailability.check(app)
    .then(
      (yes: boolean) => {
        console.log("Samsung Health is available");
        this.authorizeSamsungHealth();
      },
      (no: boolean) => {
        console.log("Samsung Health is NOT available");
        this.promptInstallSamsungHealth("Do you want to install Samsung Health?", "In order to sync data with Samsung health, Samsung Health App must be installed.", "samsungHealth");
      }
      
    );
  }

  syncAppleHealth(){
    this.authorizeGoogleFit();   
  }


  authorizeGoogleFit(){
    this.utils.showProgressLoader();
      this.health.isAvailable()
      .then((available:boolean) => {
        console.log(available);
        console.log("Health available")
        this.health.requestAuthorization([
          {
            read: ['steps'],     
          }
        ])
        .then(res => 
          {
            console.log(res)
            console.log("Authprization success")
            this.utils.dissmisProgressLoader();
            if (this.PlatformiOS){
              localStorage.setItem('selectedDataSource', 'Apple Health');  
            } else {
            localStorage.setItem('selectedDataSource', 'Google Health');
            }
            if (this.navCtrl.getActive().name != "SunactivDashboardPage") {
              this.navCtrl.push(SunactivDashboardPage);
            }
          })
        .catch(e => 
          {
            console.log(e);
            console.log("Authorization failed");
            this.utils.showAlert("", "Authorization failed");
            this.utils.dissmisProgressLoader();
          }
          );

      })
      .catch(e => 
        {
          console.log(e);
          console.log("Health not available");
          this.utils.showAlert("", "Health not available");
          this.utils.dissmisProgressLoader();
        }
        );
    
  }

  authorizeSamsungHealth(){
  
    samsunghealth.connect((success)=>{
      console.log('success');
      localStorage.setItem('selectedDataSource', 'Samsung Health');
      if (this.navCtrl.getActive().name != "SunactivDashboardPage") {
        this.navCtrl.push(SunactivDashboardPage);
      }
    },(err)=>{
           this.utils.showAlert("",JSON.stringify(err));
           console.log(JSON.stringify(err));
    });
    
  }
  
  promptInstallSamsungHealth(title,message,selectedApp){
    var url;
    if (this.PlatformiOS) {
      url = "https://apps.apple.com/in/app/samsung-health/id1224541484";
    } else {
        url = "https://play.google.com/store/apps/details?id=com.sec.android.app.shealth&hl=en";
    }   
  
      const confirm = this.alertCtrl.create({
          title: title,
          message: message,
          buttons: [
            {
              text: 'Disagree',
              handler: () => {
                console.log('Disagree clicked');
              }
            },
            {
              text: 'Agree',
              handler: () => {
                console.log('Agree clicked');
                if(selectedApp=="googleHealth"){
                this.health.promptInstallFit();
                } else {
                const browser = this.iab.create(url,  '_system');
                browser.show
                }
              }
            }
          ]
        });
        confirm.present();
  }

}
