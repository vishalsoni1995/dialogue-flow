#INTRO
This project contains a Cordova plugin for the Samsung Health platform.
Any pull request considered ;)

